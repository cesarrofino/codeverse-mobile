"""Gera os ícones PNG (legado API 24-25) e a pré-visualização 512px do CodeVerse.
O ícone adaptativo (API 26+) usa o vetor em res/drawable/ic_launcher_foreground.xml, com a mesma geometria.
Uso: python3 tools_make_icons.py
"""
from PIL import Image, ImageDraw
import os

BG = (30, 30, 30, 255)          # #1E1E1E
BLUE = (55, 148, 255, 255)      # #3794FF
BLUE_DARK = (0, 122, 204, 255)  # #007ACC
WHITE = (212, 212, 212, 255)    # #D4D4D4

# Geometria em unidades de 108 (viewport do ícone adaptativo)
LEFT = [(44, 38), (30, 54), (44, 70)]
RIGHT = [(64, 38), (78, 54), (64, 70)]
SLASH = [(58, 33), (50, 75)]


def draw_glyph(img, scale, offset=(0, 0), stroke=7):
    d = ImageDraw.Draw(img)
    def pts(points):
        return [(offset[0] + x * scale, offset[1] + y * scale) for x, y in points]
    w = int(stroke * scale)
    r = w / 2
    for poly, col in ((LEFT, BLUE), (RIGHT, BLUE_DARK), (SLASH, WHITE)):
        p = pts(poly)
        sw = w if col != WHITE else int(6 * scale)
        d.line(p, fill=col, width=sw, joint="curve")
        for (x, y) in p:
            rr = sw / 2
            d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=col)


def make(size, rounded=True, circle=False):
    S = 4  # supersampling
    big = size * S
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    mask = Image.new("L", (big, big), 0)
    md = ImageDraw.Draw(mask)
    if circle:
        md.ellipse([0, 0, big - 1, big - 1], fill=255)
    elif rounded:
        md.rounded_rectangle([0, 0, big - 1, big - 1], radius=int(big * 0.22), fill=255)
    else:
        md.rectangle([0, 0, big, big], fill=255)
    base = Image.new("RGBA", (big, big), BG)
    # o glifo ocupa a zona segura central; ampliamos um pouco no ícone legado
    scale = big / 108 * 1.25
    off = (big / 2 - 54 * scale, big / 2 - 54 * scale)
    draw_glyph(base, scale, off, stroke=7)
    img.paste(base, (0, 0), mask)
    return img.resize((size, size), Image.LANCZOS)


base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app/src/main/res")
for folder, px in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
    make(px, rounded=True).save(os.path.join(base, f"mipmap-{folder}", "ic_launcher.png"))
    make(px, circle=True).save(os.path.join(base, f"mipmap-{folder}", "ic_launcher_round.png"))

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon-preview-512.png")
make(512, rounded=True).save(out)
print("ok", out)
