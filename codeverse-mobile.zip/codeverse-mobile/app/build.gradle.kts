import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------------------------
// Biblioteca Java offline (rt.jar): gerada pelo próprio Gradle a partir do android.jar do SDK.
// Assim o rt.jar entra SEMPRE no APK, qualquer que seja o workflow/ferramenta usada no build.
// ---------------------------------------------------------------------------------------------
val javaRtDir = layout.buildDirectory.dir("generated/javaRt")
val generateJavaRt = tasks.register("generateJavaRt") {
    val outFile = javaRtDir.map { it.dir("java").file("rt.jar").asFile }
    val boot = androidComponents.sdkComponents.bootClasspath
    outputs.file(outFile)
    doLast {
        val androidJar = boot.get().map { it.asFile }.firstOrNull { it.name == "android.jar" }
            ?: error("android.jar não encontrado (instala 'platforms;android-34').")
        val target = outFile.get()
        target.parentFile.mkdirs()
        var n = 0
        ZipFile(androidJar).use { zin ->
            ZipOutputStream(target.outputStream().buffered()).use { zout ->
                for (e in zin.entries()) {
                    if (e.isDirectory) continue
                    val nm = e.name
                    if (!(nm.startsWith("java/") || nm.startsWith("javax/") || nm.startsWith("org/json/"))) continue
                    zout.putNextEntry(ZipEntry(nm))
                    zin.getInputStream(e).use { it.copyTo(zout) }
                    zout.closeEntry()
                    n++
                }
            }
        }
        if (n < 1000) error("rt.jar incompleto ($n ficheiros).")
        println("rt.jar gerado: $n ficheiros, ${target.length() / 1024} KB")
    }
}

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) dependsOn(generateJavaRt)
}

android {
    namespace = "com.codeverse.mobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.codeverse.mobile"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // ECJ e D8 (compilador Java offline) trazem ficheiros META-INF repetidos/assinados
    packaging {
        resources {
            excludes += listOf(
                "META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA", "META-INF/ECLIPSE_*",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES", "META-INF/versions/**"
            )
            pickFirsts += listOf("about.html", "plugin.properties", "META-INF/eclipse.inf", "META-INF/maven/**", "META-INF/services/**")
        }
    }

    // O wasm do Pyodide e o zip da stdlib ficam sem compressão extra no APK.
    sourceSets.getByName("main").assets.srcDir(project.files(javaRtDir).builtBy(generateJavaRt))

    androidResources {
        noCompress += listOf("wasm", "zip")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.documentfile:documentfile:1.0.1")

    // Java offline: compilador Eclipse (ECJ) + conversor DEX (D8) a correr dentro da app
    implementation("org.eclipse.jdt:ecj:3.25.0")
    implementation("com.android.tools:r8:8.5.35")
}
