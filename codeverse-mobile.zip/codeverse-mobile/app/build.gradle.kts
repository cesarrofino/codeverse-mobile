plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.codeverse.mobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.codeverse.mobile"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // ECJ e D8 (compilador Java offline) trazem ficheiros META-INF repetidos/assinados
    packaging {
        resources {
            excludes += listOf(
                "META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA", "META-INF/ECLIPSE_*",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES", "META-INF/versions/**"
            )
            pickFirsts += listOf("about.html", "plugin.properties", "META-INF/eclipse.inf", "META-INF/maven/**", "META-INF/services/**")
        }
    }

    // O wasm do Pyodide e o zip da stdlib ficam sem compressão extra no APK.
    androidResources {
        noCompress += listOf("wasm", "zip")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")

    // Java offline: compilador Eclipse (ECJ) + conversor DEX (D8) a correr dentro da app
    implementation("org.eclipse.jdt:ecj:3.25.0")
    implementation("com.android.tools:r8:8.5.35")
}
