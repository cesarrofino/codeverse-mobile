package com.codeverse.mobile

import android.webkit.MimeTypeMap
import java.io.BufferedInputStream
import java.io.File
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import kotlin.concurrent.thread

/**
 * Servidor HTTP mínimo, só em localhost (127.0.0.1): serve os ficheiros dos projetos
 * (http://localhost:PORTA/<projeto>/<caminho>) para abrir a página no navegador do telemóvel.
 */
class LocalServer(private val store: ProjectStore) {
    @Volatile private var server: ServerSocket? = null

    @Synchronized
    fun start(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val lo = InetAddress.getByName("127.0.0.1")
        val s = try { ServerSocket(8080, 20, lo) } catch (_: Exception) { ServerSocket(0, 20, lo) }
        server = s
        thread(name = "cv-local-server", isDaemon = true) {
            while (!s.isClosed) {
                val c = try { s.accept() } catch (_: Exception) { break }
                thread(isDaemon = true) { handle(c) }
            }
        }
        return s.localPort
    }

    private fun handle(sock: Socket) {
        sock.use { c ->
            try {
                c.soTimeout = 8000
                val input = BufferedInputStream(c.getInputStream())
                val first = readLine(input) ?: return
                while (true) { val h = readLine(input) ?: break; if (h.isEmpty()) break }
                val parts = first.split(' ')
                if (parts.size < 2) return
                val method = parts[0]
                val out = c.getOutputStream()
                if (method != "GET" && method != "HEAD") { send(out, 405, "Method Not Allowed", "text/plain", "405".toByteArray()); return }
                val raw = parts[1].substringBefore('?').substringBefore('#')
                val path = try { URLDecoder.decode(raw.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { raw }
                val clean = path.trimStart('/')
                val project = clean.substringBefore('/')
                val rel = if (clean.contains('/')) clean.substringAfter('/') else ""
                if (project.isEmpty() || project.contains("..") || rel.contains("..")) {
                    send(out, 404, "Not Found", "text/plain", "404".toByteArray()); return
                }
                // pasta sem "/" final: redireciona para que os caminhos relativos funcionem
                if (!path.endsWith("/") && File(store.dirOf(project), rel).isDirectory) {
                    val loc = raw + "/"
                    out.write(("HTTP/1.1 301 Moved Permanently\r\nLocation: $loc\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").toByteArray())
                    out.flush(); return
                }
                val f = store.fileForServe(project, rel)
                if (f == null) { send(out, 404, "Not Found", "text/plain", "404".toByteArray()); return }
                val ext = f.name.substringAfterLast('.', "").lowercase()
                val mime = MIME[ext] ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                val textual = mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json" || mime == "image/svg+xml"
                val ctype = if (textual) "$mime; charset=utf-8" else mime
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: $ctype\r\nContent-Length: ${f.length()}\r\n" +
                        "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray()
                )
                if (method == "GET") f.inputStream().use { it.copyTo(out) }
                out.flush()
            } catch (_: Exception) {
            }
        }
    }

    private fun send(out: OutputStream, code: Int, msg: String, type: String, body: ByteArray) {
        out.write(("HTTP/1.1 $code $msg\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray())
        out.write(body)
        out.flush()
    }

    private fun readLine(input: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private companion object {
        val MIME = mapOf(
            "html" to "text/html", "htm" to "text/html", "css" to "text/css",
            "js" to "application/javascript", "mjs" to "application/javascript",
            "json" to "application/json", "svg" to "image/svg+xml", "txt" to "text/plain",
            "md" to "text/plain", "wasm" to "application/wasm", "xml" to "text/xml",
            "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf", "otf" to "font/otf",
        )
    }
}
