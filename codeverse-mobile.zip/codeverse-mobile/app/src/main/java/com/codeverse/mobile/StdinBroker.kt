package com.codeverse.mobile

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Ponte para o input() do Python (que corre num Web Worker, onde não há teclado).
 *
 * O Worker faz um pedido XHR síncrono a https://appassets.androidplatform.net/__cv/stdin.
 * O MainActivity intercepta esse pedido e bloqueia aqui (await) até o utilizador escrever uma linha
 * no ecrã de execução (JS -> Bridge.pyInput -> submit). Assim input() bloqueia de verdade, como no PC.
 */
object StdinBroker {
    const val PATH = "/__cv/stdin"
    private const val EOF = "\u0000EOF"

    private val queue = LinkedBlockingQueue<String>()
    private val waiting = AtomicInteger(0)

    fun submit(line: String) { queue.offer(line) }

    /** Liberta um input() que esteja à espera (Parar / reiniciar). */
    fun cancel() { if (waiting.get() > 0) queue.offer(EOF) }

    /** Descarta linhas antigas antes de uma nova execução. */
    fun reset() { queue.clear() }

    /** Devolve "L:<linha>" ou "EOF". */
    fun await(): String {
        waiting.incrementAndGet()
        try {
            val v = queue.poll(15, TimeUnit.MINUTES) ?: return "EOF"
            return if (v == EOF) "EOF" else "L:$v"
        } finally {
            waiting.decrementAndGet()
        }
    }
}
