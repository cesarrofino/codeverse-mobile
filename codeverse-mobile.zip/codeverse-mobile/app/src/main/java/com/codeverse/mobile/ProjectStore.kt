package com.codeverse.mobile

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Armazenamento de projetos no armazenamento privado da app (filesDir/projects).
 * Todos os caminhos recebidos do JavaScript são validados para nunca saírem da pasta do projeto.
 */
class ProjectStore(private val root: File) {

    /** Espelho para o armazenamento do telemóvel (pastas/ficheiros ligados). Ver ExternalStorage. */
    interface SyncSink {
        fun onWrite(project: String, rel: String, file: File)
        fun onMkdir(project: String, rel: String)
        fun onDelete(project: String, rel: String)
        fun onRename(project: String, from: String, to: String)
        fun onProjectRenamed(from: String, to: String)
        fun onProjectDeleted(name: String)
    }

    @Volatile var sink: SyncSink? = null

    init {
        root.mkdirs()
    }

    /** Cria (e devolve o nome de) um projeto novo com nome único derivado de [base]. */
    @Synchronized
    fun newProjectName(base: String): String {
        val n = uniqueName(base)
        require(File(root, n).mkdirs()) { "Não foi possível criar o projeto." }
        return n
    }

    fun projectExists(name: String): Boolean = File(root, name).isDirectory

    private fun relOf(project: String, f: File): String =
        f.relativeTo(projectDir(project).canonicalFile).path.replace(File.separatorChar, '/')

    companion object {
        private const val MAX_TEXT_BYTES = 2L * 1024 * 1024
        private const val MAX_BASE64_BYTES = 5L * 1024 * 1024
        private const val MAX_TREE_ENTRIES = 5000
        private const val MAX_ZIP_ENTRIES = 5000
        private const val MAX_ZIP_TOTAL_BYTES = 150L * 1024 * 1024
        private val NAME_REGEX = Regex("^[\\p{L}\\p{N}_ .\\-]{1,60}$")
    }

    // ---------- Nomes e caminhos ----------

    fun validName(name: String): String {
        val n = name.trim()
        require(NAME_REGEX.matches(n) && !n.startsWith(".")) {
            "Nome inválido. Usa letras, números, espaços, _ . e - (máx. 60)."
        }
        return n
    }

    private fun sanitizeName(raw: String): String {
        var n = raw.trim().replace(Regex("[^\\p{L}\\p{N}_ .\\-]"), "_").trimStart('.')
        if (n.length > 60) n = n.substring(0, 60)
        return if (n.isBlank()) "projeto" else n
    }

    private fun uniqueName(base: String): String {
        val clean = sanitizeName(base)
        if (!File(root, clean).exists()) return clean
        var i = 2
        while (true) {
            val suffix = "-$i"
            val candidate = clean.take(60 - suffix.length) + suffix
            if (!File(root, candidate).exists()) return candidate
            i++
        }
    }

    /** Pasta do projeto (validada). Usada pelo compilador Java local. */
    fun dirOf(project: String): File = projectDir(project)

    private fun projectDir(project: String): File {
        val d = File(root, validName(project))
        require(d.isDirectory) { "Projeto não encontrado." }
        return d
    }

    private fun resolve(project: String, rel: String): File {
        val base = projectDir(project).canonicalFile
        val f = File(base, rel).canonicalFile
        require(f.path == base.path || f.path.startsWith(base.path + File.separator)) { "Caminho inválido." }
        return f
    }

    /** Ficheiro do projeto para a pré-visualização web (pasta -> index.html). Devolve null se não existir. */
    fun fileForServe(project: String, rel: String): File? = try {
        var f = resolve(project, rel)
        if (f.isDirectory) f = File(f, "index.html")
        if (f.isFile) f else null
    } catch (_: Exception) { null }

    private fun resolveInside(project: String, rel: String): File {
        require(rel.isNotBlank()) { "Caminho vazio." }
        val f = resolve(project, rel)
        require(f.path != projectDir(project).canonicalFile.path) { "Caminho inválido." }
        return f
    }

    private fun touch(project: String) {
        try {
            projectDir(project).setLastModified(System.currentTimeMillis())
        } catch (_: Exception) {
        }
    }

    // ---------- Projetos ----------

    fun listProjects(): JSONArray {
        val arr = JSONArray()
        root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }?.forEach {
            arr.put(JSONObject().put("name", it.name).put("modified", it.lastModified()))
        }
        return arr
    }

    fun createProject(name: String): String {
        val n = validName(name)
        val d = File(root, n)
        require(!d.exists()) { "Já existe um projeto com esse nome." }
        require(d.mkdirs()) { "Não foi possível criar o projeto." }
        return n
    }

    fun deleteProject(name: String) {
        val d = projectDir(name)
        require(d.deleteRecursively()) { "Não foi possível eliminar o projeto." }
        try { sink?.onProjectDeleted(d.name) } catch (_: Exception) { }
    }

    fun renameProject(from: String, to: String): String {
        val src = projectDir(from)
        val n = validName(to)
        val dst = File(root, n)
        require(!dst.exists()) { "Já existe um projeto com esse nome." }
        require(src.renameTo(dst)) { "Não foi possível renomear." }
        try { sink?.onProjectRenamed(src.name, n) } catch (_: Exception) { }
        return n
    }

    // ---------- Ficheiros ----------

    fun tree(project: String): JSONArray {
        val base = projectDir(project).canonicalFile
        val arr = JSONArray()
        var count = 0
        for (f in base.walkTopDown().onEnter { it == base || it.name != ".git" }) {
            if (f == base) continue
            if (f.name == ".git") continue
            if (++count > MAX_TREE_ENTRIES) break
            val rel = f.relativeTo(base).path.replace(File.separatorChar, '/')
            arr.put(
                JSONObject().put("path", rel).put("dir", f.isDirectory)
                    .put("size", if (f.isFile) f.length() else 0L)
            )
        }
        return arr
    }

    fun readFile(project: String, rel: String): JSONObject {
        val f = resolveInside(project, rel)
        require(f.isFile) { "Ficheiro não encontrado." }
        val out = JSONObject()
        if (f.length() > MAX_TEXT_BYTES) return out.put("tooLarge", true).put("size", f.length())
        val bytes = f.readBytes()
        val probe = minOf(bytes.size, 8000)
        for (i in 0 until probe) {
            if (bytes[i].toInt() == 0) return out.put("binary", true).put("size", f.length())
        }
        return out.put("binary", false).put("text", String(bytes, Charsets.UTF_8))
    }

    fun readBase64(project: String, rel: String): JSONObject {
        val f = resolveInside(project, rel)
        require(f.isFile) { "Ficheiro não encontrado." }
        require(f.length() <= MAX_BASE64_BYTES) { "Ficheiro demasiado grande." }
        return JSONObject().put("data", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
    }

    fun writeFile(project: String, rel: String, content: String) {
        val f = resolveInside(project, rel)
        require(!f.isDirectory) { "O caminho é uma pasta." }
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".cvtmp")
        tmp.writeBytes(content.toByteArray(Charsets.UTF_8))
        if (!tmp.renameTo(f)) {
            f.writeBytes(content.toByteArray(Charsets.UTF_8))
            tmp.delete()
        }
        touch(project)
        try { sink?.onWrite(project, relOf(project, f), f) } catch (_: Exception) { }
    }

    fun writeFiles(project: String, json: String) {
        val o = JSONObject(json)
        for (k in o.keys()) writeFile(project, k, o.getString(k))
    }

    fun createFile(project: String, rel: String) {
        val f = resolveInside(project, rel)
        require(!f.exists()) { "Já existe um ficheiro ou pasta com esse nome." }
        f.parentFile?.mkdirs()
        require(f.createNewFile()) { "Não foi possível criar o ficheiro." }
        touch(project)
        try { sink?.onWrite(project, relOf(project, f), f) } catch (_: Exception) { }
    }

    fun mkdir(project: String, rel: String) {
        val f = resolveInside(project, rel)
        require(!f.exists()) { "Já existe um ficheiro ou pasta com esse nome." }
        require(f.mkdirs()) { "Não foi possível criar a pasta." }
        touch(project)
        try { sink?.onMkdir(project, relOf(project, f)) } catch (_: Exception) { }
    }

    fun delete(project: String, rel: String) {
        val f = resolveInside(project, rel)
        require(f.exists()) { "Não encontrado." }
        val relDel = relOf(project, f)
        require(f.deleteRecursively()) { "Não foi possível eliminar." }
        touch(project)
        try { sink?.onDelete(project, relDel) } catch (_: Exception) { }
    }

    fun rename(project: String, from: String, to: String) {
        val src = resolveInside(project, from)
        val dst = resolveInside(project, to)
        require(src.exists()) { "Não encontrado." }
        require(!dst.exists()) { "Já existe um ficheiro ou pasta com esse nome." }
        dst.parentFile?.mkdirs()
        val relFrom = relOf(project, src)
        require(src.renameTo(dst)) { "Não foi possível renomear." }
        touch(project)
        try { sink?.onRename(project, relFrom, relOf(project, dst)) } catch (_: Exception) { }
    }

    // ---------- ZIP ----------

    fun zipTo(project: String, out: OutputStream) {
        val base = projectDir(project).canonicalFile
        ZipOutputStream(out.buffered()).use { zos ->
            for (f in base.walkTopDown().onEnter { it == base || it.name != ".git" }) {
                if (f == base || f.name == ".git") continue
                val rel = f.relativeTo(base).path.replace(File.separatorChar, '/')
                if (f.isDirectory) {
                    zos.putNextEntry(ZipEntry("$rel/"))
                    zos.closeEntry()
                } else {
                    zos.putNextEntry(ZipEntry(rel))
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
    }

    private fun cleanZipName(raw: String): String? {
        val n = raw.replace('\\', '/').trimStart('/')
        if (n.isEmpty() || n.startsWith("__MACOSX/") || n.endsWith("/.DS_Store") || n == ".DS_Store") return null
        return n
    }

    /** Importa um ZIP para um projeto novo. [open] é chamado duas vezes (deteção de pasta raiz + extração). */
    fun importZip(displayName: String, open: () -> InputStream?): String {
        val name = uniqueName(displayName.removeSuffix(".zip").removeSuffix(".ZIP"))

        val names = ArrayList<String>()
        (open() ?: throw IllegalArgumentException("Não foi possível abrir o ficheiro.")).use { input ->
            ZipInputStream(input).use { zis ->
                while (true) {
                    val e = zis.nextEntry ?: break
                    cleanZipName(e.name)?.let { names.add(it) }
                    require(names.size <= MAX_ZIP_ENTRIES) { "ZIP com demasiados ficheiros (máx. $MAX_ZIP_ENTRIES)." }
                }
            }
        }
        require(names.isNotEmpty()) { "O ZIP está vazio." }

        val first = names.first().substringBefore('/')
        val strip = names.all { it.startsWith("$first/") }

        val dir = File(root, name)
        require(dir.mkdirs()) { "Não foi possível criar o projeto." }
        val base = dir.canonicalFile
        var total = 0L
        try {
            (open() ?: throw IllegalArgumentException("Não foi possível abrir o ficheiro.")).use { input ->
                ZipInputStream(input).use { zis ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val e = zis.nextEntry ?: break
                        var n = cleanZipName(e.name) ?: continue
                        if (strip) n = n.removePrefix("$first/")
                        if (n.isEmpty()) continue
                        val target = File(base, n).canonicalFile
                        require(target.path.startsWith(base.path + File.separator)) { "ZIP com caminho inseguro." }
                        if (e.isDirectory) {
                            target.mkdirs()
                        } else {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { os ->
                                while (true) {
                                    val r = zis.read(buf)
                                    if (r < 0) break
                                    total += r
                                    require(total <= MAX_ZIP_TOTAL_BYTES) { "ZIP demasiado grande (máx. 150 MB)." }
                                    os.write(buf, 0, r)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
        return name
    }
}
