package com.codeverse.mobile

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.api.CreateBranchCommand
import org.eclipse.jgit.api.ListBranchCommand
import org.eclipse.jgit.api.MergeResult
import org.eclipse.jgit.api.errors.CheckoutConflictException
import org.eclipse.jgit.api.errors.NoHeadException
import org.eclipse.jgit.diff.DiffEntry
import org.eclipse.jgit.lib.BranchTrackingStatus
import org.eclipse.jgit.lib.ProgressMonitor
import org.eclipse.jgit.lib.ObjectId
import org.eclipse.jgit.lib.PersonIdent
import org.eclipse.jgit.lib.Repository
import org.eclipse.jgit.lib.RepositoryState
import org.eclipse.jgit.revwalk.RevWalk
import org.eclipse.jgit.transport.CredentialsProvider
import org.eclipse.jgit.transport.RemoteRefUpdate
import org.eclipse.jgit.transport.RefSpec
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider
import org.eclipse.jgit.treewalk.AbstractTreeIterator
import org.eclipse.jgit.treewalk.CanonicalTreeParser
import org.eclipse.jgit.treewalk.EmptyTreeIterator
import org.eclipse.jgit.treewalk.filter.PathFilter
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Erro "esperado" (mensagem já pronta para o utilizador), com um código opcional para a interface reagir. */
class GitUserError(message: String, val code: String? = null) : Exception(message)

/**
 * Integração com Git/GitHub (JGit). Todas as operações pesadas correm em segundo plano e devolvem o
 * resultado por CV_onNative({type:'git', id, op, ok, ...}). O token do GitHub fica só no lado nativo
 * (EncryptedSharedPreferences) e só é enviado a endereços https://github.com.
 */
class GitService(
    private val ctx: Context,
    private val store: ProjectStore,
    private val ext: ExternalStorage,
    private val emit: (JSONObject) -> Unit
) {
    companion object {
        private const val UA = "CodeVerse-Mobile"
        private const val MAX_DIFF = 200_000
    }

    private val pool = Executors.newCachedThreadPool()
    private val cancels = ConcurrentHashMap<String, AtomicBoolean>()
    private val locks = ConcurrentHashMap<String, Any>()
    private val prefs: SharedPreferences = openPrefs()

    init {
        // O JGit procura ~/.gitconfig; no Android não há "home" válida.
        val home = System.getProperty("user.home")
        if (home.isNullOrEmpty() || home == "/") System.setProperty("user.home", ctx.filesDir.absolutePath)
    }

    private fun openPrefs(): SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "cv_git_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        ctx.getSharedPreferences("cv_git", Context.MODE_PRIVATE)
    }

    // ---------------------------------------------------------------- conta / identidade

    private fun token(): String? = prefs.getString("token", null)?.takeIf { it.isNotBlank() }
    private fun clientId(): String = prefs.getString("client_id", "") ?: ""

    private fun identity(): Pair<String, String> {
        val n = prefs.getString("id_name", null)?.takeIf { it.isNotBlank() } ?: prefs.getString("auth_name", "") ?: ""
        val e = prefs.getString("id_email", null)?.takeIf { it.isNotBlank() } ?: prefs.getString("auth_email", "") ?: ""
        return n to e
    }

    fun authInfo(): JSONObject {
        val (n, e) = identity()
        return JSONObject()
            .put("loggedIn", token() != null)
            .put("login", prefs.getString("login", "") ?: "")
            .put("name", n).put("email", e)
            .put("hasClientId", clientId().isNotEmpty())
            .put("clientId", clientId())
    }

    fun logout() {
        prefs.edit().remove("token").remove("login").remove("auth_name").remove("auth_email").apply()
    }

    fun setIdentity(name: String, email: String) {
        require(name.isNotBlank() && email.contains('@')) { "Indica um nome e um email válidos." }
        prefs.edit().putString("id_name", name.trim()).putString("id_email", email.trim()).apply()
    }

    fun setClientId(id: String) {
        prefs.edit().putString("client_id", id.trim()).apply()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val u = URL(url)
        require(u.protocol == "https") { "Só são permitidos endereços https." }
        val c = u.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", UA)
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val st = c.responseCode
            val stream = if (st in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return st to text
        } finally {
            c.disconnect()
        }
    }

    private fun apiHeaders(tk: String) = mapOf(
        "Authorization" to "Bearer $tk",
        "Accept" to "application/vnd.github+json",
        "X-GitHub-Api-Version" to "2022-11-28"
    )

    /** Valida o token no GitHub e guarda a sessão (login, nome, email). */
    private fun loginWithToken(tk: String): JSONObject {
        val t = tk.trim()
        if (t.isEmpty()) throw GitUserError("Cola o token de acesso.")
        val (st, body) = http("GET", "https://api.github.com/user", apiHeaders(t), null)
        if (st == 401) throw GitUserError("Token inválido ou expirado.")
        if (st !in 200..299) throw GitUserError("O GitHub respondeu com o código $st.")
        val j = JSONObject(body)
        val login = j.getString("login")
        val name = j.optString("name", "").ifBlank { login }
        var email = j.optString("email", "")
        if (email.isBlank() || email == "null") email = "${j.getLong("id")}+$login@users.noreply.github.com"
        prefs.edit().putString("token", t).putString("login", login)
            .putString("auth_name", name).putString("auth_email", email).apply()
        return authInfo()
    }

    /** Fluxo de dispositivo (OAuth Device Flow): mostra um código, o utilizador autoriza no navegador. */
    private fun deviceFlow(id: String): JSONObject {
        val cid = clientId()
        if (cid.isEmpty()) throw GitUserError("Falta o Client ID da OAuth App do GitHub.", "need_client_id")
        val flag = cancels[id]
        val form = mapOf("Accept" to "application/json", "Content-Type" to "application/x-www-form-urlencoded")
        val (_, b0) = http("POST", "https://github.com/login/device/code", form, "client_id=${enc(cid)}&scope=repo")
        val j = JSONObject(b0)
        if (j.has("error")) throw GitUserError(j.optString("error_description", j.getString("error")))
        val device = j.getString("device_code")
        var interval = j.optInt("interval", 5).coerceAtLeast(1)
        val deadline = System.currentTimeMillis() + j.optInt("expires_in", 900) * 1000L
        emit(JSONObject().put("type", "git").put("id", id).put("op", "device").put("phase", "code")
            .put("user_code", j.getString("user_code")).put("uri", j.getString("verification_uri")))
        while (flag?.get() != true && System.currentTimeMillis() < deadline) {
            Thread.sleep(interval * 1000L)
            if (flag?.get() == true) break
            val (_, b) = http("POST", "https://github.com/login/oauth/access_token", form,
                "client_id=${enc(cid)}&device_code=${enc(device)}&grant_type=${enc("urn:ietf:params:oauth:grant-type:device_code")}")
            val r = JSONObject(b)
            when (val err = r.optString("error", "")) {
                "" -> return loginWithToken(r.getString("access_token"))
                "authorization_pending" -> {}
                "slow_down" -> interval = r.optInt("interval", interval + 5)
                "expired_token" -> throw GitUserError("O código expirou. Tenta de novo.")
                "access_denied" -> throw GitUserError("O pedido foi recusado no GitHub.")
                else -> throw GitUserError(r.optString("error_description", err))
            }
        }
        throw GitUserError(if (flag?.get() == true) "Cancelado." else "O código expirou. Tenta de novo.")
    }

    /** Lista os repositórios do utilizador (para escolher o que clonar). */
    private fun repos(): JSONObject {
        val tk = token() ?: throw GitUserError("Entra no GitHub primeiro.", "need_login")
        val (st, body) = http("GET",
            "https://api.github.com/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member",
            apiHeaders(tk), null)
        if (st == 401) { logout(); throw GitUserError("A sessão expirou. Entra de novo.", "need_login") }
        if (st !in 200..299) throw GitUserError("O GitHub respondeu com o código $st.")
        val arr = JSONArray(body)
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            out.put(JSONObject().put("name", r.getString("full_name")).put("private", r.optBoolean("private"))
                .put("desc", r.optString("description", "").let { if (it == "null") "" else it })
                .put("url", r.getString("clone_url")))
        }
        return JSONObject().put("repos", out)
    }

    // ---------------------------------------------------------------- execução assíncrona

    fun cancel(id: String) { cancels[id]?.set(true) }

    private fun lockFor(project: String) = locks.getOrPut(project) { Any() }

    fun run(id: String, op: String, project: String, args: JSONObject) {
        cancels[id] = AtomicBoolean(false)
        pool.execute {
            val out = JSONObject().put("type", "git").put("id", id).put("op", op).put("phase", "done")
            try {
                val needsLock = project.isNotEmpty() && op != "device"
                val r = if (needsLock) synchronized(lockFor(project)) { dispatch(id, op, project, args) } else dispatch(id, op, project, args)
                for (k in r.keys()) out.put(k, r.get(k))
                out.put("ok", true)
            } catch (e: GitUserError) {
                out.put("ok", false).put("error", e.message ?: "Erro").put("code", e.code ?: "")
            } catch (e: Throwable) {
                out.put("ok", false).put("error", friendly(e))
            } finally {
                cancels.remove(id)
            }
            emit(out)
        }
    }

    private fun dispatch(id: String, op: String, project: String, a: JSONObject): JSONObject = when (op) {
        "login" -> loginWithToken(a.getString("token"))
        "device" -> deviceFlow(id)
        "repos" -> repos()
        "clone" -> clone(id, a.getString("url"), a.optString("name", ""))
        "status" -> status(project)
        "init" -> initRepo(project)
        "stage" -> stage(project, a)
        "unstage" -> unstage(project, a.getJSONArray("paths"))
        "discard" -> discard(project, a.getJSONArray("items"))
        "commit" -> commit(project, a.optString("message", ""), a.optBoolean("amend", false))
        "push" -> push(id, project)
        "pull" -> pull(id, project)
        "branches" -> branches(project)
        "checkout" -> checkout(project, a.getString("name"), a.optBoolean("create", false))
        "log" -> log(project, a.optInt("max", 30))
        "diff" -> diff(project, a.getString("path"), a.optBoolean("staged", false), a.optString("s", "M"))
        "remote" -> setRemote(project, a.getString("url"))
        "createRepo" -> createRepo(project, a.getString("name").trim(), a.optBoolean("private", true))
        else -> throw GitUserError("Operação desconhecida: $op")
    }

    private fun friendly(e: Throwable): String {
        val m = (e.message ?: e.javaClass.simpleName)
        val l = m.lowercase()
        return when {
            e is CheckoutConflictException ->
                "Há alterações locais que seriam substituídas (${e.conflictingPaths.take(3).joinToString(", ")}). Faz commit ou descarta-as primeiro."
            "not authorized" in l || "authentication is required" in l || "auth" in l && "fail" in l || "401" in l ->
                "Autenticação recusada. Entra no GitHub com um token que tenha permissão “repo”."
            "403" in l -> "O GitHub recusou o acesso (403). Confirma as permissões do token."
            "not found" in l || "404" in l || "repository not found" in l ->
                "Repositório não encontrado. Se for privado, entra no GitHub."
            "unknownhost" in l || "unable to resolve" in l || "failed to connect" in l || "timeout" in l || "timed out" in l ->
                "Sem ligação à internet (ou o GitHub não respondeu)."
            "cancel" in l -> "Cancelado."
            e is OutOfMemoryError -> "Memória insuficiente para esta operação (repositório muito grande)."
            else -> m
        }
    }

    // ---------------------------------------------------------------- utilitários Git

    private fun dirOf(project: String): File = store.dirOf(project)

    private fun isRepo(dir: File) = File(dir, ".git").exists()

    private fun openGit(project: String): Git {
        val dir = dirOf(project)
        if (!isRepo(dir)) throw GitUserError("Este projeto ainda não é um repositório Git.", "not_repo")
        return Git.open(dir)
    }

    private fun safePath(p: String): String {
        val n = p.replace('\\', '/').trimStart('/')
        require(n.isNotEmpty() && n.split('/').none { it == ".." || it == ".git" }) { "Caminho inválido." }
        return n
    }

    private fun hostOf(url: String?): String? = try { URI(url ?: "").host } catch (_: Exception) { null }

    /** Só envia o token para github.com (nunca para outros servidores). */
    private fun creds(url: String?): CredentialsProvider? {
        val tk = token() ?: return null
        if (!"github.com".equals(hostOf(url), ignoreCase = true)) return null
        val user = prefs.getString("login", "")?.ifBlank { null } ?: "x-access-token"
        return UsernamePasswordCredentialsProvider(user, tk)
    }

    private fun requireAuthFor(url: String) {
        if ("github.com".equals(hostOf(url), ignoreCase = true) && token() == null)
            throw GitUserError("Entra no GitHub para enviar/receber alterações.", "need_login")
    }

    private fun normalizeUrl(raw: String): String {
        var s = raw.trim()
        if (Regex("^[\\w.-]+/[\\w.-]+$").matches(s)) s = "https://github.com/$s"
        if (s.startsWith("git@github.com:")) s = "https://github.com/" + s.removePrefix("git@github.com:")
        if (!s.startsWith("https://")) throw GitUserError("Usa um endereço https (ou “dono/repositório”).")
        val host = hostOf(s) ?: throw GitUserError("Endereço inválido.")
        if (s.substringAfter("https://").substringBefore('/').contains('@'))
            throw GitUserError("Não coloques o token no endereço; usa “Entrar no GitHub”.")
        if (host.isBlank()) throw GitUserError("Endereço inválido.")
        s = s.trimEnd('/')
        if ("github.com".equals(host, true) && !s.endsWith(".git")) s += ".git"
        return s
    }

    private inner class Progress(val id: String, val label: String) : ProgressMonitor {
        private var title = ""
        private var total = 0
        private var done = 0
        private var last = 0L
        override fun start(totalTasks: Int) {}
        override fun beginTask(t: String?, totalWork: Int) { title = t ?: ""; total = totalWork; done = 0; send(true) }
        override fun update(completed: Int) { done += completed; send(false) }
        override fun endTask() { send(true) }
        override fun isCancelled(): Boolean = cancels[id]?.get() == true
        private fun send(force: Boolean) {
            val now = System.currentTimeMillis()
            if (!force && now - last < 250) return
            last = now
            val pct = if (total > 0) " · ${(done * 100L / total).coerceAtMost(100)}%" else ""
            emit(JSONObject().put("type", "git").put("id", id).put("phase", "progress").put("text", "$label · $title$pct"))
        }
    }

    private fun headId(repo: Repository): ObjectId? = try { repo.resolve("HEAD") } catch (_: Exception) { null }

    /** Ficheiros alterados/removidos entre dois commits (para espelhar no armazenamento do telemóvel). */
    private fun changedBetween(g: Git, old: ObjectId?, new: ObjectId?): Pair<List<String>, List<String>> {
        if (new == null || new == old) return emptyList<String>() to emptyList()
        val repo = g.repository
        val write = ArrayList<String>()
        val del = ArrayList<String>()
        repo.newObjectReader().use { reader ->
            RevWalk(repo).use { rw ->
                fun tree(id: ObjectId?): AbstractTreeIterator {
                    if (id == null) return EmptyTreeIterator()
                    val p = CanonicalTreeParser()
                    p.reset(reader, rw.parseCommit(id).tree.id)
                    return p
                }
                val diffs = g.diff().setOldTree(tree(old)).setNewTree(tree(new)).call()
                for (d in diffs) {
                    when (d.changeType) {
                        DiffEntry.ChangeType.DELETE -> del.add(d.oldPath)
                        DiffEntry.ChangeType.RENAME -> { del.add(d.oldPath); write.add(d.newPath) }
                        else -> write.add(d.newPath)
                    }
                }
            }
        }
        return write to del
    }

    private fun mirror(project: String, write: Collection<String>, del: Collection<String>) {
        try { ext.mirror(project, write, del) } catch (_: Exception) { }
    }

    // ---------------------------------------------------------------- operações

    private fun initRepo(project: String): JSONObject {
        val dir = dirOf(project)
        if (!isRepo(dir)) {
            Git.init().setDirectory(dir).setInitialBranch("main").call().close()
            val gi = File(dir, ".gitignore")
            if (!gi.exists()) {
                gi.writeText("node_modules/\nbuild/\n.gradle/\n.dart_tool/\n__pycache__/\n*.class\n*.cvtmp\n.DS_Store\n")
                mirror(project, listOf(".gitignore"), emptyList())
            }
        }
        return status(project)
    }

    private fun status(project: String): JSONObject {
        val dir = dirOf(project)
        if (!isRepo(dir)) return JSONObject().put("repo", false)
        Git.open(dir).use { g ->
            val repo = g.repository
            val st = g.status().call()
            val staged = JSONArray()
            val changes = JSONArray()
            fun add(arr: JSONArray, p: String, s: String) { arr.put(JSONObject().put("path", p).put("s", s)) }
            val conflicts = st.conflicting.toSortedSet()
            conflicts.forEach { add(changes, it, "C") }
            st.added.sorted().forEach { add(staged, it, "A") }
            st.changed.sorted().forEach { add(staged, it, "M") }
            st.removed.sorted().forEach { add(staged, it, "D") }
            st.modified.sorted().filter { it !in conflicts }.forEach { add(changes, it, "M") }
            st.missing.sorted().filter { it !in conflicts }.forEach { add(changes, it, "D") }
            st.untracked.sorted().filter { !it.endsWith(".cvtmp") }.forEach { add(changes, it, "U") }

            val full = repo.fullBranch ?: ""
            val attached = full.startsWith("refs/heads/")
            val branch = if (attached) repo.branch else (repo.branch ?: "").take(7)
            val out = JSONObject().put("repo", true).put("branch", branch).put("detached", !attached)
                .put("hasCommits", headId(repo) != null)
                .put("staged", staged).put("changes", changes)
                .put("merging", repo.repositoryState != RepositoryState.SAFE)
                .put("remote", repo.config.getString("remote", "origin", "url") ?: "")
            if (attached) {
                try {
                    val bt = BranchTrackingStatus.of(repo, repo.branch)
                    if (bt != null) out.put("ahead", bt.aheadCount).put("behind", bt.behindCount).put("upstream", Repository.shortenRefName(bt.remoteTrackingBranch))
                } catch (_: Exception) { }
            }
            return out
        }
    }

    private fun stage(project: String, a: JSONObject): JSONObject {
        openGit(project).use { g ->
            val dir = dirOf(project)
            if (a.optBoolean("all", false)) {
                g.add().addFilepattern(".").call()
                g.add().setUpdate(true).addFilepattern(".").call()
            } else {
                val paths = a.getJSONArray("paths")
                for (i in 0 until paths.length()) {
                    val p = safePath(paths.getString(i))
                    if (File(dir, p).exists()) g.add().addFilepattern(p).call()
                    else g.rm().setCached(true).addFilepattern(p).call()
                }
            }
        }
        return JSONObject()
    }

    private fun unstage(project: String, paths: JSONArray): JSONObject {
        openGit(project).use { g ->
            val hasHead = headId(g.repository) != null
            for (i in 0 until paths.length()) {
                val p = safePath(paths.getString(i))
                if (hasHead) g.reset().addPath(p).call()
                else g.rm().setCached(true).addFilepattern(p).call()
            }
        }
        return JSONObject()
    }

    private fun discard(project: String, items: JSONArray): JSONObject {
        openGit(project).use { g ->
            val restored = ArrayList<String>()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val p = safePath(item.getString("path"))
                if (item.optString("s") == "U") {
                    if (File(dirOf(project), p).exists()) store.delete(project, p)
                } else {
                    g.checkout().addPath(p).call()
                    restored.add(p)
                }
            }
            mirror(project, restored, emptyList())
        }
        return JSONObject()
    }

    private fun commit(project: String, message: String, amend: Boolean): JSONObject {
        openGit(project).use { g ->
            val repo = g.repository
            val (n, e) = identity()
            if (n.isBlank() || e.isBlank()) throw GitUserError("Define o teu nome e email para os commits.", "need_identity")
            val st = g.status().call()
            if (st.conflicting.isNotEmpty()) throw GitUserError("Há conflitos por resolver. Edita os ficheiros e faz stage deles.")
            val hasStaged = st.added.isNotEmpty() || st.changed.isNotEmpty() || st.removed.isNotEmpty()
            if (!hasStaged && !amend && repo.repositoryState == RepositoryState.SAFE)
                throw GitUserError("Não há nada em stage. Toca em “+” nos ficheiros alterados.")
            if (message.isBlank() && !amend) throw GitUserError("Escreve uma mensagem para o commit.")
            val who = PersonIdent(n, e)
            val cmd = g.commit().setAuthor(who).setCommitter(who).setAmend(amend)
            if (message.isNotBlank()) cmd.setMessage(message.trim())
            val rev = cmd.call()
            return JSONObject().put("id", rev.name.take(7)).put("summary", rev.shortMessage)
        }
    }

    private fun attachedBranch(repo: Repository): String {
        val full = repo.fullBranch ?: ""
        if (!full.startsWith("refs/heads/")) throw GitUserError("Estás num commit solto (HEAD desligado). Muda para uma branch primeiro.")
        return repo.branch
    }

    private fun remoteUrl(repo: Repository): String =
        repo.config.getString("remote", "origin", "url")?.takeIf { it.isNotBlank() }
            ?: throw GitUserError("Ainda não há repositório remoto. Define o endereço do GitHub.", "need_remote")

    private fun push(id: String, project: String): JSONObject {
        openGit(project).use { g ->
            val repo = g.repository
            val branch = attachedBranch(repo)
            if (headId(repo) == null) throw GitUserError("Ainda não há commits para enviar.")
            val url = remoteUrl(repo)
            requireAuthFor(url)
            val results = g.push().setRemote("origin")
                .setRefSpecs(RefSpec("refs/heads/$branch:refs/heads/$branch"))
                .setCredentialsProvider(creds(url)).setProgressMonitor(Progress(id, "A enviar"))
                .setTimeout(60).call()
            var upToDate = true
            for (r in results) for (u in r.remoteUpdates) {
                when (u.status) {
                    RemoteRefUpdate.Status.OK -> upToDate = false
                    RemoteRefUpdate.Status.UP_TO_DATE -> {}
                    RemoteRefUpdate.Status.REJECTED_NONFASTFORWARD, RemoteRefUpdate.Status.REJECTED_REMOTE_CHANGED ->
                        throw GitUserError("O remoto tem commits que não tens. Faz pull primeiro.")
                    else -> throw GitUserError("O envio foi recusado: ${u.message ?: u.status}")
                }
            }
            val cfg = repo.config
            if (cfg.getString("branch", branch, "remote") == null) {
                cfg.setString("branch", branch, "remote", "origin")
                cfg.setString("branch", branch, "merge", "refs/heads/$branch")
                cfg.save()
            }
            return JSONObject().put("upToDate", upToDate).put("branch", branch)
        }
    }

    private fun pull(id: String, project: String): JSONObject {
        openGit(project).use { g ->
            val repo = g.repository
            val branch = attachedBranch(repo)
            val url = remoteUrl(repo)
            requireAuthFor(url)
            val cfg = repo.config
            if (cfg.getString("branch", branch, "remote") == null) {
                cfg.setString("branch", branch, "remote", "origin")
                cfg.setString("branch", branch, "merge", "refs/heads/$branch")
                cfg.save()
            }
            val before = headId(repo)
            val res = try {
                g.pull().setCredentialsProvider(creds(url)).setProgressMonitor(Progress(id, "A receber")).setTimeout(60).call()
            } catch (e: org.eclipse.jgit.api.errors.TransportException) {
                if ((e.message ?: "").contains("advertised", true) || (e.message ?: "").contains("Couldn't find remote ref", true))
                    throw GitUserError("Esta branch ainda não existe no GitHub. Faz push primeiro.")
                throw e
            } catch (e: org.eclipse.jgit.api.errors.RefNotAdvertisedException) {
                throw GitUserError("Esta branch ainda não existe no GitHub. Faz push primeiro.")
            }
            val after = headId(repo)
            val (w, d) = changedBetween(g, before, after)
            val merge = res.mergeResult
            val status = merge?.mergeStatus
            val out = JSONObject().put("upToDate", status == MergeResult.MergeStatus.ALREADY_UP_TO_DATE)
            if (merge != null && status == MergeResult.MergeStatus.CONFLICTING) {
                val names = merge.conflicts?.keys?.toList() ?: emptyList()
                mirror(project, w + names, d)
                return out.put("conflicts", JSONArray(names))
            }
            if (merge != null && status == MergeResult.MergeStatus.FAILED) {
                val bad = merge.failingPaths?.keys?.take(3)?.joinToString(", ") ?: "ficheiros"
                throw GitUserError("Não foi possível juntar: há alterações locais em $bad. Faz commit ou descarta-as.")
            }
            mirror(project, w, d)
            return out.put("changed", w.size + d.size)
        }
    }

    private fun clone(id: String, rawUrl: String, wantedName: String): JSONObject {
        val url = normalizeUrl(rawUrl)
        val repoName = url.trimEnd('/').removeSuffix(".git").substringAfterLast('/')
        val project = store.newProjectName(wantedName.ifBlank { repoName })
        try {
            Git.cloneRepository().setURI(url).setDirectory(dirOf(project))
                .setCredentialsProvider(creds(url)).setProgressMonitor(Progress(id, "A clonar"))
                .setTimeout(60).call().close()
        } catch (e: Throwable) {
            try { store.deleteProject(project) } catch (_: Exception) { }
            throw e
        }
        return JSONObject().put("project", project)
    }

    private fun branches(project: String): JSONObject {
        openGit(project).use { g ->
            val repo = g.repository
            val local = g.branchList().call().map { Repository.shortenRefName(it.name) }.sorted()
            val remote = g.branchList().setListMode(ListBranchCommand.ListMode.REMOTE).call()
                .map { Repository.shortenRefName(it.name) }
                .filter { !it.endsWith("/HEAD") }
                .map { it.substringAfter('/') }
                .filter { it !in local }.distinct().sorted()
            val full = repo.fullBranch ?: ""
            return JSONObject().put("current", if (full.startsWith("refs/heads/")) repo.branch else "")
                .put("local", JSONArray(local)).put("remote", JSONArray(remote))
        }
    }

    private fun checkout(project: String, name: String, create: Boolean): JSONObject {
        require(Repository.isValidRefName("refs/heads/$name")) { "Nome de branch inválido." }
        openGit(project).use { g ->
            val repo = g.repository
            val before = headId(repo)
            val existsLocal = repo.findRef("refs/heads/$name") != null
            val cmd = g.checkout().setName(name)
            if (create) {
                if (existsLocal) throw GitUserError("Já existe uma branch com esse nome.")
                if (before == null) throw GitUserError("Faz primeiro um commit para poderes criar branches.")
                cmd.setCreateBranch(true)
            } else if (!existsLocal) {
                if (repo.findRef("refs/remotes/origin/$name") == null) throw GitUserError("A branch “$name” não existe.")
                cmd.setCreateBranch(true).setStartPoint("origin/$name")
                    .setUpstreamMode(CreateBranchCommand.SetupUpstreamMode.TRACK)
            }
            cmd.call()
            val (w, d) = changedBetween(g, before, headId(repo))
            mirror(project, w, d)
            return JSONObject().put("branch", name)
        }
    }

    private fun log(project: String, max: Int): JSONObject {
        openGit(project).use { g ->
            val arr = JSONArray()
            if (headId(g.repository) != null) {
                try {
                    for (c in g.log().setMaxCount(max.coerceIn(1, 100)).call()) {
                        arr.put(JSONObject().put("id", c.name.take(7)).put("msg", c.shortMessage)
                            .put("author", c.authorIdent.name).put("time", c.commitTime * 1000L))
                    }
                } catch (_: NoHeadException) { }
            }
            return JSONObject().put("commits", arr)
        }
    }

    private fun diff(project: String, path: String, staged: Boolean, s: String): JSONObject {
        val p = safePath(path)
        val dir = dirOf(project)
        fun asNew(): JSONObject {
            val f = File(dir, p)
            if (!f.isFile) return JSONObject().put("text", "")
            if (f.length() > MAX_DIFF) return JSONObject().put("text", "(ficheiro demasiado grande para mostrar)")
            val bytes = f.readBytes()
            if (bytes.take(8000).any { it.toInt() == 0 }) return JSONObject().put("text", "(ficheiro binário)")
            val body = String(bytes, Charsets.UTF_8).lines().joinToString("\n") { "+$it" }
            return JSONObject().put("text", "novo ficheiro: $p\n$body")
        }
        if (s == "U") return asNew()
        openGit(project).use { g ->
            val out = ByteArrayOutputStream()
            try {
                g.diff().setOutputStream(out).setCached(staged).setPathFilter(PathFilter.create(p)).setContextLines(3).call()
            } catch (_: NoHeadException) {
                return asNew()
            }
            var text = out.toString("UTF-8")
            if (text.length > MAX_DIFF) text = text.take(MAX_DIFF) + "\n… (cortado)"
            if (text.isBlank()) text = "(sem diferenças de texto)"
            return JSONObject().put("text", text)
        }
    }

    private fun setRemote(project: String, rawUrl: String): JSONObject {
        val url = normalizeUrl(rawUrl)
        openGit(project).use { g ->
            val cfg = g.repository.config
            cfg.setString("remote", "origin", "url", url)
            cfg.setString("remote", "origin", "fetch", "+refs/heads/*:refs/remotes/origin/*")
            cfg.save()
        }
        return JSONObject().put("remote", url)
    }

    /** Cria um repositório novo (vazio) na conta do utilizador e liga-o como "origin". */
    private fun createRepo(project: String, name: String, isPrivate: Boolean): JSONObject {
        val tk = token() ?: throw GitUserError("Entra no GitHub primeiro.", "need_login")
        if (!Regex("^[A-Za-z0-9._-]{1,100}$").matches(name))
            throw GitUserError("Nome inválido: usa letras, números, ponto, _ e -.")
        val body = JSONObject().put("name", name).put("private", isPrivate).toString()
        val (st, resp) = http("POST", "https://api.github.com/user/repos",
            apiHeaders(tk) + ("Content-Type" to "application/json"), body)
        if (st == 422) throw GitUserError("Já existe um repositório com esse nome na tua conta.")
        if (st == 401 || st == 403) throw GitUserError("O token não tem permissão para criar repositórios (precisa de “repo”).")
        if (st !in 200..299) throw GitUserError("O GitHub respondeu com o código $st.")
        return setRemote(project, JSONObject(resp).getString("clone_url"))
    }
}
