package com.codeverse.mobile

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.os.CancellationSignal
import android.util.Base64
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.gms.tasks.Tasks
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest
import java.util.Date
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Conta (Firebase Authentication) + sincronização de projetos (Cloud Firestore).
 *
 * Modelo de dados (tudo por utilizador; as regras em firestore.rules só deixam o dono aceder):
 *   users/{uid}/projects/{projectId}                 -> { name, deleted, createdAt, updatedAt, device }
 *   users/{uid}/projects/{projectId}/files/{sha1(path)} -> { path, dir, deleted, enc("t"|"b"), content, size, hash, updatedAt, device }
 *
 * Algoritmo: para cada projeto guardamos localmente o estado da última sincronização (hash de cada ficheiro).
 * Isso permite saber o que mudou localmente e o que mudou na nuvem. Primeiro puxa-se (só os documentos
 * alterados desde a última vez), depois envia-se. Se o mesmo ficheiro mudou nos dois lados, a versão da nuvem
 * é guardada ao lado como "nome (nuvem).ext" — nunca se perde nada. Apagar ficheiros na nuvem é "soft": o documento
 * fica marcado como apagado e conserva o conteúdo.
 *
 * Tudo o que mexe no estado corre numa única thread ([worker]). Sem rede, o editor continua a funcionar
 * normalmente com os ficheiros locais e a sincronização é retomada quando a rede volta.
 */
class CloudService(
    private val activity: Activity,
    private val store: ProjectStore,
    private val emitJson: (JSONObject) -> Unit
) : ProjectStore.SyncSink {

    companion object {
        private const val TAG = "CodeVerseCloud"
        private const val MAX_FILE_BYTES = 700_000      // 700 KB (em base64 cabe no limite de 1 MiB por documento)
        private const val MAX_FILES = 3000
        private const val PAGE = 30L
        private const val BATCH_OPS = 100
        private const val BATCH_BYTES = 3_000_000
        private const val TIMEOUT_S = 60L
        private const val DEBOUNCE_S = 4L
    }

    private val ctx: Context = activity.applicationContext
    private val prefs = ctx.getSharedPreferences("cloud", Context.MODE_PRIVATE)

    /** Só é true se o google-services.json estava presente no build (o Firebase inicializou-se sozinho). */
    val available: Boolean = try { FirebaseApp.getApps(ctx).isNotEmpty() } catch (_: Throwable) { false }

    private val auth: FirebaseAuth? by lazy { if (available) FirebaseAuth.getInstance() else null }
    private val db: FirebaseFirestore? by lazy { if (available) FirebaseFirestore.getInstance() else null }

    private val worker = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "cv-cloud").apply { isDaemon = true } }
    private val debounce = ConcurrentHashMap<String, ScheduledFuture<*>>()
    private val fullQueued = AtomicBoolean(false)
    private val applying = ThreadLocal<Boolean>()

    private val deviceId: String = prefs.getString("device", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("device", it).apply() }

    // ----- estado (só a thread worker mexe em cs/uid/listener) -----
    private class FS(var h: String, var size: Long, var mtime: Long, var dir: Boolean)
    private class PS(var id: String, var lastPull: Long, val files: MutableMap<String, FS>)
    private class CS(val projects: MutableMap<String, PS>, val deletes: MutableList<String>)
    private class RP(val id: String, val name: String, val deleted: Boolean)
    private class Local(val dir: Boolean, val file: File?)
    private class Op(val path: String, val kind: Int, val hash: String = "", val dir: Boolean = false) // 0 = ficheiro, 1 = pasta, 2 = apagar

    private var cs: CS? = null
    private var uid: String? = null
    private var listener: ListenerRegistration? = null
    @Volatile private var signedIn = false
    @Volatile private var state = "idle"           // idle | syncing | offline | error
    @Volatile private var lastSync = 0L
    @Volatile private var lastError: String? = null
    @Volatile private var skipped = 0
    @Volatile private var lastFull = 0L

    fun autoSync(): Boolean = prefs.getBoolean("autosync", true)

    // =====================================================================================
    // Arranque
    // =====================================================================================

    fun start() {
        val a = auth ?: return
        a.addAuthStateListener { fa -> onAuthChanged(fa.currentUser) }
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (signedIn && autoSync() && (state == "offline" || state == "error")) scheduleFull(3)
                }
            })
        } catch (_: Exception) { /* sem monitorização de rede */ }
    }

    fun onResume() {
        if (signedIn && autoSync() && System.currentTimeMillis() - lastFull > 20_000) scheduleFull(1)
    }

    private fun onAuthChanged(user: FirebaseUser?) {
        worker.execute {
            try {
                if (user == null) {
                    detach()
                    emitState()
                    return@execute
                }
                if (uid == user.uid && cs != null) { emitState(); return@execute }
                detach()
                uid = user.uid
                signedIn = true
                cs = loadState(user.uid)
                attachListener(user.uid)
                emitState()
                if (autoSync()) fullSync()
            } catch (e: Throwable) {
                fail(e)
            }
        }
    }

    private fun detach() {
        try { listener?.remove() } catch (_: Exception) { }
        listener = null
        uid = null
        cs = null
        signedIn = false
        state = "idle"
        lastError = null
        debounce.values.forEach { it.cancel(false) }
        debounce.clear()
    }

    // =====================================================================================
    // Informação para a interface
    // =====================================================================================

    private fun webClientId(): String? {
        val id = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
        return if (id != 0) activity.getString(id).takeIf { it.isNotBlank() } else null
    }

    private fun userJson(u: FirebaseUser): JSONObject {
        val info = u.providerData.firstOrNull { it.providerId != "firebase" }
        val email = (u.email ?: info?.email)?.takeIf { it.isNotBlank() }
        val name = (u.displayName ?: info?.displayName)?.takeIf { it.isNotBlank() }
            ?: email?.substringBefore('@') ?: "Utilizador"
        return JSONObject()
            .put("uid", u.uid)
            .put("name", name)
            .put("email", email ?: JSONObject.NULL)
            .put("photo", (u.photoUrl ?: info?.photoUrl)?.toString() ?: JSONObject.NULL)
            .put("provider", info?.providerId ?: JSONObject.NULL)
    }

    fun info(): JSONObject {
        val o = JSONObject().put("available", available).put("autoSync", autoSync())
        if (!available) {
            return o.put("signedIn", false)
                .put("reason", "O Firebase não está configurado neste APK (falta o ficheiro app/google-services.json no build).")
        }
        val u = auth?.currentUser
        o.put("signedIn", u != null)
        if (u != null) o.put("user", userJson(u))
        o.put("google", webClientId() != null)
        o.put(
            "sync", JSONObject().put("state", state).put("last", lastSync)
                .put("error", lastError ?: JSONObject.NULL).put("skipped", skipped)
        )
        return o
    }

    private fun emitState() = emitJson(info().put("type", "auth").put("op", "state"))
    private fun emitChanged(names: Collection<String>) {
        if (names.isEmpty()) return
        emitJson(JSONObject().put("type", "cloud").put("op", "changed").put("projects", JSONArray(names.toList())))
    }

    // =====================================================================================
    // Autenticação
    // =====================================================================================

    fun signIn(provider: String) {
        val a = auth
        if (a == null) { signInResult(false, "O Firebase não está configurado neste APK."); return }
        when (provider) {
            "google" -> signInGoogle(a)
            "github" -> signInGithub(a)
            else -> signInResult(false, "Método de início de sessão desconhecido.")
        }
    }

    private fun signInResult(ok: Boolean, error: String? = null, cancelled: Boolean = false) {
        val o = info().put("type", "auth").put("op", "signin").put("ok", ok).put("cancelled", cancelled)
        if (error != null) o.put("error", error)
        emitJson(o)
    }

    private fun signInGoogle(a: FirebaseAuth) {
        val webId = webClientId()
        if (webId == null) {
            signInResult(false, "Google não configurado: ativa o Google em Authentication, adiciona o SHA-1/SHA-256 da app e volta a descarregar o google-services.json.")
            return
        }
        activity.runOnUiThread {
            try {
                val option = GetSignInWithGoogleOption.Builder(webId).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                CredentialManager.create(activity).getCredentialAsync(
                    activity, request, CancellationSignal(), ContextCompat.getMainExecutor(activity),
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val cred = result.credential
                            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                try {
                                    val g = GoogleIdTokenCredential.createFrom(cred.data)
                                    a.signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null))
                                        .addOnCompleteListener { t ->
                                            if (t.isSuccessful) signInResult(true) else authFailure(t.exception)
                                        }
                                } catch (e: Exception) {
                                    signInResult(false, "Resposta do Google inválida: " + (e.message ?: ""))
                                }
                            } else {
                                signInResult(false, "O Google devolveu um tipo de credencial inesperado.")
                            }
                        }

                        override fun onError(e: GetCredentialException) {
                            when (e) {
                                is GetCredentialCancellationException -> signInResult(false, cancelled = true)
                                is NoCredentialException -> signInResult(false, "Não há nenhuma conta Google neste telemóvel. Adiciona uma nas definições do Android e tenta de novo.")
                                else -> signInResult(false, "Falha no início de sessão com Google: " + (e.message ?: e.javaClass.simpleName))
                            }
                        }
                    }
                )
            } catch (e: Exception) {
                signInResult(false, "Não foi possível iniciar o Google: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun signInGithub(a: FirebaseAuth) {
        activity.runOnUiThread {
            try {
                val provider = OAuthProvider.newBuilder("github.com").setScopes(listOf("user:email")).build()
                a.startActivityForSignInWithProvider(activity, provider)
                    .addOnSuccessListener { signInResult(true) }
                    .addOnFailureListener { e -> authFailure(e) }
            } catch (e: Exception) {
                signInResult(false, "Não foi possível iniciar o GitHub: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun authFailure(e: Exception?) {
        val code = (e as? FirebaseAuthException)?.errorCode ?: ""
        when (code) {
            "ERROR_WEB_CONTEXT_CANCELED" -> signInResult(false, cancelled = true)
            "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" ->
                signInResult(false, "Já existe uma conta com este e-mail criada com outro método (Google ou GitHub). Entra com o método que usaste da primeira vez.")
            "ERROR_NETWORK_REQUEST_FAILED" -> signInResult(false, "Sem ligação à internet.")
            "ERROR_OPERATION_NOT_ALLOWED" -> signInResult(false, "Este método de início de sessão não está ativado na consola do Firebase (Authentication → Sign-in method).")
            "ERROR_USER_DISABLED" -> signInResult(false, "Esta conta foi desativada.")
            else -> {
                val msg = e?.message ?: "erro desconhecido"
                if (msg.contains("network", ignoreCase = true)) signInResult(false, "Sem ligação à internet.")
                else signInResult(false, "Falha no início de sessão: $msg")
            }
        }
    }

    /** Termina a sessão. Com [wipeLocal], apaga também deste telemóvel os projetos que estavam sincronizados com a conta. */
    fun signOut(wipeLocal: Boolean) {
        worker.execute {
            try {
                val c = cs
                val u = uid
                val names = c?.projects?.keys?.toList() ?: emptyList()
                detach()
                auth?.signOut()
                if (wipeLocal && u != null) {
                    applying.set(true)
                    try {
                        for (n in names) try { store.deleteProject(n) } catch (_: Exception) { }
                    } finally { applying.set(false) }
                    stateFile(u).delete()
                }
                emitState()
                if (wipeLocal) emitChanged(names.ifEmpty { listOf("*") })
            } catch (e: Throwable) {
                fail(e)
            }
        }
    }

    fun setAutoSync(on: Boolean) {
        prefs.edit().putBoolean("autosync", on).apply()
        if (on && signedIn) scheduleFull(0)
        emitState()
    }

    fun syncNow() {
        if (signedIn) scheduleFull(0)
    }

    private fun scheduleFull(delaySec: Long) {
        if (!fullQueued.compareAndSet(false, true)) return
        worker.schedule(Runnable { fullQueued.set(false); fullSync() }, delaySec, TimeUnit.SECONDS)
    }

    // =====================================================================================
    // Persistência do estado local de sincronização (um ficheiro por utilizador)
    // =====================================================================================

    private fun stateDir() = File(ctx.filesDir, "cloud").apply { mkdirs() }
    private fun stateFile(u: String) = File(stateDir(), u.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".json")

    private fun loadState(u: String): CS {
        val cs = CS(HashMap(), ArrayList())
        try {
            val f = stateFile(u)
            if (!f.exists()) return cs
            val o = JSONObject(f.readText())
            val ps = o.optJSONObject("projects") ?: JSONObject()
            for (name in ps.keys()) {
                val p = ps.getJSONObject(name)
                val files = HashMap<String, FS>()
                val fo = p.optJSONObject("files") ?: JSONObject()
                for (path in fo.keys()) {
                    val e = fo.getJSONObject(path)
                    files[path] = FS(e.optString("h"), e.optLong("s"), e.optLong("m"), e.optBoolean("d"))
                }
                cs.projects[name] = PS(p.getString("id"), p.optLong("pull"), files)
            }
            val del = o.optJSONArray("deletes")
            if (del != null) for (i in 0 until del.length()) cs.deletes.add(del.getString(i))
        } catch (e: Exception) {
            Log.w(TAG, "estado ilegível, recomeça do zero: " + e.message)
        }
        return cs
    }

    private fun saveState() {
        val c = cs ?: return
        val u = uid ?: return
        try {
            val ps = JSONObject()
            for ((name, p) in c.projects) {
                val fo = JSONObject()
                for ((path, f) in p.files) fo.put(path, JSONObject().put("h", f.h).put("s", f.size).put("m", f.mtime).put("d", f.dir))
                ps.put(name, JSONObject().put("id", p.id).put("pull", p.lastPull).put("files", fo))
            }
            val o = JSONObject().put("projects", ps).put("deletes", JSONArray(c.deletes))
            val f = stateFile(u)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(f)) { f.writeText(o.toString()); tmp.delete() }
        } catch (e: Exception) {
            Log.w(TAG, "não foi possível guardar o estado: " + e.message)
        }
    }

    /** Projetos que já pertencem à sincronização de OUTRA conta neste telemóvel nunca são enviados para esta. */
    private fun ownedByOthers(name: String, me: String): Boolean {
        val mine = stateFile(me).name
        val files = stateDir().listFiles { f -> f.name.endsWith(".json") && f.name != mine } ?: return false
        for (f in files) {
            try {
                if (JSONObject(f.readText()).optJSONObject("projects")?.has(name) == true) return true
            } catch (_: Exception) { }
        }
        return false
    }

    // =====================================================================================
    // Referências Firestore
    // =====================================================================================

    private fun projectsCol(u: String) = db!!.collection("users").document(u).collection("projects")
    private fun filesCol(u: String, pid: String) = projectsCol(u).document(pid).collection("files")

    private fun <T> await(t: com.google.android.gms.tasks.Task<T>): T = Tasks.await(t, TIMEOUT_S, TimeUnit.SECONDS)

    // =====================================================================================
    // Sincronização completa (início de sessão, voltar à app, voltar a ter rede, pedido do utilizador)
    // =====================================================================================

    private fun fullSync() {
        val c = cs ?: return
        val u = uid ?: return
        lastFull = System.currentTimeMillis()
        setState("syncing")
        var firstErr: Throwable? = null
        val changed = LinkedHashSet<String>()
        try {
            retryPendingDeletes(u, c)
            val remote = ArrayList<RP>()
            for (d in await(projectsCol(u).get(Source.SERVER)).documents) {
                remote.add(RP(d.id, d.getString("name") ?: continue, d.getBoolean("deleted") == true))
            }
            val ids = remote.map { it.id }.toSet()
            // projetos que tinham ligação mas já não existem na nuvem: voltam a ser projetos locais novos
            for (n in c.projects.keys.toList()) if (c.projects[n]!!.id !in ids) c.projects.remove(n)

            for (rp in remote) {
                try { handleRemoteProject(u, c, rp, changed) } catch (e: Throwable) { if (firstErr == null) firstErr = e }
            }
            val listed = store.listProjects()
            for (i in 0 until listed.length()) {
                val n = listed.getJSONObject(i).getString("name")
                if (c.projects.containsKey(n) || !eligible(n, u)) continue
                try { mapNew(u, c, n); syncProject(u, c, n, changed) } catch (e: Throwable) { if (firstErr == null) firstErr = e }
            }
        } catch (e: Throwable) {
            firstErr = e
        }
        saveState()
        if (firstErr != null) fail(firstErr) else {
            lastSync = System.currentTimeMillis(); lastError = null; setState("idle")
        }
        emitChanged(changed)
    }

    private fun eligible(name: String, u: String) = name != ExternalStorage.LOOSE_PROJECT && !ownedByOthers(name, u)

    private fun mapNew(u: String, c: CS, name: String) {
        val id = UUID.randomUUID().toString()
        await(
            projectsCol(u).document(id).set(
                mapOf(
                    "name" to name, "deleted" to false, "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId
                ),
                SetOptions.merge()
            )
        )
        c.projects[name] = PS(id, 0L, HashMap())
        saveState()
    }

    /** Aplica o estado de um projeto da nuvem a este telemóvel. */
    private fun handleRemoteProject(u: String, c: CS, rp: RP, changed: MutableSet<String>) {
        val entry = c.projects.entries.firstOrNull { it.value.id == rp.id }
        if (entry == null) {
            if (rp.deleted) return
            applying.set(true)
            val name = try { store.newProjectName(rp.name) } finally { applying.set(false) }
            c.projects[name] = PS(rp.id, 0L, HashMap())
            changed.add(name)
            syncProject(u, c, name, changed)
            return
        }
        var name = entry.key
        val ps = entry.value
        if (rp.deleted) {
            if (isUnchangedLocally(name, ps)) {
                applying.set(true)
                try { store.deleteProject(name) } catch (_: Exception) { } finally { applying.set(false) }
                changed.add(name)
            }
            // se há alterações locais por enviar, o projeto fica no telemóvel como projeto novo (será reenviado)
            c.projects.remove(name)
            return
        }
        if (rp.name != name && !store.projectExists(rp.name)) {
            applying.set(true)
            try {
                store.renameProject(name, rp.name)
                c.projects.remove(name)
                c.projects[rp.name] = ps
                name = rp.name
                changed.add(name)
            } catch (_: Exception) { } finally { applying.set(false) }
        }
        syncProject(u, c, name, changed)
    }

    private fun retryPendingDeletes(u: String, c: CS) {
        val it = c.deletes.iterator()
        while (it.hasNext()) {
            val id = it.next()
            try {
                await(
                    projectsCol(u).document(id).set(
                        mapOf("deleted" to true, "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId),
                        SetOptions.merge()
                    )
                )
                it.remove()
            } catch (e: Throwable) {
                val cause = if (e is ExecutionException && e.cause != null) e.cause else e
                // sem permissão/inexistente: nada a fazer; sem rede: tenta mais tarde
                if (cause is FirebaseFirestoreException &&
                    (cause.code == FirebaseFirestoreException.Code.PERMISSION_DENIED || cause.code == FirebaseFirestoreException.Code.NOT_FOUND)
                ) it.remove()
            }
        }
        saveState()
    }

    // =====================================================================================
    // Sincronização de um projeto
    // =====================================================================================

    private fun syncProject(u: String, c: CS, name: String, changed: MutableSet<String>) {
        val ps = c.projects[name] ?: return
        applying.set(true)
        try {
            pull(u, name, ps, changed)
            push(u, name, ps)
        } finally {
            applying.set(false)
            saveState()
        }
    }

    private fun safeRel(p: String): Boolean {
        if (p.isEmpty() || p.length > 1000 || p.startsWith("/") || p.contains('\\')) return false
        val parts = p.split('/')
        if (parts.any { it.isEmpty() || it == "." || it == ".." }) return false
        if (parts.first() == ".git" || p.endsWith(".cvtmp")) return false
        return true
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun sha256(b: ByteArray) = hex(MessageDigest.getInstance("SHA-256").digest(b))
    private fun fid(path: String) = hex(MessageDigest.getInstance("SHA-1").digest(path.toByteArray(Charsets.UTF_8)))

    private fun localHash(f: File, base: FS?): String {
        if (base != null && !base.dir && base.size == f.length() && base.mtime == f.lastModified()) return base.h
        if (f.length() > 8_000_000) return "big:" + f.length() + ":" + f.lastModified()
        return sha256(f.readBytes())
    }

    private fun fsOf(f: File, h: String) = FS(h, f.length(), f.lastModified(), false)

    private fun encode(bytes: ByteArray): Pair<String, String> {
        if (bytes.none { it.toInt() == 0 }) {
            try {
                val s = Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString()
                return "t" to s
            } catch (_: CharacterCodingException) { }
        }
        return "b" to Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun decode(enc: String, content: String): ByteArray =
        if (enc == "b") Base64.decode(content, Base64.DEFAULT) else content.toByteArray(Charsets.UTF_8)

    private fun scanLocal(name: String): Pair<Map<String, Local>, Int> {
        val base = store.dirOf(name).canonicalFile
        val out = LinkedHashMap<String, Local>()
        var big = 0
        for (f in base.walkTopDown().onEnter { it == base || it.name != ".git" }) {
            if (f == base || f.name == ".git" || f.name.endsWith(".cvtmp")) continue
            if (out.size >= MAX_FILES) { big++; continue }
            val rel = f.relativeTo(base).path.replace(File.separatorChar, '/')
            if (f.isDirectory) out[rel] = Local(true, null)
            else if (f.length() > MAX_FILE_BYTES) big++
            else out[rel] = Local(false, f)
        }
        return out to big
    }

    private fun isUnchangedLocally(name: String, ps: PS): Boolean = try {
        val (entries, big) = scanLocal(name)
        var same = big == 0
        for ((path, l) in entries) {
            val b = ps.files[path]
            if (b == null) { same = false; break }
            if (!l.dir && localHash(l.file!!, b) != b.h) { same = false; break }
        }
        if (same) for (path in ps.files.keys) if (!entries.containsKey(path)) { same = false; break }
        same
    } catch (_: Exception) { false }

    // ----- puxar -----

    private fun pull(u: String, name: String, ps: PS, changed: MutableSet<String>) {
        var base: Query = filesCol(u, ps.id).orderBy("updatedAt")
        if (ps.lastPull > 0) base = base.whereGreaterThan("updatedAt", Timestamp(Date(maxOf(0L, ps.lastPull - 1500L))))
        var q = base.limit(PAGE)
        var maxTs = ps.lastPull
        var ioError = false
        val dirsDeleted = ArrayList<String>()
        while (true) {
            val docs = await(q.get(Source.SERVER)).documents
            for (doc in docs) {
                try { applyRemoteFile(name, ps, doc, changed, dirsDeleted) } catch (e: Exception) { ioError = true; Log.w(TAG, "falha a aplicar " + doc.getString("path") + ": " + e.message) }
                val ts = doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0L
                if (ts > maxTs) maxTs = ts
            }
            if (docs.size < PAGE) break
            q = base.startAfter(docs.last()).limit(PAGE)
        }
        if (!ioError) ps.lastPull = maxTs
        if (dirsDeleted.isNotEmpty()) {
            val root = store.dirOf(name)
            for (d in dirsDeleted.sortedByDescending { it.length }) try { File(root, d).delete() } catch (_: Exception) { } // só apaga se vazia
        }
    }

    private fun applyRemoteFile(name: String, ps: PS, doc: DocumentSnapshot, changed: MutableSet<String>, dirsDeleted: MutableList<String>) {
        val path = doc.getString("path") ?: return
        if (!safeRel(path)) return
        val deleted = doc.getBoolean("deleted") == true
        val isDir = doc.getBoolean("dir") == true
        val base = ps.files[path]
        val root = store.dirOf(name)
        val f = File(root, path)

        if (deleted) {
            if (isDir) { dirsDeleted.add(path); ps.files.remove(path); return }
            if (f.isFile && base != null && localHash(f, base) == base.h) {
                store.delete(name, path)   // sem alterações locais: segue a nuvem
                changed.add(name)
            }
            // com alterações locais: mantém o ficheiro (será enviado de novo)
            ps.files.remove(path)
            return
        }
        if (isDir) {
            if (!f.exists()) { f.mkdirs(); changed.add(name) }
            ps.files[path] = FS("", 0, 0, true)
            return
        }
        val rh = doc.getString("hash") ?: return
        val bytes = decode(doc.getString("enc") ?: "t", doc.getString("content") ?: "")
        if (sha256(bytes) != rh) { Log.w(TAG, "hash não coincide, ignorado: $path"); return }
        if (f.isDirectory) return

        if (f.isFile) {
            val lh = localHash(f, base)
            if (lh == rh) { ps.files[path] = fsOf(f, rh); return }
            // a nuvem tem a mesma versão que sincronizámos da última vez (por ex. o que acabámos de enviar):
            // só mudou aqui, no telemóvel. Não é conflito: o envio trata disso e NÃO se cria cópia "(nuvem)".
            if (base != null && base.h == rh) return
            if (base != null && lh == base.h) {          // só mudou na nuvem
                store.writeBytes(name, path, bytes)
                ps.files[path] = fsOf(f, rh)
                changed.add(name)
            } else {                                      // mudou nos dois lados: guarda a versão da nuvem ao lado
                store.writeBytes(name, conflictName(root, path), bytes)
                ps.files[path] = FS(rh, bytes.size.toLong(), 0, false)  // força o envio da versão local
                changed.add(name)
            }
        } else {
            if (base != null && base.h == rh) return      // apagado localmente desde a última vez: o envio trata do resto
            store.writeBytes(name, path, bytes)
            ps.files[path] = fsOf(f, rh)
            changed.add(name)
        }
    }

    private fun conflictName(root: File, path: String): String {
        val slash = path.lastIndexOf('/')
        val dot = path.lastIndexOf('.')
        val stem = if (dot > slash + 1) path.substring(0, dot) else path
        val ext = if (dot > slash + 1) path.substring(dot) else ""
        var cand = "$stem (nuvem)$ext"
        var i = 2
        while (File(root, cand).exists()) { cand = "$stem (nuvem $i)$ext"; i++ }
        return cand
    }

    // ----- enviar -----

    private fun push(u: String, name: String, ps: PS) {
        val (entries, big) = scanLocal(name)
        skipped = big
        val ops = ArrayList<Op>()
        for ((path, l) in entries) {
            val b = ps.files[path]
            if (l.dir) { if (b == null) ops.add(Op(path, 1, dir = true)); continue }
            val h = localHash(l.file!!, b)
            if (b == null || b.h != h) ops.add(Op(path, 0, h))
        }
        val root = store.dirOf(name)
        // ficheiros que existem mas ficaram de fora (grandes demais / limite de ficheiros) NÃO contam como apagados
        for ((path, b) in ps.files) if (!entries.containsKey(path) && !File(root, path).exists()) ops.add(Op(path, 2, dir = b.dir))
        if (ops.isEmpty()) return

        val col = filesCol(u, ps.id)
        var batch = db!!.batch()
        var n = 0
        var bytes = 0
        val after = ArrayList<() -> Unit>()
        var pushed = false

        fun flush() {
            if (n == 0) return
            await(batch.commit())
            after.forEach { it() }
            after.clear()
            batch = db!!.batch()
            n = 0; bytes = 0
            pushed = true
            saveState()
        }

        for (op in ops) {
            val ref = col.document(fid(op.path))
            when (op.kind) {
                0 -> {
                    val f = File(root, op.path)
                    if (!f.isFile || f.length() > MAX_FILE_BYTES) continue
                    val data = f.readBytes()
                    val h = sha256(data)
                    val (enc, content) = encode(data)
                    batch.set(
                        ref, mapOf(
                            "path" to op.path, "dir" to false, "deleted" to false, "enc" to enc, "content" to content,
                            "size" to data.size.toLong(), "hash" to h, "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId
                        )
                    )
                    val fs = FS(h, f.length(), f.lastModified(), false)
                    after.add { ps.files[op.path] = fs }
                    bytes += content.length + 400
                }
                1 -> {
                    batch.set(
                        ref, mapOf(
                            "path" to op.path, "dir" to true, "deleted" to false, "enc" to "t", "content" to "",
                            "size" to 0L, "hash" to "", "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId
                        )
                    )
                    after.add { ps.files[op.path] = FS("", 0, 0, true) }
                    bytes += 400
                }
                else -> {
                    // apagar = marcar como apagado (o documento conserva o conteúdo anterior)
                    batch.set(
                        ref, mapOf(
                            "path" to op.path, "dir" to op.dir, "deleted" to true,
                            "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId
                        ),
                        SetOptions.merge()
                    )
                    after.add { ps.files.remove(op.path) }
                    bytes += 400
                }
            }
            n++
            if (n >= BATCH_OPS || bytes >= BATCH_BYTES) flush()
        }
        flush()
        if (pushed) {
            // avisa os outros dispositivos (que escutam a lista de projetos) de que há novidades
            await(
                projectsCol(u).document(ps.id).set(
                    mapOf("name" to name, "deleted" to false, "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId),
                    SetOptions.merge()
                )
            )
        }
    }

    // =====================================================================================
    // Alterações em tempo real vindas de outros dispositivos
    // =====================================================================================

    private fun attachListener(u: String) {
        var first = true
        listener = projectsCol(u).addSnapshotListener(worker, EventListener<QuerySnapshot> { snap, err ->
            if (err != null) {
                if (signedIn) fail(err)
                return@EventListener
            }
            if (snap == null) return@EventListener
            if (first) { first = false; return@EventListener }   // o estado inicial é tratado pela sincronização completa
            val c = cs ?: return@EventListener
            if (uid != u || !autoSync()) return@EventListener
            val changed = LinkedHashSet<String>()
            var err2: Throwable? = null
            for (dc in snap.documentChanges) {
                if (dc.type == DocumentChange.Type.REMOVED || dc.document.metadata.hasPendingWrites()) continue
                val d = dc.document
                if (d.getString("device") == deviceId) continue   // alteração feita por este telemóvel: já está aplicada
                val rp = RP(d.id, d.getString("name") ?: continue, d.getBoolean("deleted") == true)
                try { handleRemoteProject(u, c, rp, changed) } catch (e: Throwable) { err2 = e }
            }
            saveState()
            if (err2 != null) fail(err2) else if (changed.isNotEmpty()) { lastSync = System.currentTimeMillis(); lastError = null; setState("idle") }
            emitChanged(changed)
        })
    }

    // =====================================================================================
    // Alterações locais (ProjectStore.SyncSink): sincroniza o projeto 4 s depois da última alteração
    // =====================================================================================

    private fun scheduleProject(name: String) {
        if (applying.get() == true || !signedIn || !autoSync() || name == ExternalStorage.LOOSE_PROJECT) return
        debounce.remove(name)?.cancel(false)
        debounce[name] = worker.schedule(Runnable { debounce.remove(name); syncOne(name) }, DEBOUNCE_S, TimeUnit.SECONDS)
    }

    private fun syncOne(name: String) {
        val c = cs ?: return
        val u = uid ?: return
        val changed = LinkedHashSet<String>()
        try {
            if (!store.projectExists(name)) return
            setState("syncing")
            if (!c.projects.containsKey(name)) {
                if (!eligible(name, u)) { setState("idle"); return }
                mapNew(u, c, name)
            }
            syncProject(u, c, name, changed)
            lastSync = System.currentTimeMillis(); lastError = null; setState("idle")
            emitChanged(changed)
        } catch (e: Throwable) {
            fail(e)
        }
    }

    override fun onWrite(project: String, rel: String, file: File) = scheduleProject(project)
    override fun onMkdir(project: String, rel: String) = scheduleProject(project)
    override fun onDelete(project: String, rel: String) = scheduleProject(project)
    override fun onRename(project: String, from: String, to: String) = scheduleProject(project)

    override fun onProjectRenamed(from: String, to: String) {
        if (applying.get() == true || !signedIn) return
        worker.execute {
            val c = cs ?: return@execute
            val u = uid ?: return@execute
            val ps = c.projects.remove(from) ?: return@execute
            c.projects[to] = ps
            saveState()
            try {
                await(
                    projectsCol(u).document(ps.id).set(
                        mapOf("name" to to, "updatedAt" to FieldValue.serverTimestamp(), "device" to deviceId),
                        SetOptions.merge()
                    )
                )
            } catch (e: Throwable) { fail(e) }
        }
    }

    override fun onProjectDeleted(name: String) {
        if (applying.get() == true || !signedIn) return
        debounce.remove(name)?.cancel(false)
        worker.execute {
            val c = cs ?: return@execute
            val u = uid ?: return@execute
            val ps = c.projects.remove(name) ?: return@execute
            c.deletes.add(ps.id)
            saveState()
            retryPendingDeletes(u, c)
        }
    }

    // =====================================================================================
    // Estado e erros
    // =====================================================================================

    private fun setState(s: String) {
        if (state == s) return
        state = s
        emitState()
    }

    private fun fail(e: Throwable) {
        val cause: Throwable = if (e is ExecutionException && e.cause != null) e.cause!! else e
        Log.w(TAG, "sincronização falhou", cause)
        var offline = false
        val msg = when {
            cause is TimeoutException -> { offline = true; "Sem resposta do servidor (rede lenta ou sem ligação). Vou tentar de novo quando a rede voltar." }
            cause is FirebaseFirestoreException -> when (cause.code) {
                FirebaseFirestoreException.Code.UNAVAILABLE, FirebaseFirestoreException.Code.DEADLINE_EXCEEDED -> { offline = true; "Sem ligação à internet. As alterações ficam no telemóvel e sincronizam quando houver rede." }
                FirebaseFirestoreException.Code.PERMISSION_DENIED -> "Sem permissão no Firestore. Publica as regras de segurança (firestore.rules) no projeto Firebase."
                FirebaseFirestoreException.Code.NOT_FOUND -> "A base de dados Cloud Firestore ainda não foi criada no projeto Firebase."
                FirebaseFirestoreException.Code.UNAUTHENTICATED -> "A sessão expirou. Termina a sessão e entra de novo."
                FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED -> "Limite de utilização do Firestore atingido. Tenta mais tarde."
                else -> "Erro do Firestore: " + (cause.message ?: cause.code.name)
            }
            else -> "Erro de sincronização: " + (cause.message ?: cause.javaClass.simpleName)
        }
        lastError = msg
        state = if (offline) "offline" else "error"
        emitState()
    }
}
