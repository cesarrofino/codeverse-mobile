package com.codeverse.mobile

import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Ponte entre o JavaScript (WebView) e o código nativo. Exposta ao JS como `window.Native`.
 * Todos os métodos devolvem uma string JSON: {"ok":true,...} ou {"ok":false,"error":"..."}.
 * Só é carregado conteúdo da própria app (https://appassets.androidplatform.net).
 */
class Bridge(private val store: ProjectStore, private val host: Host) {

    interface Host {
        fun requestExport(project: String)
        fun requestImport()
        fun emit(json: JSONObject)
    }

    private val pool = Executors.newCachedThreadPool()
    private val connections = ConcurrentHashMap<String, HttpURLConnection>()

    private fun wrap(block: () -> JSONObject): String = try {
        block().put("ok", true).toString()
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message ?: e.javaClass.simpleName).toString()
    }

    @JavascriptInterface
    fun listProjects(): String = wrap { JSONObject().put("projects", store.listProjects()) }

    @JavascriptInterface
    fun createProject(name: String): String = wrap { JSONObject().put("name", store.createProject(name)) }

    @JavascriptInterface
    fun deleteProject(name: String): String = wrap { store.deleteProject(name); JSONObject() }

    @JavascriptInterface
    fun renameProject(from: String, to: String): String =
        wrap { JSONObject().put("name", store.renameProject(from, to)) }

    @JavascriptInterface
    fun tree(project: String): String = wrap { JSONObject().put("items", store.tree(project)) }

    @JavascriptInterface
    fun readFile(project: String, path: String): String = wrap { store.readFile(project, path) }

    @JavascriptInterface
    fun readBase64(project: String, path: String): String = wrap { store.readBase64(project, path) }

    @JavascriptInterface
    fun writeFile(project: String, path: String, content: String): String =
        wrap { store.writeFile(project, path, content); JSONObject() }

    @JavascriptInterface
    fun writeFiles(project: String, json: String): String =
        wrap { store.writeFiles(project, json); JSONObject() }

    @JavascriptInterface
    fun createFile(project: String, path: String): String =
        wrap { store.createFile(project, path); JSONObject() }

    @JavascriptInterface
    fun mkdir(project: String, path: String): String = wrap { store.mkdir(project, path); JSONObject() }

    @JavascriptInterface
    fun deletePath(project: String, path: String): String =
        wrap { store.delete(project, path); JSONObject() }

    @JavascriptInterface
    fun renamePath(project: String, from: String, to: String): String =
        wrap { store.rename(project, from, to); JSONObject() }

    /** Abre o seletor do Android para guardar o ZIP; o resultado chega via CV_onNative({type:'export'}). */
    @JavascriptInterface
    fun exportZip(project: String): String = wrap { host.requestExport(project); JSONObject() }

    /** Abre o seletor do Android para escolher um ZIP; o resultado chega via CV_onNative({type:'import'}). */
    @JavascriptInterface
    fun importZip(): String = wrap { host.requestImport(); JSONObject() }

    /**
     * POST JSON assíncrono (só https). Feito no lado nativo para evitar problemas de CORS.
     * O resultado chega via CV_onNative({type:'http', id, ok, status, body}).
     */
    @JavascriptInterface
    fun httpPost(id: String, url: String, body: String, timeoutMs: Int) {
        pool.execute {
            val out = JSONObject().put("type", "http").put("id", id)
            try {
                val u = URL(url)
                require(u.protocol == "https") { "Só são permitidos endereços https." }
                val c = u.openConnection() as HttpURLConnection
                connections[id] = c
                c.requestMethod = "POST"
                c.connectTimeout = 10_000
                c.readTimeout = timeoutMs.coerceIn(5_000, 120_000)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val status = c.responseCode
                val stream: InputStream? = if (status in 200..299) c.inputStream else c.errorStream
                val text = stream?.use { readCapped(it, 2_000_000) } ?: ""
                out.put("ok", true).put("status", status).put("body", text)
            } catch (e: Exception) {
                out.put("ok", false).put("error", e.message ?: e.javaClass.simpleName)
            } finally {
                connections.remove(id)?.disconnect()
            }
            host.emit(out)
        }
    }

    @JavascriptInterface
    fun httpCancel(id: String) {
        connections.remove(id)?.disconnect()
    }

    private fun readCapped(input: InputStream, cap: Int): String {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (bos.size() < cap) {
            val r = input.read(buf)
            if (r < 0) break
            bos.write(buf, 0, r)
        }
        return bos.toString("UTF-8")
    }
}
