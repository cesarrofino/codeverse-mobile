package com.codeverse.mobile

import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Ponte entre o JavaScript (WebView) e o código nativo. Exposta ao JS como `window.Native`.
 * Todos os métodos devolvem uma string JSON: {"ok":true,...} ou {"ok":false,"error":"..."}.
 * Só é carregado conteúdo da própria app (https://appassets.androidplatform.net).
 */
class Bridge(
    private val store: ProjectStore,
    private val host: Host,
    private val java: JavaSession,
    private val ext: ExternalStorage,
    private val git: GitService,
    private val cloud: CloudService
) {

    interface Host {
        fun requestExport(project: String)
        fun requestImport()
        fun requestPickFolder()
        fun requestPickFiles()
        fun emit(json: JSONObject)
        fun versionName(): String
        fun updatesDir(): File
        fun installApk(file: File)
        fun openUrl(url: String)
    }

    private val pool = Executors.newCachedThreadPool()
    private val connections = ConcurrentHashMap<String, HttpURLConnection>()
    private val localServer by lazy { LocalServer(store) }

    private fun wrap(block: () -> JSONObject): String = try {
        block().put("ok", true).toString()
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message ?: e.javaClass.simpleName).toString()
    }

    @JavascriptInterface
    fun listProjects(): String = wrap { JSONObject().put("projects", store.listProjects()) }

    @JavascriptInterface
    fun createProject(name: String): String = wrap { JSONObject().put("name", store.createProject(name)) }

    @JavascriptInterface
    fun deleteProject(name: String): String = wrap { store.deleteProject(name); JSONObject() }

    @JavascriptInterface
    fun renameProject(from: String, to: String): String =
        wrap { JSONObject().put("name", store.renameProject(from, to)) }

    @JavascriptInterface
    fun tree(project: String): String = wrap { JSONObject().put("items", store.tree(project)) }

    @JavascriptInterface
    fun readFile(project: String, path: String): String = wrap { store.readFile(project, path) }

    @JavascriptInterface
    fun readBase64(project: String, path: String): String = wrap { store.readBase64(project, path) }

    @JavascriptInterface
    fun writeFile(project: String, path: String, content: String): String =
        wrap { store.writeFile(project, path, content); JSONObject() }

    @JavascriptInterface
    fun writeFiles(project: String, json: String): String =
        wrap { store.writeFiles(project, json); JSONObject() }

    @JavascriptInterface
    fun createFile(project: String, path: String): String =
        wrap { store.createFile(project, path); JSONObject() }

    @JavascriptInterface
    fun mkdir(project: String, path: String): String = wrap { store.mkdir(project, path); JSONObject() }

    @JavascriptInterface
    fun deletePath(project: String, path: String): String =
        wrap { store.delete(project, path); JSONObject() }

    @JavascriptInterface
    fun renamePath(project: String, from: String, to: String): String =
        wrap { store.rename(project, from, to); JSONObject() }

    /** Abre o seletor do Android para guardar o ZIP; o resultado chega via CV_onNative({type:'export'}). */
    @JavascriptInterface
    fun exportZip(project: String): String = wrap { host.requestExport(project); JSONObject() }

    /** Abre o seletor do Android para escolher um ZIP; o resultado chega via CV_onNative({type:'import'}). */
    @JavascriptInterface
    fun importZip(): String = wrap { host.requestImport(); JSONObject() }

    /** Abre o seletor de pastas do Android; o resultado chega via CV_onNative({type:'pick', kind:'folder'}). */
    @JavascriptInterface
    fun pickFolder(): String = wrap { host.requestPickFolder(); JSONObject() }

    /** Abre o seletor de ficheiros do Android; o resultado chega via CV_onNative({type:'pick', kind:'file'}). */
    @JavascriptInterface
    fun pickFiles(): String = wrap { host.requestPickFiles(); JSONObject() }

    @JavascriptInterface
    fun linkInfo(project: String): String = wrap { ext.describe(project) }

    /** Volta a ler a pasta do armazenamento (assíncrono). Resultado: CV_onNative({type:'storage', op:'refresh'}). */
    @JavascriptInterface
    fun storageRefresh(project: String): String = wrap {
        pool.execute {
            val r = JSONObject().put("type", "storage").put("op", "refresh").put("project", project)
            try { ext.refresh(project); r.put("ok", true) } catch (e: Exception) { r.put("ok", false).put("error", e.message ?: "Erro") }
            host.emit(r)
        }
        JSONObject()
    }

    @JavascriptInterface
    fun storageUnlink(project: String): String = wrap { ext.unlink(project); JSONObject() }

    /** Compila e executa Java offline. Resultado em CV_onNative({type:'java', id, kind:'phase'|'out'|'err'|'done'}). */
    @JavascriptInterface
    fun javaRun(id: String, project: String, mainPath: String, level: String): String =
        wrap { java.start(id, store.dirOf(project).absolutePath, mainPath, level); JSONObject() }

    @JavascriptInterface
    fun javaInput(id: String, text: String) { java.input(id, text) }

    @JavascriptInterface
    fun javaStop(id: String) { java.stop(id) }

    /** input() do Python: o JS envia a linha escrita; o Worker está bloqueado num pedido XHR (ver StdinBroker). */
    @JavascriptInterface
    fun pyInput(line: String) { StdinBroker.submit(line) }

    @JavascriptInterface
    fun pyInputCancel() { StdinBroker.cancel() }

    @JavascriptInterface
    fun pyInputReset() { StdinBroker.reset() }

    /**
     * POST JSON assíncrono (só https). Feito no lado nativo para evitar problemas de CORS.
     * O resultado chega via CV_onNative({type:'http', id, ok, status, body}).
     */
    @JavascriptInterface
    fun httpPost(id: String, url: String, body: String, timeoutMs: Int) {
        pool.execute {
            val out = JSONObject().put("type", "http").put("id", id)
            try {
                val u = URL(url)
                require(u.protocol == "https") { "Só são permitidos endereços https." }
                val c = u.openConnection() as HttpURLConnection
                connections[id] = c
                c.requestMethod = "POST"
                c.connectTimeout = 10_000
                c.readTimeout = timeoutMs.coerceIn(5_000, 120_000)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val status = c.responseCode
                val stream: InputStream? = if (status in 200..299) c.inputStream else c.errorStream
                val text = stream?.use { readCapped(it, 2_000_000) } ?: ""
                out.put("ok", true).put("status", status).put("body", text)
            } catch (e: Exception) {
                out.put("ok", false).put("error", e.message ?: e.javaClass.simpleName)
            } finally {
                connections.remove(id)?.disconnect()
            }
            host.emit(out)
        }
    }

    /**
     * GET assíncrono (só https), usado pela loja de plugins. Máx. 1 MB de resposta.
     * O resultado chega via CV_onNative({type:'http', id, ok, status, body}).
     */
    @JavascriptInterface
    fun httpGet(id: String, url: String, timeoutMs: Int) {
        pool.execute {
            val out = JSONObject().put("type", "http").put("id", id)
            try {
                val u = URL(url)
                require(u.protocol == "https") { "Só são permitidos endereços https." }
                val c = u.openConnection() as HttpURLConnection
                connections[id] = c
                c.requestMethod = "GET"
                c.instanceFollowRedirects = true
                c.connectTimeout = 10_000
                c.readTimeout = timeoutMs.coerceIn(5_000, 60_000)
                c.setRequestProperty("Accept", "application/json, text/plain, */*")
                c.setRequestProperty("User-Agent", "CodeVerse-Mobile")
                val status = c.responseCode
                val stream: InputStream? = if (status in 200..299) c.inputStream else c.errorStream
                val text = stream?.use { readCapped(it, 1_000_000) } ?: ""
                out.put("ok", true).put("status", status).put("body", text)
            } catch (e: Exception) {
                out.put("ok", false).put("error", e.message ?: e.javaClass.simpleName)
            } finally {
                connections.remove(id)?.disconnect()
            }
            host.emit(out)
        }
    }

    /** Versão instalada da app (versionName). */
    /** Arranca (se preciso) o servidor localhost e devolve a porta. */
    @JavascriptInterface
    fun previewPort(): String = wrap { JSONObject().put("port", localServer.start()) }

    /** Abre http://localhost:PORTA/<projeto>/<caminho> no navegador do telemóvel. */
    @JavascriptInterface
    fun openInBrowser(project: String, path: String): String = wrap {
        val port = localServer.start()
        val enc = path.split('/').joinToString("/") { android.net.Uri.encode(it) }
        host.openUrl("http://localhost:$port/" + android.net.Uri.encode(project) + "/" + enc)
        JSONObject().put("port", port)
    }

    // ---------- Git / GitHub ----------

    /** Estado da sessão do GitHub (nunca devolve o token). */
    @JavascriptInterface
    fun gitAuth(): String = wrap { git.authInfo() }

    @JavascriptInterface
    fun gitLogout(): String = wrap { git.logout(); git.authInfo() }

    @JavascriptInterface
    fun gitSetIdentity(name: String, email: String): String = wrap { git.setIdentity(name, email); git.authInfo() }

    @JavascriptInterface
    fun gitSetClientId(clientId: String): String = wrap { git.setClientId(clientId); git.authInfo() }

    /**
     * Executa uma operação Git em segundo plano (login, device, repos, clone, status, init, stage, unstage, discard,
     * commit, push, pull, branches, checkout, log, diff, remote). Resultado em CV_onNative({type:'git', id, ...}).
     */
    @JavascriptInterface
    fun gitRun(id: String, op: String, project: String, args: String): String = wrap {
        git.run(id, op, project, JSONObject(if (args.isBlank()) "{}" else args)); JSONObject()
    }

    @JavascriptInterface
    fun gitCancel(id: String) { git.cancel(id) }

    /** Abre uma página do GitHub (só https://github.com/) no navegador do telemóvel. */
    @JavascriptInterface
    fun gitOpenUrl(url: String): String = wrap {
        require(url.startsWith("https://github.com/")) { "Endereço não permitido." }
        host.openUrl(url); JSONObject()
    }

    // ---------- Conta (Firebase Auth) e sincronização (Firestore) ----------

    /** Estado da conta e da sincronização (sem tokens). */
    @JavascriptInterface
    fun cloudInfo(): String = wrap { cloud.info() }

    /** provider = "google" | "github". O resultado chega via CV_onNative({type:'auth', op:'signin', ok, ...}). */
    @JavascriptInterface
    fun cloudSignIn(provider: String): String = wrap { cloud.signIn(provider); JSONObject() }

    /** Termina a sessão; wipeLocal=true apaga deste telemóvel os projetos sincronizados com a conta. */
    @JavascriptInterface
    fun cloudSignOut(wipeLocal: Boolean): String = wrap { cloud.signOut(wipeLocal); JSONObject() }

    @JavascriptInterface
    fun cloudSyncNow(): String = wrap { cloud.syncNow(); JSONObject() }

    @JavascriptInterface
    fun cloudSetAutoSync(on: Boolean): String = wrap { cloud.setAutoSync(on); JSONObject() }

    @JavascriptInterface
    fun appVersion(): String = wrap { JSONObject().put("version", host.versionName()).put("repo", BuildConfig.UPDATE_REPO) }

    /**
     * Descarrega o APK da atualização (só https) para a cache da app.
     * Progresso/fim em CV_onNative({type:'download', id, kind:'progress'|'done'|'error', ...}).
     */
    @JavascriptInterface
    fun downloadApk(id: String, url: String) {
        pool.execute {
            val out = JSONObject().put("type", "download").put("id", id)
            try {
                val u = URL(url)
                require(u.protocol == "https") { "Só são permitidos endereços https." }
                val dir = host.updatesDir().apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val target = File(dir, "CodeVerse-update.apk")
                val c = u.openConnection() as HttpURLConnection
                connections[id] = c
                c.instanceFollowRedirects = true
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                c.setRequestProperty("User-Agent", "CodeVerse-Mobile")
                val status = c.responseCode
                if (status !in 200..299) throw IOException("O servidor respondeu com o código $status.")
                val total = c.contentLengthLong
                var done = 0L
                var last = 0L
                c.inputStream.use { input ->
                    target.outputStream().buffered().use { fos ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val r = input.read(buf)
                            if (r < 0) break
                            fos.write(buf, 0, r)
                            done += r
                            val now = System.currentTimeMillis()
                            if (now - last > 150) {
                                last = now
                                host.emit(JSONObject().put("type", "download").put("id", id).put("kind", "progress").put("done", done).put("total", total))
                            }
                        }
                    }
                }
                val magic = target.inputStream().use { val b = ByteArray(2); it.read(b); b }
                if (done < 100_000 || magic[0] != 'P'.code.toByte() || magic[1] != 'K'.code.toByte()) {
                    target.delete()
                    throw IOException("O ficheiro descarregado não é um APK válido.")
                }
                out.put("kind", "done").put("size", done)
            } catch (e: Exception) {
                out.put("kind", "error").put("error", e.message ?: e.javaClass.simpleName)
            } finally {
                connections.remove(id)?.disconnect()
            }
            host.emit(out)
        }
    }

    /** Abre o instalador do Android para o APK já descarregado. */
    @JavascriptInterface
    fun installApk(): String = wrap {
        val f = File(host.updatesDir(), "CodeVerse-update.apk")
        require(f.exists() && f.length() > 0) { "A atualização ainda não foi descarregada." }
        host.installApk(f)
        JSONObject()
    }

    @JavascriptInterface
    fun httpCancel(id: String) {
        connections.remove(id)?.disconnect()
    }

    private fun readCapped(input: InputStream, cap: Int): String {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (bos.size() < cap) {
            val r = input.read(buf)
            if (r < 0) break
            bos.write(buf, 0, r)
        }
        return bos.toString("UTF-8")
    }
}
