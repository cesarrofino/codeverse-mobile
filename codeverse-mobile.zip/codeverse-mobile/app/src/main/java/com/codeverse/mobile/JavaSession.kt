package com.codeverse.mobile

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import org.json.JSONObject

/**
 * Lado da app (processo principal) da execução de Java offline.
 * O código é compilado e executado num processo separado (RunnerService, ":runner"):
 * assim um programa com ciclo infinito ou sem memória nunca bloqueia a interface e o botão Parar
 * limita-se a terminar esse processo.
 */
class JavaSession(private val ctx: Context, private val emit: (JSONObject) -> Unit) {

    private val ui = Handler(Looper.getMainLooper())
    private val incoming = Messenger(Handler(Looper.getMainLooper()) { m -> onReply(m); true })

    private var currentId: String? = null
    private var conn: ServiceConnection? = null
    private var service: Messenger? = null

    fun start(id: String, srcDir: String, mainPath: String, level: String) {
        ui.post {
            cleanup(kill = true)
            currentId = id
            val c = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                    if (currentId != id) return
                    val m = Messenger(binder)
                    service = m
                    val msg = Message.obtain(null, RunnerProtocol.MSG_RUN)
                    msg.replyTo = incoming
                    msg.data = Bundle().apply {
                        putString(RunnerProtocol.K_SRC, srcDir)
                        putString(RunnerProtocol.K_MAIN, mainPath)
                        putString(RunnerProtocol.K_LEVEL, level)
                    }
                    try {
                        m.send(msg)
                    } catch (e: Exception) {
                        finish(id, 1, "Não foi possível iniciar o executor Java: ${e.message}", false)
                    }
                }

                override fun onServiceDisconnected(name: ComponentName) {
                    if (currentId == id) {
                        finish(id, 137, "O processo do programa terminou (System.exit, falta de memória ou paragem).", false)
                    }
                }
            }
            conn = c
            val ok = try {
                ctx.bindService(Intent(ctx, RunnerService::class.java), c, Context.BIND_AUTO_CREATE)
            } catch (e: Exception) {
                false
            }
            if (!ok) finish(id, 1, "Não foi possível ligar ao executor Java.", false)
        }
    }

    fun input(id: String, text: String) {
        ui.post {
            if (id != currentId) return@post
            val m = Message.obtain(null, RunnerProtocol.MSG_STDIN)
            m.data = Bundle().apply { putString(RunnerProtocol.K_TEXT, text) }
            try { service?.send(m) } catch (_: Exception) { }
        }
    }

    fun stop(id: String) {
        ui.post { if (id == currentId) cleanup(kill = true) }
    }

    private fun json(id: String, kind: String) = JSONObject().put("type", "java").put("id", id).put("kind", kind)

    private fun onReply(m: Message) {
        val id = currentId ?: return
        val d = m.data
        val text = d?.getString(RunnerProtocol.K_TEXT) ?: ""
        when (m.what) {
            RunnerProtocol.MSG_PHASE ->
                emit(json(id, "phase").put("text", text).put("log", d?.getBoolean(RunnerProtocol.K_LOG) ?: false))
            RunnerProtocol.MSG_OUT -> emit(json(id, "out").put("text", text))
            RunnerProtocol.MSG_ERR -> emit(json(id, "err").put("text", text))
            RunnerProtocol.MSG_DONE ->
                finish(id, m.arg1, null, d?.getBoolean(RunnerProtocol.K_COMPILE) ?: false)
        }
    }

    private fun finish(id: String, code: Int, text: String?, compile: Boolean) {
        if (id != currentId) return
        val j = json(id, "done").put("code", code).put("compile", compile)
        if (text != null) j.put("text", text)
        emit(j)
        cleanup(kill = true)
    }

    private fun cleanup(kill: Boolean) {
        val s = service
        if (kill && s != null) {
            try { s.send(Message.obtain(null, RunnerProtocol.MSG_KILL)) } catch (_: Exception) { }
        }
        conn?.let { try { ctx.unbindService(it) } catch (_: Exception) { } }
        conn = null
        service = null
        currentId = null
    }
}
