package com.codeverse.mobile

import android.content.Context
import com.android.tools.r8.CompilationMode
import com.android.tools.r8.D8
import com.android.tools.r8.D8Command
import com.android.tools.r8.OutputMode
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Compilador de Java dentro do telemóvel, sem internet:
 *   .java --(ECJ, Eclipse Compiler for Java)--> .class --(D8)--> classes.dex --(DexClassLoader)--> execução.
 * As classes da biblioteca padrão vêm de assets/java/rt.jar (extraído do android.jar durante o build).
 */
object JavaToolchain {

    class Result(val error: String?, val dex: List<File>)

    fun build(ctx: Context, src: File, work: File, level: String): Result {
        val rt = ensureRuntimeJar(ctx) ?: return Result(
            "A biblioteca Java offline (assets/java/rt.jar) não está no APK.\n" +
                "Confirma que o passo \"Preparar biblioteca Java\" do workflow correu sem erros.", emptyList()
        )
        val classes = File(work, "classes").apply { mkdirs() }
        val dexDir = File(work, "dex").apply { mkdirs() }

        val sources = src.walkTopDown()
            .onEnter { !it.name.startsWith(".") }
            .filter { it.isFile && it.extension == "java" }
            .toList()
        if (sources.isEmpty()) return Result("Nenhum ficheiro .java no projeto.", emptyList())

        // 1) Java -> .class
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        val args = mutableListOf(
            "-$level", "-nowarn", "-proc:none", "-encoding", "UTF-8",
            "-bootclasspath", rt.absolutePath, "-cp", rt.absolutePath,
            "-d", classes.absolutePath
        )
        sources.forEach { args += it.absolutePath }
        val ok = org.eclipse.jdt.internal.compiler.batch.Main(pw, pw, false).compile(args.toTypedArray())
        pw.flush()
        if (!ok) {
            val prefix = src.absolutePath + File.separator
            return Result(sw.toString().replace(prefix, "").trim().ifEmpty { "A compilação falhou." }, emptyList())
        }

        // 2) .class -> .dex
        val classFiles = classes.walkTopDown().filter { it.isFile && it.extension == "class" }.map { it.toPath() }.toList()
        if (classFiles.isEmpty()) return Result("O compilador não gerou ficheiros .class.", emptyList())
        try {
            val cmd = D8Command.builder()
                .addProgramFiles(classFiles)
                .addLibraryFiles(rt.toPath())
                .setMinApiLevel(26)
                .setMode(CompilationMode.DEBUG)
                .setOutput(dexDir.toPath(), OutputMode.DexIndexed)
                .build()
            D8.run(cmd)
        } catch (t: Throwable) {
            return Result("Falha ao converter para DEX: ${t.message ?: t}", emptyList())
        }
        val dex = dexDir.listFiles { f -> f.extension == "dex" }?.sortedBy { it.name }.orEmpty()
        if (dex.isEmpty()) return Result("O conversor DEX não gerou ficheiros.", emptyList())
        return Result(null, dex)
    }

    /** Copia assets/java/rt.jar para o armazenamento interno (uma vez por instalação/atualização). */
    private fun ensureRuntimeJar(ctx: Context): File? {
        val dir = File(ctx.filesDir, "java").apply { mkdirs() }
        val out = File(dir, "rt.jar")
        val installed = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        } catch (_: Exception) {
            0L
        }
        if (out.exists() && out.length() > 0 && out.lastModified() >= installed) return out
        return try {
            ctx.assets.open("java/rt.jar").use { input -> out.outputStream().use { input.copyTo(it) } }
            out
        } catch (_: Exception) {
            null
        }
    }

    /** Nome completo da classe principal a partir do ficheiro (package + nome do ficheiro). */
    fun mainClassOf(src: File, mainRel: String): String {
        val f = File(src, mainRel)
        val text = try { f.readText() } catch (_: Exception) { "" }
        val pkg = Regex("""^\s*package\s+([\w.]+)\s*;""", RegexOption.MULTILINE).find(text)?.groupValues?.get(1)
        val name = f.nameWithoutExtension
        return if (pkg.isNullOrEmpty()) name else "$pkg.$name"
    }
}
