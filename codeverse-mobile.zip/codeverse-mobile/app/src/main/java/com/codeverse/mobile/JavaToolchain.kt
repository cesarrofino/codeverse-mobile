package com.codeverse.mobile

import android.content.Context
import com.android.tools.r8.CompilationMode
import com.android.tools.r8.D8
import com.android.tools.r8.D8Command
import com.android.tools.r8.OutputMode
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Compilador de Java dentro do telemóvel, sem internet:
 *   .java --(ECJ, Eclipse Compiler for Java)--> .class --(D8)--> classes.dex --(DexClassLoader)--> execução.
 * As classes da biblioteca padrão vêm de assets/java/rt.jar (extraído do android.jar durante o build).
 */
object JavaToolchain {

    class Result(val error: String?, val dex: List<File>)

    fun build(ctx: Context, src: File, work: File, level: String): Result {
        val rt = try {
            ensureRuntimeJar(ctx)
        } catch (e: Exception) {
            return Result(
                "Não foi possível preparar a biblioteca Java offline (java/rt.jar): ${e.javaClass.simpleName}: ${e.message}\n" +
                    "Reinstala a versão mais recente da app.", emptyList()
            )
        }
        val classes = File(work, "classes").apply { mkdirs() }
        val dexDir = File(work, "dex").apply { mkdirs() }

        val origFiles = src.walkTopDown()
            .onEnter { !it.name.startsWith(".") }
            .filter { it.isFile && it.extension == "java" }
            .toList()
        if (origFiles.isEmpty()) return Result("Nenhum ficheiro .java no projeto.", emptyList())

        // O Java exige que a classe "public" tenha o nome do ficheiro (Imprimir -> Imprimir.java).
        // Como aqui o ficheiro pode chamar-se app.java, compilamos cópias com o nome certo
        // (os ficheiros do utilizador não são alterados) e traduzimos o nome nas mensagens de erro.
        val stage = File(work, "src").apply { deleteRecursively(); mkdirs() }
        val sources = mutableListOf<File>()
        val shown = mutableMapOf<String, String>() // caminho da cópia -> caminho original (relativo)
        for (f in origFiles) {
            val rel = f.relativeTo(src).path
            val text = try { f.readText() } catch (_: Exception) { "" }
            val pub = topLevelTypes(text).firstOrNull { it.isPublic }?.name
            var dest = File(stage, File(rel).parent?.let { "$it/" }.orEmpty() + (pub ?: f.nameWithoutExtension) + ".java")
            if (dest.exists()) dest = File(stage, rel)
            dest.parentFile?.mkdirs()
            dest.writeText(text)
            sources += dest
            shown[dest.absolutePath] = rel
        }

        // 1) Java -> .class
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        val args = mutableListOf(
            "-$level", "-nowarn", "-proc:none", "-encoding", "UTF-8",
            "-bootclasspath", rt.absolutePath, "-cp", rt.absolutePath,
            "-d", classes.absolutePath
        )
        sources.forEach { args += it.absolutePath }
        val ok = org.eclipse.jdt.internal.compiler.batch.Main(pw, pw, false).compile(args.toTypedArray())
        pw.flush()
        if (!ok) {
            var msg = sw.toString()
            for ((k, v) in shown) msg = msg.replace(k, v)
            msg = msg.replace(stage.absolutePath + File.separator, "")
            return Result(msg.trim().ifEmpty { "A compilação falhou." }, emptyList())
        }

        // 2) .class -> .dex
        val classFiles = classes.walkTopDown().filter { it.isFile && it.extension == "class" }.map { it.toPath() }.toList()
        if (classFiles.isEmpty()) return Result("O compilador não gerou ficheiros .class.", emptyList())
        try {
            val cmd = D8Command.builder()
                .addProgramFiles(classFiles)
                .addLibraryFiles(rt.toPath())
                .setMinApiLevel(26)
                .setMode(CompilationMode.DEBUG)
                .setOutput(dexDir.toPath(), OutputMode.DexIndexed)
                .build()
            D8.run(cmd)
        } catch (t: Throwable) {
            return Result("Falha ao converter para DEX: ${t.message ?: t}", emptyList())
        }
        val dex = dexDir.listFiles { f -> f.extension == "dex" }?.sortedBy { it.name }.orEmpty()
        if (dex.isEmpty()) return Result("O conversor DEX não gerou ficheiros.", emptyList())
        return Result(null, dex)
    }

    /** Copia assets/java/rt.jar para o armazenamento interno (uma vez por instalação/atualização). */
    private fun ensureRuntimeJar(ctx: Context): File {
        val dir = File(ctx.filesDir, "java").apply { mkdirs() }
        val out = File(dir, "rt.jar")
        val installed = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        } catch (_: Exception) {
            0L
        }
        if (out.exists() && out.length() > 0 && out.lastModified() >= installed) return out
        val tmp = File(dir, "rt.jar.tmp")
        ctx.assets.open("java/rt.jar").use { input -> tmp.outputStream().use { input.copyTo(it) } }
        out.delete()
        if (!tmp.renameTo(out)) throw java.io.IOException("não foi possível gravar o rt.jar")
        return out
    }

    private class TypeDecl(val name: String, val isPublic: Boolean, val pos: Int)

    private val typeRegex = Regex("""\b((?:(?:public|abstract|final|strictfp|sealed)\s+)*)(class|interface|enum|record|@interface)\s+([A-Za-z_]\w*)""")

    /** Tipos declarados ao nível superior do ficheiro (ignora comentários, textos e classes internas). */
    private fun topLevelTypes(text: String): List<TypeDecl> {
        val sb = StringBuilder(text.length)
        var depth = 0
        var i = 0
        val n = text.length
        fun blank(to: Int) { while (i < to) { sb.append(if (text[i] == '\n') '\n' else ' '); i++ } }
        while (i < n) {
            val c = text[i]
            when {
                text.startsWith("//", i) -> { val e = text.indexOf('\n', i).let { if (it < 0) n else it }; blank(e) }
                text.startsWith("/*", i) -> { val e = text.indexOf("*/", i + 2).let { if (it < 0) n else it + 2 }; blank(e) }
                text.startsWith("\"\"\"", i) -> { val e = text.indexOf("\"\"\"", i + 3).let { if (it < 0) n else it + 3 }; blank(e) }
                c == '"' || c == '\'' -> {
                    var j = i + 1
                    while (j < n && text[j] != c && text[j] != '\n') { if (text[j] == '\\') j++; j++ }
                    blank(minOf(n, j + 1))
                }
                c == '{' -> { depth++; sb.append(' '); i++ }
                c == '}' -> { if (depth > 0) depth--; sb.append(' '); i++ }
                else -> { sb.append(if (depth == 0 || c == '\n') c else ' '); i++ }
            }
        }
        return typeRegex.findAll(sb).map {
            TypeDecl(it.groupValues[3], it.groupValues[1].contains("public"), it.range.first)
        }.toList()
    }

    /** Nome completo da classe principal: a classe do ficheiro que tem main (ou a pública / a primeira). */
    fun mainClassOf(src: File, mainRel: String): String {
        val f = File(src, mainRel)
        val text = try { f.readText() } catch (_: Exception) { "" }
        val pkg = Regex("""^\s*package\s+([\w.]+)\s*;""", RegexOption.MULTILINE).find(text)?.groupValues?.get(1)
        val types = topLevelTypes(text)
        val mainPos = Regex("""static\s+void\s+main\s*\(""").find(text)?.range?.first ?: -1
        val name = types.firstOrNull { it.isPublic }?.name
            ?: types.lastOrNull { mainPos >= 0 && it.pos <= mainPos }?.name
            ?: types.firstOrNull()?.name
            ?: f.nameWithoutExtension
        return if (pkg.isNullOrEmpty()) name else "$pkg.$name"
    }
}
