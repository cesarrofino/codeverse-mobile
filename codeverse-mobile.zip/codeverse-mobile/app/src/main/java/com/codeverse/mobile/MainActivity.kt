package com.codeverse.mobile

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import java.io.IOException

class MainActivity : AppCompatActivity(), Bridge.Host {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private val MIME = mapOf(
            "html" to "text/html",
            "htm" to "text/html",
            "js" to "application/javascript",
            "mjs" to "application/javascript",
            "css" to "text/css",
            "json" to "application/json",
            "wasm" to "application/wasm",
            "zip" to "application/zip",
            "png" to "image/png",
            "svg" to "image/svg+xml",
            "txt" to "text/plain"
        )
    }

    private lateinit var webView: WebView
    private lateinit var store: ProjectStore
    private lateinit var ext: ExternalStorage
    private var pendingExport: String? = null

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            onExportUri(uri)
        }

    private val folderLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = if (r.resultCode == RESULT_OK) r.data?.data else null
            onFolderUri(uri)
        }

    private val filesLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uris = ArrayList<Uri>()
            if (r.resultCode == RESULT_OK) {
                r.data?.data?.let { uris.add(it) }
                val clip = r.data?.clipData
                if (clip != null) for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
            }
            onFileUris(uris)
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            onImportUri(uri)
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        store = ProjectStore(File(filesDir, "projects"))
        ext = ExternalStorage(applicationContext, store) { emit(it) }
        store.sink = ext

        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                textZoom = 100
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    val url = request.url
                    if (url.scheme == "https" && url.host == HOST) {
                        if (url.path == StdinBroker.PATH) return stdinResponse()
                        return serveAsset(url.path ?: "/")
                    }
                    return null
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return false
                    if (request.url.host == HOST) return false
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    } catch (_: Exception) {
                    }
                    return true
                }
            }
            addJavascriptInterface(Bridge(store, this@MainActivity, JavaSession(applicationContext) { emit(it) }, ext), "Native")
        }
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.CV_onBack ? window.CV_onBack() : false)") { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl("https://$HOST/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        webView.evaluateJavascript("window.CV_onPause && window.CV_onPause()", null)
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    // ---------- Servidor de ficheiros da app (assets/www) ----------

    private fun serveAsset(rawPath: String): WebResourceResponse {
        var p = rawPath.trimStart('/')
        if (p.isEmpty()) p = "index.html"
        if (p.contains("..")) return notFound()
        return try {
            val stream = assets.open("www/$p")
            val ext = p.substringAfterLast('.', "").lowercase()
            val mime = MIME[ext] ?: "application/octet-stream"
            val enc = if (mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json") "utf-8" else null
            WebResourceResponse(mime, enc, 200, "OK", mapOf("Cache-Control" to "no-cache"), stream)
        } catch (_: IOException) {
            notFound()
        }
    }

    /** Resposta (bloqueante) ao input() do Python; corre numa thread de rede do WebView, não na UI. */
    private fun stdinResponse() = WebResourceResponse(
        "text/plain", "utf-8", 200, "OK",
        mapOf("Cache-Control" to "no-store"),
        StdinBroker.await().byteInputStream(Charsets.UTF_8)
    )

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", emptyMap(), "404".byteInputStream()
    )

    // ---------- Bridge.Host ----------

    override fun emit(json: JSONObject) {
        runOnUiThread {
            webView.evaluateJavascript("window.CV_onNative && window.CV_onNative($json)", null)
        }
    }

    override fun requestExport(project: String) {
        runOnUiThread {
            pendingExport = project
            exportLauncher.launch("$project.zip")
        }
    }

    override fun requestImport() {
        runOnUiThread {
            importLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
    }

    private val grantFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION

    override fun requestPickFolder() {
        runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(grantFlags or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            try { folderLauncher.launch(i) } catch (e: Exception) {
                emit(JSONObject().put("type", "pick").put("kind", "folder").put("ok", false).put("error", "Seletor de pastas indisponível."))
            }
        }
    }

    override fun requestPickFiles() {
        runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true).addFlags(grantFlags)
            try { filesLauncher.launch(i) } catch (e: Exception) {
                emit(JSONObject().put("type", "pick").put("kind", "file").put("ok", false).put("error", "Seletor de ficheiros indisponível."))
            }
        }
    }

    private fun onFolderUri(uri: Uri?) {
        if (uri == null) {
            emit(JSONObject().put("type", "pick").put("kind", "folder").put("ok", false).put("cancelled", true))
            return
        }
        Thread {
            val r = JSONObject().put("type", "pick").put("kind", "folder")
            try { r.put("ok", true).put("project", ext.importTree(uri)) }
            catch (e: Exception) { r.put("ok", false).put("error", e.message ?: "Erro ao abrir a pasta") }
            emit(r)
        }.start()
    }

    private fun onFileUris(uris: List<Uri>) {
        if (uris.isEmpty()) {
            emit(JSONObject().put("type", "pick").put("kind", "file").put("ok", false).put("cancelled", true))
            return
        }
        Thread {
            val r = JSONObject().put("type", "pick").put("kind", "file")
            try {
                var first: String? = null
                for (u in uris) { val rel = ext.importFile(u); if (first == null) first = rel }
                r.put("ok", true).put("project", ExternalStorage.LOOSE_PROJECT).put("path", first)
            } catch (e: Exception) { r.put("ok", false).put("error", e.message ?: "Erro ao abrir o ficheiro") }
            emit(r)
        }.start()
    }

    private fun onExportUri(uri: Uri?) {
        val project = pendingExport ?: return
        pendingExport = null
        if (uri == null) {
            emit(JSONObject().put("type", "export").put("ok", false).put("cancelled", true))
            return
        }
        Thread {
            val r = JSONObject().put("type", "export").put("project", project)
            try {
                val os = contentResolver.openOutputStream(uri) ?: throw IOException("Não foi possível escrever o ficheiro.")
                os.use { store.zipTo(project, it) }
                r.put("ok", true)
            } catch (e: Exception) {
                r.put("ok", false).put("error", e.message ?: "Erro ao exportar")
            }
            emit(r)
        }.start()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val s = c.getString(0)
                if (!s.isNullOrBlank()) return s
            }
        }
        return "projeto-importado"
    }

    private fun onImportUri(uri: Uri?) {
        if (uri == null) {
            emit(JSONObject().put("type", "import").put("ok", false).put("cancelled", true))
            return
        }
        Thread {
            val r = JSONObject().put("type", "import")
            try {
                val name = store.importZip(displayName(uri)) { contentResolver.openInputStream(uri) }
                r.put("ok", true).put("name", name)
            } catch (e: Exception) {
                r.put("ok", false).put("error", e.message ?: "Erro ao importar")
            }
            emit(r)
        }.start()
    }
}
