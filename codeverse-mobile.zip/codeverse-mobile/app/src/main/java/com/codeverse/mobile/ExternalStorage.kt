package com.codeverse.mobile

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

/**
 * Ligação ao armazenamento do telemóvel (Storage Access Framework).
 *
 * Como funciona:
 *  - O utilizador escolhe uma PASTA (ou ficheiros) no armazenamento. A app guarda a permissão de forma persistente.
 *  - O conteúdo é copiado para um projeto interno (rápido, necessário para compilar Java / correr Python).
 *  - Cada gravação, criação, renomeação ou eliminação feita no projeto é espelhada no armazenamento real,
 *    por uma fila de trabalho (uma operação de cada vez, na ordem certa).
 *  - "Atualizar do armazenamento" volta a ler a pasta (se outra app a alterou).
 */
class ExternalStorage(
    private val ctx: Context,
    private val store: ProjectStore,
    private val emit: (JSONObject) -> Unit
) : ProjectStore.SyncSink {

    companion object {
        private val SKIP_DIRS = setOf(
            ".git", "node_modules", "venv", ".venv", "__pycache__", "build", ".gradle", ".idea", ".dart_tool"
        )
        private const val MAX_FILES = 5000
        private const val MAX_TOTAL = 120L * 1024 * 1024
        private const val MAX_FILE = 25L * 1024 * 1024
        const val LOOSE_PROJECT = "Ficheiros avulsos"
    }

    private val prefs = ctx.getSharedPreferences("cv_links", Context.MODE_PRIVATE)
    private val exec = Executors.newSingleThreadExecutor()
    private val cr get() = ctx.contentResolver
    private var lastErrorAt = 0L

    // ---------- Ligações guardadas ----------

    @Synchronized private fun links(): JSONObject =
        try { JSONObject(prefs.getString("links", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    @Synchronized private fun saveLinks(o: JSONObject) {
        prefs.edit().putString("links", o.toString()).apply()
    }

    @Synchronized fun linkOf(project: String): JSONObject? = links().optJSONObject(project)

    @Synchronized private fun setLink(project: String, link: JSONObject) {
        val all = links(); all.put(project, link); saveLinks(all)
    }

    @Synchronized fun unlink(project: String) {
        val all = links(); all.remove(project); saveLinks(all)
    }

    fun describe(project: String): JSONObject {
        val l = linkOf(project) ?: return JSONObject().put("linked", false)
        return JSONObject().put("linked", true).put("type", l.optString("type"))
            .put("label", l.optString("label"))
    }

    private fun persist(uri: Uri, write: Boolean) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or (if (write) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        try { cr.takePersistableUriPermission(uri, flags) } catch (_: Exception) {
            try { cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return (if (ext.isEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext))
            ?: "application/octet-stream"
    }

    private fun displayName(uri: Uri): String {
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val s = c.getString(0)
                if (!s.isNullOrBlank()) return s
            }
        }
        return "ficheiro.txt"
    }

    // ---------- Abrir pasta do armazenamento ----------

    /** Copia a pasta escolhida para um projeto e liga-o. Devolve o nome do projeto. */
    fun importTree(uri: Uri): String {
        persist(uri, true)
        val root = DocumentFile.fromTreeUri(ctx, uri) ?: throw IOException("Pasta inválida.")
        require(root.isDirectory) { "Escolhe uma pasta." }
        val label = root.name ?: "pasta"
        var name: String? = null
        val all = links()
        for (k in all.keys()) {
            val l = all.optJSONObject(k) ?: continue
            if (l.optString("type") == "tree" && l.optString("uri") == uri.toString() && store.projectExists(k)) { name = k; break }
        }
        val project = name ?: store.newProjectName(label)
        try {
            pullTree(project, root)
        } catch (e: Exception) {
            if (name == null) { try { store.deleteProject(project) } catch (_: Exception) { } }
            throw e
        }
        setLink(project, JSONObject().put("type", "tree").put("uri", uri.toString()).put("label", label))
        return project
    }

    private class Counter { var files = 0; var bytes = 0L }

    private fun pullTree(project: String, root: DocumentFile) {
        pull(store.dirOf(project), root, Counter())
    }

    private fun pull(dir: File, doc: DocumentFile, c: Counter) {
        for (child in doc.listFiles()) {
            val n = child.name ?: continue
            if (n == "." || n == ".." || n.contains('/')) continue
            if (child.isDirectory) {
                if (n in SKIP_DIRS) continue
                val d = File(dir, n)
                d.mkdirs()
                pull(d, child, c)
            } else if (child.isFile) {
                c.files++
                if (c.files > MAX_FILES) throw IOException("Pasta com demasiados ficheiros (máx. $MAX_FILES). Escolhe uma subpasta.")
                val len = child.length()
                if (len > MAX_FILE) continue
                c.bytes += len
                if (c.bytes > MAX_TOTAL) throw IOException("Pasta demasiado grande (máx. 120 MB). Escolhe uma subpasta.")
                val ins = cr.openInputStream(child.uri) ?: continue
                ins.use { i -> File(dir, n).outputStream().use { o -> i.copyTo(o) } }
            }
        }
    }

    /** Volta a ler do armazenamento (sobrepõe os ficheiros locais com o conteúdo do armazenamento). */
    fun refresh(project: String) {
        val l = linkOf(project) ?: throw IOException("Este projeto não está ligado ao armazenamento.")
        when (l.optString("type")) {
            "tree" -> {
                val root = DocumentFile.fromTreeUri(ctx, Uri.parse(l.getString("uri")))
                    ?: throw IOException("Não foi possível abrir a pasta (permissão perdida?).")
                pullTree(project, root)
            }
            "files" -> {
                val map = l.optJSONObject("map") ?: return
                val dir = store.dirOf(project)
                for (rel in map.keys()) {
                    val ins = cr.openInputStream(Uri.parse(map.getString(rel))) ?: continue
                    ins.use { i -> File(dir, rel).outputStream().use { o -> i.copyTo(o) } }
                }
            }
        }
    }

    // ---------- Abrir ficheiros soltos ----------

    /** Copia o ficheiro para o projeto "Ficheiros avulsos" e liga-o. Devolve o caminho relativo. */
    fun importFile(uri: Uri): String {
        persist(uri, true)
        val dispName = displayName(uri).replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (!store.projectExists(LOOSE_PROJECT)) store.createProject(LOOSE_PROJECT)
        val dir = store.dirOf(LOOSE_PROJECT)
        val link = linkOf(LOOSE_PROJECT) ?: JSONObject().put("type", "files").put("label", LOOSE_PROJECT)
        val map = link.optJSONObject("map") ?: JSONObject()
        // reutiliza o mesmo ficheiro se já estava aberto; senão escolhe um nome livre
        var found: String? = null
        for (k in map.keys()) if (map.getString(k) == uri.toString()) found = k
        var rel: String = found ?: dispName
        if (found == null) {
            var i = 2
            while (map.has(rel)) {
                val dot = dispName.lastIndexOf('.')
                rel = if (dot > 0) dispName.substring(0, dot) + "-" + i + dispName.substring(dot) else "$dispName-$i"
                i++
            }
        }
        val ins = cr.openInputStream(uri) ?: throw IOException("Não foi possível ler o ficheiro.")
        ins.use { i -> File(dir, rel).outputStream().use { o -> i.copyTo(o) } }
        map.put(rel, uri.toString())
        link.put("map", map)
        setLink(LOOSE_PROJECT, link)
        return rel
    }

    // ---------- Espelho (projeto -> armazenamento) ----------

    private fun treeRoot(project: String): DocumentFile? {
        val l = linkOf(project) ?: return null
        if (l.optString("type") != "tree") return null
        return DocumentFile.fromTreeUri(ctx, Uri.parse(l.getString("uri")))
    }

    private fun docAt(root: DocumentFile, rel: String, createDirs: Boolean): DocumentFile? {
        var cur: DocumentFile = root
        for (part in rel.split('/')) {
            if (part.isEmpty()) continue
            val next = cur.findFile(part)
            cur = if (next != null) next
            else if (createDirs) (cur.createDirectory(part) ?: return null)
            else return null
        }
        return cur
    }

    private fun report(project: String, rel: String, e: Exception) {
        val now = System.currentTimeMillis()
        if (now - lastErrorAt < 3000) return
        lastErrorAt = now
        emit(JSONObject().put("type", "sync").put("ok", false).put("project", project).put("path", rel)
            .put("error", e.message ?: e.javaClass.simpleName))
    }

    private fun queue(project: String, rel: String, job: () -> Unit) {
        if (linkOf(project) == null) return
        exec.execute {
            try { job() } catch (e: Exception) { report(project, rel, e) }
        }
    }

    private fun writeNow(project: String, rel: String, file: File) {
        val l = linkOf(project) ?: return
        if (!file.isFile) return
        val bytes = file.readBytes()
        if (l.optString("type") == "files") {
            val u = l.optJSONObject("map")?.optString(rel, "") ?: ""
            if (u.isEmpty()) return
            val os = cr.openOutputStream(Uri.parse(u), "wt") ?: throw IOException("Não foi possível escrever no armazenamento.")
            os.use { it.write(bytes) }
            return
        }
        val root = treeRoot(project) ?: throw IOException("Permissão da pasta perdida: volta a abrir a pasta.")
        val parentRel = if (rel.contains('/')) rel.substringBeforeLast('/') else ""
        val name = rel.substringAfterLast('/')
        val parent = docAt(root, parentRel, true) ?: throw IOException("Não foi possível criar a pasta de destino.")
        val doc = parent.findFile(name) ?: parent.createFile(mimeOf(name), name)
            ?: throw IOException("Não foi possível criar “$name” no armazenamento.")
        val os = cr.openOutputStream(doc.uri, "wt") ?: throw IOException("Não foi possível escrever “$name”.")
        os.use { it.write(bytes) }
    }

    override fun onWrite(project: String, rel: String, file: File) {
        queue(project, rel) { writeNow(project, rel, file) }
    }

    override fun onMkdir(project: String, rel: String) {
        queue(project, rel) {
            val root = treeRoot(project) ?: return@queue
            docAt(root, rel, true)
        }
    }

    override fun onDelete(project: String, rel: String) {
        queue(project, rel) {
            val l = linkOf(project) ?: return@queue
            if (l.optString("type") == "files") {
                // não apagamos ficheiros originais soltos; só deixam de estar ligados
                val map = l.optJSONObject("map")
                if (map != null && map.has(rel)) { map.remove(rel); setLink(project, l) }
                return@queue
            }
            val root = treeRoot(project) ?: return@queue
            docAt(root, rel, false)?.delete()
        }
    }

    override fun onRename(project: String, from: String, to: String) {
        queue(project, from) {
            val l = linkOf(project) ?: return@queue
            if (l.optString("type") == "files") {
                val map = l.optJSONObject("map")
                if (map != null && map.has(from)) { val u = map.getString(from); map.remove(from); map.put(to, u); setLink(project, l) }
                return@queue
            }
            val root = treeRoot(project) ?: return@queue
            val doc = docAt(root, from, false)
            val sameParent = from.substringBeforeLast('/', "") == to.substringBeforeLast('/', "")
            if (doc != null && sameParent) {
                if (!doc.renameTo(to.substringAfterLast('/'))) throw IOException("Não foi possível renomear no armazenamento.")
            } else {
                doc?.delete()
                pushRecursive(project, to)
            }
        }
    }

    private fun pushRecursive(project: String, rel: String) {
        val f = File(store.dirOf(project), rel)
        if (f.isDirectory) {
            val root = treeRoot(project) ?: return
            docAt(root, rel, true)
            f.listFiles()?.forEach { pushRecursive(project, "$rel/${it.name}") }
        } else if (f.isFile) {
            writeNow(project, rel, f)
        }
    }

    /** Espelha no armazenamento os ficheiros alterados/removidos por operações Git (pull, checkout, descartar). */
    fun mirror(project: String, write: Collection<String>, delete: Collection<String>) {
        if (linkOf(project) == null) return
        val dir = store.dirOf(project)
        for (rel in write) {
            val f = File(dir, rel)
            if (f.isFile) onWrite(project, rel, f)
        }
        for (rel in delete) onDelete(project, rel)
    }

    override fun onProjectRenamed(from: String, to: String) {
        val l = linkOf(from) ?: return
        unlink(from)
        setLink(to, l)
    }

    override fun onProjectDeleted(name: String) {
        // apaga só a ligação: os ficheiros reais no armazenamento ficam intactos
        unlink(name)
    }
}
