package com.codeverse.mobile

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import dalvik.system.DexClassLoader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.io.PrintStream
import java.lang.reflect.InvocationTargetException

/**
 * Executor de Java. Corre no processo separado ":runner" (ver AndroidManifest):
 * compila o projeto (ECJ + D8), carrega o DEX e chama main(). A saída e os erros seguem para a
 * interface por mensagens; a entrada (System.in) vem das mensagens MSG_STDIN.
 */
class RunnerService : Service() {

    private lateinit var ctl: HandlerThread
    private lateinit var messenger: Messenger
    @Volatile private var reply: Messenger? = null
    @Volatile private var stdinOut: PipedOutputStream? = null

    override fun onCreate() {
        super.onCreate()
        ctl = HandlerThread("cv-runner-ctl").also { it.start() }
        messenger = Messenger(Handler(ctl.looper) { msg -> handle(msg); true })
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onDestroy() {
        // processo dedicado: terminar garante memória e estado limpos na próxima execução
        android.os.Process.killProcess(android.os.Process.myPid())
        super.onDestroy()
    }

    private fun handle(msg: Message) {
        when (msg.what) {
            RunnerProtocol.MSG_RUN -> {
                reply = msg.replyTo
                val d = msg.data
                val src = d.getString(RunnerProtocol.K_SRC) ?: return
                val main = d.getString(RunnerProtocol.K_MAIN) ?: return
                val level = d.getString(RunnerProtocol.K_LEVEL) ?: "1.8"
                val group = ThreadGroup("cv-user")
                // pilha grande: o compilador e programas recursivos precisam dela
                Thread(group, { job(group, src, main, level) }, "cv-job", 64L * 1024 * 1024).start()
            }
            RunnerProtocol.MSG_STDIN -> {
                val text = msg.data?.getString(RunnerProtocol.K_TEXT) ?: return
                try {
                    stdinOut?.write(text.toByteArray(Charsets.UTF_8))
                    stdinOut?.flush()
                } catch (_: Exception) { }
            }
            RunnerProtocol.MSG_KILL -> android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    private fun send(what: Int, text: String? = null, code: Int = 0, compile: Boolean = false, log: Boolean = false) {
        val m = Message.obtain(null, what, code, 0)
        m.data = Bundle().apply {
            if (text != null) putString(RunnerProtocol.K_TEXT, text)
            putBoolean(RunnerProtocol.K_COMPILE, compile)
            putBoolean(RunnerProtocol.K_LOG, log)
        }
        try { reply?.send(m) } catch (_: Exception) { }
    }

    /** Junta a saída em blocos (evita uma mensagem por println) e limita o total. */
    private inner class Sink(private val what: Int) : OutputStream() {
        private val buf = ByteArrayOutputStream()
        private var total = 0L
        private var truncated = false

        @Synchronized override fun write(b: Int) { buf.write(b) }
        @Synchronized override fun write(b: ByteArray, off: Int, len: Int) { buf.write(b, off, len) }

        @Synchronized fun drain() {
            if (buf.size() == 0) return
            val text = buf.toString("UTF-8")
            buf.reset()
            total += text.length
            if (total > 4_000_000) {
                if (!truncated) { truncated = true; send(what, "\n[saída truncada: demasiado texto]\n") }
                return
            }
            send(what, text)
        }
    }

    private fun job(group: ThreadGroup, src: String, mainRel: String, level: String) {
        val outSink = Sink(RunnerProtocol.MSG_OUT)
        val errSink = Sink(RunnerProtocol.MSG_ERR)
        val flusher = Thread {
            while (true) {
                try { Thread.sleep(40) } catch (_: InterruptedException) { break }
                outSink.drain(); errSink.drain()
            }
        }.also { it.isDaemon = true; it.start() }

        var code = 0
        var compileFailed = false
        try {
            send(RunnerProtocol.MSG_PHASE, "A compilar…", log = true)
            val work = File(cacheDir, "jrun").apply { deleteRecursively(); mkdirs() }
            val srcDir = File(src)
            val result = JavaToolchain.build(applicationContext, srcDir, work, level)
            if (result.error != null) {
                send(RunnerProtocol.MSG_ERR, result.error + "\n")
                code = 1; compileFailed = true
            } else {
                send(RunnerProtocol.MSG_PHASE, "A executar…")
                code = runMain(group, result.dex, JavaToolchain.mainClassOf(srcDir, mainRel), outSink, errSink)
            }
        } catch (t: Throwable) {
            send(RunnerProtocol.MSG_ERR, "Erro interno do executor: $t\n")
            code = 1
        } finally {
            flusher.interrupt()
            outSink.drain(); errSink.drain()
            send(RunnerProtocol.MSG_DONE, null, code, compileFailed)
        }
    }

    private fun runMain(group: ThreadGroup, dex: List<File>, cls: String, out: Sink, err: Sink): Int {
        val pin = PipedInputStream(1 shl 16)
        stdinOut = PipedOutputStream(pin)
        System.setIn(pin)
        System.setOut(PrintStream(out, true, "UTF-8"))
        System.setErr(PrintStream(err, true, "UTF-8"))
        // Android 14+: o DEX carregado tem de ser só de leitura
        dex.forEach { it.setReadOnly() }
        val loader = DexClassLoader(dex.joinToString(File.pathSeparator) { it.absolutePath }, null, null, classLoader)
        val baseline = group.activeCount()
        return try {
            val c = loader.loadClass(cls)
            val m = c.getMethod("main", Array<String>::class.java)
            m.invoke(null, arrayOf<String>())
            // como numa JVM: espera pelas threads que o programa tenha deixado a correr
            while (group.activeCount() > baseline) Thread.sleep(50)
            0
        } catch (e: InvocationTargetException) {
            e.targetException.printStackTrace()
            1
        } catch (e: ClassNotFoundException) {
            System.err.println("Classe principal não encontrada: $cls")
            1
        } catch (e: NoSuchMethodException) {
            System.err.println("A classe $cls não tem \"public static void main(String[] args)\".")
            1
        } catch (e: Throwable) {
            e.printStackTrace()
            1
        } finally {
            System.out.flush()
            System.err.flush()
        }
    }
}
