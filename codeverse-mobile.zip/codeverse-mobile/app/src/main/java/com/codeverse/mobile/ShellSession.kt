package com.codeverse.mobile

import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Terminal: shell do Android (/system/bin/sh, mksh) em modo interativo, ligada ao ecrã Terminal.
 * Corre na pasta do projeto aberto (ou na pasta home da app), sem root. Os comandos (ls, cat, grep, ps...)
 * são os do toybox do próprio Android; o aspeto "Linux" (prompt, cores, aliases) é feito no ecrã (app.js).
 * Eventos para o JS: CV_onNative({type:'shell', id, kind:'out'|'done', text|code}).
 */
class ShellSession(
    private val home: File,
    private val emit: (JSONObject) -> Unit
) {

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var currentId: String? = null
    private val lock = Any()

    fun start(id: String, cwd: File?) {
        synchronized(lock) {
            stopLocked()
            val dir = (cwd ?: home).also { it.mkdirs() }
            val pb = ProcessBuilder("/system/bin/sh", "-i")
            pb.directory(dir)
            pb.redirectErrorStream(true)
            val env = pb.environment()
            env["HOME"] = home.absolutePath
            env["TMPDIR"] = File(home, "tmp").also { it.mkdirs() }.absolutePath
            env["TERM"] = "xterm-256color"
            env["USER"] = "dev"
            env["LOGNAME"] = "dev"
            env["HOSTNAME"] = "codeverse"
            env["LANG"] = "en_US.UTF-8"
            // Prompt = marca para o ecrã (pasta, pasta home, pid); PS2 = linha de continuação.
            // ${PWD}/${HOME}/$$ ficam por expandir aqui de propósito: a shell expande o PS1 sempre que o mostra.
            env["PS1"] = "\u0001CV\${PWD}\u0002\${HOME}\u0002\$\$\u0001"
            env["PS2"] = "\u0001C2\u0001"
            val p = try {
                pb.start()
            } catch (e: Exception) {
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", 127)
                    .put("text", "Não foi possível iniciar a shell: ${e.message}"))
                return
            }
            proc = p
            out = p.outputStream
            currentId = id
            Thread { pump(id, p.inputStream, p) }.apply { isDaemon = true }.start()
        }
    }

    private fun pump(id: String, input: InputStream, p: Process) {
        val buf = ByteArray(4096)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                    .put("text", String(buf, 0, n, Charsets.UTF_8)))
            }
        } catch (_: Exception) { }
        val code = try { p.waitFor() } catch (_: Exception) { 1 }
        synchronized(lock) { if (currentId == id) { proc = null; out = null; currentId = null } }
        emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", code))
    }

    fun input(id: String, text: String) {
        synchronized(lock) {
            if (id != currentId) return
            try { out?.write(text.toByteArray(Charsets.UTF_8)); out?.flush() } catch (_: Exception) { }
        }
    }

    /**
     * Ctrl+C: envia SIGINT ao comando em curso (filhos da shell) ou, com [self], à própria shell
     * (cancela uma linha de continuação). Usa o kill/pkill do toybox do Android.
     */
    fun interrupt(id: String, pid: Int, self: Boolean): Boolean {
        synchronized(lock) { if (id != currentId) return false }
        if (pid <= 1) return false
        val args = if (self) listOf("/system/bin/kill", "-INT", pid.toString())
                   else listOf("/system/bin/pkill", "-INT", "-P", pid.toString())
        return try { ProcessBuilder(args).redirectErrorStream(true).start().waitFor(); true } catch (_: Exception) { false }
    }

    fun stop(id: String) {
        synchronized(lock) { if (id == currentId) stopLocked() }
    }

    fun stopAll() { synchronized(lock) { stopLocked() } }

    private fun stopLocked() {
        try { proc?.destroy() } catch (_: Exception) { }
        proc = null; out = null; currentId = null
    }
}
