package com.codeverse.mobile

import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Terminal Linux: uma shell real (/system/bin/sh do Android, que é Linux) ligada ao ecrã Terminal.
 * Corre na pasta do projeto aberto (ou na pasta home da app). Sem root e sem rede obrigatória.
 * Eventos para o JS: CV_onNative({type:'shell', id, kind:'out'|'done', text|code}).
 */
class ShellSession(private val home: File, private val emit: (JSONObject) -> Unit) {

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var currentId: String? = null
    private val lock = Any()

    fun start(id: String, cwd: File?) {
        synchronized(lock) {
            stopLocked()
            val dir = (cwd ?: home).also { it.mkdirs() }
            val pb = ProcessBuilder("/system/bin/sh")
            pb.directory(dir)
            pb.redirectErrorStream(true)
            val env = pb.environment()
            env["HOME"] = home.absolutePath
            env["TMPDIR"] = File(home, "tmp").also { it.mkdirs() }.absolutePath
            env["TERM"] = "dumb"
            env["PS1"] = "\\$ "
            env["PATH"] = (env["PATH"] ?: "/system/bin:/system/xbin")
            val p = try {
                pb.start()
            } catch (e: Exception) {
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", 127)
                    .put("text", "Não foi possível iniciar a shell: ${e.message}"))
                return
            }
            proc = p
            out = p.outputStream
            currentId = id
            Thread { pump(id, p.inputStream, p) }.apply { isDaemon = true }.start()
        }
    }

    private fun pump(id: String, input: InputStream, p: Process) {
        val buf = ByteArray(4096)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                    .put("text", String(buf, 0, n, Charsets.UTF_8)))
            }
        } catch (_: Exception) { }
        val code = try { p.waitFor() } catch (_: Exception) { 1 }
        synchronized(lock) { if (currentId == id) { proc = null; out = null; currentId = null } }
        emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", code))
    }

    fun input(id: String, text: String) {
        synchronized(lock) {
            if (id != currentId) return
            try { out?.write(text.toByteArray(Charsets.UTF_8)); out?.flush() } catch (_: Exception) { }
        }
    }

    fun stop(id: String) {
        synchronized(lock) { if (id == currentId) stopLocked() }
    }

    fun stopAll() { synchronized(lock) { stopLocked() } }

    private fun stopLocked() {
        try { proc?.destroy() } catch (_: Exception) { }
        proc = null; out = null; currentId = null
    }
}
