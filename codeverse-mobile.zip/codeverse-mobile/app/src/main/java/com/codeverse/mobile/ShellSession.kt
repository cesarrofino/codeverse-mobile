package com.codeverse.mobile

import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Terminal Linux: shell BusyBox (ash) em modo interativo, ligada ao ecrã Terminal.
 * O BusyBox vai dentro do APK como libbusybox.so, em app/src/main/jniLibs — essa é a ÚNICA pasta da app de
 * onde o Android (desde o 10) deixa executar ficheiros; qualquer cópia ou atalho para a pasta privada da
 * app (filesDir) é bloqueado pelo sistema. O BusyBox tem de ser compilado contra o bionic (NDK): um binário
 * estático musl faz syscalls que o filtro seccomp do Android proíbe e o processo é morto com SIGSYS (código 159).
 * Se mesmo assim isso acontecer, a sessão recomeça sozinha com /system/bin/sh.
 * Por isso os comandos (ls, grep, sed, awk, tar, wget...) não são ficheiros à parte: são funções criadas
 * dentro da própria shell que chamam sempre o mesmo libbusybox.so, só isso é executado. Sem BusyBox, usa a
 * shell do Android (/system/bin/sh). Corre na pasta do projeto aberto (ou na pasta home da app), sem root.
 * Eventos para o JS: CV_onNative({type:'shell', id, kind:'out'|'done', text|code}).
 */
class ShellSession(
    private val home: File,
    private val nativeDir: File,
    private val emit: (JSONObject) -> Unit
) {

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var currentId: String? = null
    private val lock = Any()

    private val busybox get() = File(nativeDir, "libbusybox.so")

    // Nomes que a própria shell já trata (builtins) ou de que não é seguro fazer função — ficam como estão,
    // para não alterar o comportamento normal da shell.
    private val reserved = setOf(
        "sh", "ash", "busybox", "cd", "exit", "exec", "export", "read", "set", "shift", "trap",
        "unset", "eval", "wait", "umask", "ulimit", "times", "true", "false", "test", "[", ".", ":",
        "type", "command", "alias", "unalias", "local", "return", "break", "continue", "source",
        "echo", "printf", "pwd", "kill", "jobs", "bg", "fg"
    )

    private fun appletNames(): List<String> = try {
        val p = ProcessBuilder(busybox.absolutePath, "--list").redirectErrorStream(true).start()
        val names = p.inputStream.bufferedReader().readLines()
            .map { it.trim() }
            .filter { it.matches(Regex("[A-Za-z][A-Za-z0-9_]*")) && it !in reserved }
        p.waitFor()
        names
    } catch (_: Exception) { emptyList() }

    /** Script enviado à shell no arranque: uma função por comando do BusyBox, ex. ls() { "$BB" ls "$@"; } */
    private fun functionsScript(): String {
        val sb = StringBuilder("BB='").append(busybox.absolutePath).append("'\n")
        for (n in appletNames()) {
            if (n == "ls") sb.append("ls() { \"\$BB\" ls --color=always \"\$@\"; }\n")
            else sb.append(n).append("() { \"\$BB\" ").append(n).append(" \"\$@\"; }\n")
        }
        return sb.toString()
    }

    /** O BusyBox só é usado se arrancar de facto (um binário que o Android mata com SIGSYS é descartado). */
    private fun busyboxWorks(): Boolean = try {
        if (!busybox.exists()) false
        else {
            val p = ProcessBuilder(busybox.absolutePath, "true").redirectErrorStream(true).start()
            p.waitFor() == 0
        }
    } catch (_: Exception) { false }

    fun start(id: String, cwd: File?) {
        synchronized(lock) {
            stopLocked()
            launch(id, cwd, busyboxWorks(), false)
        }
    }

    private fun launch(id: String, cwd: File?, hasBb: Boolean, fellBack: Boolean) {
        val dir = (cwd ?: home).also { it.mkdirs() }
        val pb = if (hasBb) ProcessBuilder(busybox.absolutePath, "sh", "-i") else ProcessBuilder("/system/bin/sh", "-i")
        pb.directory(dir)
        pb.redirectErrorStream(true)
        val env = pb.environment()
        env["HOME"] = home.absolutePath
        env["TMPDIR"] = File(home, "tmp").also { it.mkdirs() }.absolutePath
        env["TERM"] = "xterm-256color"
        env["USER"] = "dev"
        env["LOGNAME"] = "dev"
        env["HOSTNAME"] = "codeverse"
        env["LANG"] = "en_US.UTF-8"
        // Prompt = marca para o ecrã (pasta, pasta home, pid); PS2 = linha de continuação.
        // ${PWD}/${HOME}/$$ ficam por expandir aqui de propósito: a shell expande o PS1 sempre que o mostra.
        env["PS1"] = "\u0001CV\${PWD}\u0002\${HOME}\u0002\$\$\u0001"
        env["PS2"] = "\u0001C2\u0001"
        if (hasBb) env["SHELL"] = busybox.absolutePath
        val p = try {
            pb.start()
        } catch (e: Exception) {
            emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", 127)
                .put("text", "Não foi possível iniciar a shell: ${e.message}"))
            return
        }
        proc = p
        out = p.outputStream
        currentId = id
        if (hasBb) {
            try { out?.write(functionsScript().toByteArray(Charsets.UTF_8)); out?.flush() } catch (_: Exception) { }
        }
        val t0 = System.currentTimeMillis()
        Thread { pump(id, p.inputStream, p, hasBb, fellBack, cwd, t0) }.apply { isDaemon = true }.start()
    }

    private fun pump(id: String, input: InputStream, p: Process, usedBb: Boolean, fellBack: Boolean, cwd: File?, t0: Long) {
        val buf = ByteArray(4096)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                    .put("text", String(buf, 0, n, Charsets.UTF_8)))
            }
        } catch (_: Exception) { }
        val code = try { p.waitFor() } catch (_: Exception) { 1 }
        // Se o BusyBox morreu logo no arranque (159 = SIGSYS, bloqueado pelo Android), repete com a shell do sistema.
        if (usedBb && !fellBack && code == 159 && System.currentTimeMillis() - t0 < 10_000) {
            synchronized(lock) {
                if (currentId == id) {
                    emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                        .put("text", "[BusyBox bloqueado pelo Android (SIGSYS); a usar /system/bin/sh]\r\n"))
                    proc = null; out = null
                    launch(id, cwd, false, true)
                    return
                }
            }
        }
        synchronized(lock) { if (currentId == id) { proc = null; out = null; currentId = null } }
        emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", code))
    }

    fun input(id: String, text: String) {
        synchronized(lock) {
            if (id != currentId) return
            try { out?.write(text.toByteArray(Charsets.UTF_8)); out?.flush() } catch (_: Exception) { }
        }
    }

    /**
     * Ctrl+C: envia SIGINT ao comando em curso (filhos da shell) ou, com [self], à própria shell
     * (cancela uma linha de continuação). Só funciona com BusyBox (precisa do applet kill/pkill).
     */
    fun interrupt(id: String, pid: Int, self: Boolean): Boolean {
        synchronized(lock) { if (id != currentId) return false }
        if (pid <= 1 || !busybox.exists()) return false
        val args = if (self) listOf(busybox.absolutePath, "kill", "-INT", pid.toString())
                   else listOf(busybox.absolutePath, "pkill", "-INT", "-P", pid.toString())
        return try { ProcessBuilder(args).redirectErrorStream(true).start().waitFor(); true } catch (_: Exception) { false }
    }

    fun stop(id: String) {
        synchronized(lock) { if (id == currentId) stopLocked() }
    }

    fun stopAll() { synchronized(lock) { stopLocked() } }

    private fun stopLocked() {
        try { proc?.destroy() } catch (_: Exception) { }
        proc = null; out = null; currentId = null
    }
}
