package com.codeverse.mobile

import android.system.Os
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Terminal Linux: shell BusyBox (ash) em modo interativo, ligada ao ecrã Terminal.
 * O BusyBox vai dentro do APK como libbusybox.so (o workflow descarrega-o para app/src/main/jniLibs) e os
 * comandos (ls, grep, sed, awk, tar, wget, vi...) são atalhos criados em filesDir/bin. Sem BusyBox, usa a
 * shell do Android (/system/bin/sh). Corre na pasta do projeto aberto (ou na pasta home da app), sem root.
 * Eventos para o JS: CV_onNative({type:'shell', id, kind:'out'|'done', text|code}).
 */
class ShellSession(
    private val home: File,
    private val nativeDir: File,
    private val emit: (JSONObject) -> Unit
) {

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var currentId: String? = null
    private val lock = Any()

    private val busybox get() = File(nativeDir, "libbusybox.so")
    private val binDir get() = File(home.parentFile ?: home, "bin")

    /** Cria os atalhos dos comandos BusyBox (uma vez por instalação). Devolve false se não houver BusyBox. */
    private fun setupBin(): Boolean {
        val bb = busybox
        if (!bb.exists()) return false
        return try {
            binDir.mkdirs()
            val stamp = bb.absolutePath + ":" + bb.length()
            val mark = File(binDir, ".ver")
            if (mark.exists() && mark.readText() == stamp) return true
            val p = ProcessBuilder(bb.absolutePath, "--list").redirectErrorStream(true).start()
            val names = p.inputStream.bufferedReader().readLines()
                .map { it.trim() }.filter { it.matches(Regex("[A-Za-z0-9._\\[-]+")) }
            p.waitFor()
            if (names.isEmpty()) return false
            for (n in names) {
                val link = File(binDir, n)
                try { link.delete(); Os.symlink(bb.absolutePath, link.absolutePath) } catch (_: Exception) { }
            }
            mark.writeText(stamp)
            true
        } catch (_: Exception) { false }
    }

    fun start(id: String, cwd: File?) {
        synchronized(lock) {
            stopLocked()
            val dir = (cwd ?: home).also { it.mkdirs() }
            val hasBb = setupBin()
            val pb = if (hasBb) ProcessBuilder(busybox.absolutePath, "sh", "-i") else ProcessBuilder("/system/bin/sh", "-i")
            pb.directory(dir)
            pb.redirectErrorStream(true)
            val env = pb.environment()
            env["HOME"] = home.absolutePath
            env["TMPDIR"] = File(home, "tmp").also { it.mkdirs() }.absolutePath
            env["TERM"] = "xterm-256color"
            env["USER"] = "dev"
            env["LOGNAME"] = "dev"
            env["HOSTNAME"] = "codeverse"
            env["LANG"] = "en_US.UTF-8"
            // Prompt = marca para o ecrã (pasta, pasta home, pid); PS2 = linha de continuação
            env["PS1"] = "\u0001CV\${PWD}\u0002\${HOME}\u0002\$\$\u0001"
            env["PS2"] = "\u0001C2\u0001"
            val sys = env["PATH"] ?: "/system/bin:/system/xbin"
            env["PATH"] = if (hasBb) binDir.absolutePath + ":" + sys else sys
            if (hasBb) env["SHELL"] = File(binDir, "sh").absolutePath
            val p = try {
                pb.start()
            } catch (e: Exception) {
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", 127)
                    .put("text", "Não foi possível iniciar a shell: ${e.message}"))
                return
            }
            proc = p
            out = p.outputStream
            currentId = id
            Thread { pump(id, p.inputStream, p) }.apply { isDaemon = true }.start()
            if (!hasBb) {
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                    .put("text", "[aviso] BusyBox indisponível (" + (if (!busybox.exists())
                        "libbusybox.so não está no APK; ficheiros em lib: " + (nativeDir.list()?.joinToString(",").orEmpty().ifEmpty { "nenhum" })
                        else "não foi possível preparar os comandos") + "); a usar a shell do Android.\n"))
            }
        }
    }

    private fun pump(id: String, input: InputStream, p: Process) {
        val buf = ByteArray(4096)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                emit(JSONObject().put("type", "shell").put("id", id).put("kind", "out")
                    .put("text", String(buf, 0, n, Charsets.UTF_8)))
            }
        } catch (_: Exception) { }
        val code = try { p.waitFor() } catch (_: Exception) { 1 }
        synchronized(lock) { if (currentId == id) { proc = null; out = null; currentId = null } }
        emit(JSONObject().put("type", "shell").put("id", id).put("kind", "done").put("code", code))
    }

    fun input(id: String, text: String) {
        synchronized(lock) {
            if (id != currentId) return
            try { out?.write(text.toByteArray(Charsets.UTF_8)); out?.flush() } catch (_: Exception) { }
        }
    }

    /**
     * Ctrl+C: envia SIGINT ao comando em curso (filhos da shell) ou, com [self], à própria shell
     * (cancela uma linha de continuação). Precisa dos atalhos BusyBox (pkill/kill).
     */
    fun interrupt(id: String, pid: Int, self: Boolean): Boolean {
        synchronized(lock) { if (id != currentId) return false }
        if (pid <= 1) return false
        val tool = File(binDir, if (self) "kill" else "pkill")
        if (!tool.exists()) return false
        val args = if (self) listOf(tool.absolutePath, "-INT", pid.toString())
                   else listOf(tool.absolutePath, "-INT", "-P", pid.toString())
        return try { ProcessBuilder(args).redirectErrorStream(true).start().waitFor(); true } catch (_: Exception) { false }
    }

    fun stop(id: String) {
        synchronized(lock) { if (id == currentId) stopLocked() }
    }

    fun stopAll() { synchronized(lock) { stopLocked() } }

    private fun stopLocked() {
        try { proc?.destroy() } catch (_: Exception) { }
        proc = null; out = null; currentId = null
    }
}
