package com.codeverse.mobile

/** Mensagens trocadas entre a app (processo principal) e o executor Java (processo ":runner"). */
object RunnerProtocol {
    // app -> executor
    const val MSG_RUN = 1
    const val MSG_STDIN = 2
    const val MSG_KILL = 3

    // executor -> app
    const val MSG_PHASE = 10
    const val MSG_OUT = 11
    const val MSG_ERR = 12
    const val MSG_DONE = 13

    const val K_SRC = "src"
    const val K_MAIN = "main"
    const val K_LEVEL = "level"
    const val K_TEXT = "text"
    const val K_LOG = "log"
    const val K_COMPILE = "compile"
}
