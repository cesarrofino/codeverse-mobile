package javax.lang.model

/**
 * O Android não traz o pacote javax.lang.model (é do JDK), mas o compilador ECJ referencia
 * SourceVersion. Esta versão mínima, igual à do JDK, evita o NoClassDefFoundError.
 */
enum class SourceVersion {
    RELEASE_0, RELEASE_1, RELEASE_2, RELEASE_3, RELEASE_4, RELEASE_5, RELEASE_6, RELEASE_7, RELEASE_8,
    RELEASE_9, RELEASE_10, RELEASE_11, RELEASE_12, RELEASE_13, RELEASE_14, RELEASE_15, RELEASE_16,
    RELEASE_17, RELEASE_18, RELEASE_19, RELEASE_20, RELEASE_21;

    companion object {
        private val KEYWORDS = setOf(
            "abstract", "continue", "for", "new", "switch", "assert", "default", "if", "package", "synchronized",
            "boolean", "do", "goto", "private", "this", "break", "double", "implements", "protected", "throw",
            "byte", "else", "import", "public", "throws", "case", "enum", "instanceof", "return", "transient",
            "catch", "extends", "int", "short", "try", "char", "final", "interface", "static", "void",
            "class", "finally", "long", "strictfp", "volatile", "const", "float", "native", "super", "while",
            "_", "true", "false", "null"
        )

        @JvmStatic fun latest(): SourceVersion = RELEASE_21

        @JvmStatic fun latestSupported(): SourceVersion = RELEASE_17

        @JvmStatic fun isIdentifier(name: CharSequence): Boolean {
            val s = name.toString()
            if (s.isEmpty() || !Character.isJavaIdentifierStart(s[0])) return false
            for (i in 1 until s.length) if (!Character.isJavaIdentifierPart(s[i])) return false
            return true
        }

        @JvmStatic fun isKeyword(s: CharSequence): Boolean = s.toString() in KEYWORDS

        @JvmStatic fun isKeyword(s: CharSequence, version: SourceVersion): Boolean = s.toString() in KEYWORDS

        @JvmStatic fun isName(name: CharSequence): Boolean {
            val s = name.toString()
            if (s.isEmpty()) return false
            return s.split('.').all { isIdentifier(it) && !isKeyword(it) }
        }

        @JvmStatic fun isName(name: CharSequence, version: SourceVersion): Boolean = isName(name)
    }
}
