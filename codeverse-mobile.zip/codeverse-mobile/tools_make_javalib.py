"""Gera app/src/main/assets/java/rt.jar a partir do android.jar do SDK.

O compilador Java offline (ECJ) precisa das classes da biblioteca padrão (java.*, javax.*) para compilar
os programas do utilizador. Em vez de enviar o android.jar inteiro (~27 MB), guardamos só o necessário.
Uso (corre automaticamente no workflow):  python3 tools_make_javalib.py
"""
import os
import sys
import zipfile

KEEP = ("java/", "javax/", "org/json/")
OUT = os.path.join("app", "src", "main", "assets", "java", "rt.jar")


def find_android_jar():
    sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    candidates = []
    if sdk:
        base = os.path.join(sdk, "platforms")
        if os.path.isdir(base):
            # prefere android-34; senão a plataforma mais recente
            names = sorted(os.listdir(base), key=lambda n: (n != "android-34", n), reverse=False)
            candidates = [os.path.join(base, n, "android.jar") for n in names]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def main():
    jar = find_android_jar()
    if not jar:
        sys.exit("android.jar não encontrado. Define ANDROID_HOME e instala 'platforms;android-34'.")
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    n = 0
    with zipfile.ZipFile(jar) as zin, zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            if info.is_dir() or not info.filename.startswith(KEEP):
                continue
            zout.writestr(info.filename, zin.read(info.filename))
            n += 1
    size = os.path.getsize(OUT) / (1024 * 1024)
    print("rt.jar criado a partir de %s: %d ficheiros, %.1f MB" % (jar, n, size))
    if n < 1000:
        sys.exit("rt.jar parece incompleto (%d ficheiros)." % n)


if __name__ == "__main__":
    main()
