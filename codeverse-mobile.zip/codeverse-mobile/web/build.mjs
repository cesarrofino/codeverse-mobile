// Gera app/src/main/assets/www a partir de web/src (+ Pyodide do npm).
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.resolve(here, '../app/src/main/assets/www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// 1) Editor (CodeMirror 6 + tema Dark+) num único ficheiro
await build({
  entryPoints: [path.join(here, 'src/editor.js')],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['chrome90'],
  outfile: path.join(out, 'editor.bundle.js'),
  legalComments: 'none',
  logLevel: 'info',
});

// 2) Ficheiros estáticos da interface
for (const f of ['index.html', 'icons.js', 'app.js', 'templates.js', 'filetemplates.js', 'plugins.js', 'git.js', 'cloud.js', 'ai.js', 'styles.css', 'python-worker.js']) {
  fs.copyFileSync(path.join(here, 'src', f), path.join(out, f));
}

// 2a) Configuração do assistente de IA: as chaves vêm dos segredos do GitHub (variáveis de ambiente
//     na compilação). Nunca ficam no repositório; ficam dentro do APK gerado.
// Cada segredo pode ter uma ou várias chaves separadas por vírgula (ou por linha).
const keysOf = (v) => String(v || '').split(/[\s,;]+/).map((k) => k.trim()).filter(Boolean);
const gemKeys = keysOf(process.env.GEMINI_KEY);
const orKeys = keysOf(process.env.OPENROUTER_KEY);
const aiCfg = {
  gemini: {
    keys: gemKeys,
    model: (process.env.GEMINI_MODEL || '').trim() || 'gemini-3.8-flash',
    // Opcional: esforço de raciocínio (none, minimal, low, medium, high). Menos raciocínio = resposta mais rápida.
    reasoning: ['none', 'minimal', 'low', 'medium', 'high'].includes((process.env.GEMINI_REASONING || '').trim()) ? process.env.GEMINI_REASONING.trim() : '',
  },
  openrouter: { keys: orKeys, model: (process.env.OPENROUTER_MODEL || '').trim() || 'openrouter/auto' },
};
fs.writeFileSync(path.join(out, 'ai-config.js'), 'window.CV_AI_CONFIG = ' + JSON.stringify(aiCfg) + ';\n');
console.log('IA: ' + gemKeys.length + ' chave(s) Gemini, ' + orKeys.length + ' chave(s) OpenRouter');

// 2b) Loja de plugins incluída (registry.json + plugins/*.json)
fs.cpSync(path.join(here, 'src', 'plugins'), path.join(out, 'plugins'), { recursive: true });

// 3) Pyodide (Python/WebAssembly) para execução 100% offline
const pyDir = path.join(here, 'node_modules', 'pyodide');
if (!fs.existsSync(pyDir)) throw new Error('Pacote "pyodide" não encontrado. Corre "npm install" primeiro.');
const wanted = /^(pyodide(\.asm)?\.(js|mjs|wasm)|python_stdlib\.zip|pyodide-lock\.json)$/;
const pyOut = path.join(out, 'pyodide');
fs.mkdirSync(pyOut, { recursive: true });
const copied = [];
for (const f of fs.readdirSync(pyDir)) {
  if (wanted.test(f)) {
    fs.copyFileSync(path.join(pyDir, f), path.join(pyOut, f));
    copied.push(f);
  }
}
for (const required of ['pyodide.js', 'pyodide.asm.js', 'pyodide.asm.wasm', 'python_stdlib.zip', 'pyodide-lock.json']) {
  if (!copied.includes(required)) throw new Error('Ficheiro Pyodide em falta: ' + required + ' (copiados: ' + copied.join(', ') + ')');
}
console.log('Pyodide copiado:', copied.join(', '));
console.log('Web build concluído em', out);
