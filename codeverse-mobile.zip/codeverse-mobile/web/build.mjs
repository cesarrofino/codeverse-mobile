// Gera app/src/main/assets/www a partir de web/src (+ Pyodide do npm).
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.resolve(here, '../app/src/main/assets/www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// 1) Editor (CodeMirror 6 + tema Dark+) num único ficheiro
await build({
  entryPoints: [path.join(here, 'src/editor.js')],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['chrome90'],
  outfile: path.join(out, 'editor.bundle.js'),
  legalComments: 'none',
  logLevel: 'info',
});

// 2) Ficheiros estáticos da interface
for (const f of ['index.html', 'icons.js', 'app.js', 'templates.js', 'styles.css', 'python-worker.js']) {
  fs.copyFileSync(path.join(here, 'src', f), path.join(out, f));
}

// 3) Pyodide (Python/WebAssembly) para execução 100% offline
const pyDir = path.join(here, 'node_modules', 'pyodide');
if (!fs.existsSync(pyDir)) throw new Error('Pacote "pyodide" não encontrado. Corre "npm install" primeiro.');
const wanted = /^(pyodide(\.asm)?\.(js|mjs|wasm)|python_stdlib\.zip|pyodide-lock\.json)$/;
const pyOut = path.join(out, 'pyodide');
fs.mkdirSync(pyOut, { recursive: true });
const copied = [];
for (const f of fs.readdirSync(pyDir)) {
  if (wanted.test(f)) {
    fs.copyFileSync(path.join(pyDir, f), path.join(pyOut, f));
    copied.push(f);
  }
}
for (const required of ['pyodide.js', 'pyodide.asm.js', 'pyodide.asm.wasm', 'python_stdlib.zip', 'pyodide-lock.json']) {
  if (!copied.includes(required)) throw new Error('Ficheiro Pyodide em falta: ' + required + ' (copiados: ' + copied.join(', ') + ')');
}
console.log('Pyodide copiado:', copied.join(', '));
console.log('Web build concluído em', out);
