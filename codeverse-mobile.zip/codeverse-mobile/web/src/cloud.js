/* CodeVerse — Conta e sincronização na nuvem (interface).
 * Autenticação (Google / GitHub) e sincronização correm no lado nativo (CloudService.kt, Firebase Auth + Firestore);
 * aqui só há o ícone de perfil na barra lateral, o ecrã "Conta" e as reações aos eventos nativos.
 * Usa a API que o app.js entrega em CVCloud.init({...}). */
'use strict';
(function () {
  let A = null;
  const C = {
    info: null,       // último estado enviado pelo nativo: { available, signedIn, user, sync, autoSync, ... }
    busy: '',         // 'google' | 'github' enquanto o início de sessão está aberto
    view: null,       // { render } do ecrã "Conta" se estiver aberto
    reload: null,
  };

  const GOOGLE_G = '<svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>';
  const GITHUB_MARK = '<svg viewBox="0 0 16 16" width="20" height="20" aria-hidden="true" fill="currentColor"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>';

  const user = () => (C.info && C.info.signedIn && C.info.user) || null;

  function initials(u) {
    const s = String((u && (u.name || u.email)) || '?').trim();
    const parts = s.split(/\s+/).filter(Boolean);
    const t = parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : s.slice(0, 2);
    return t.toUpperCase();
  }

  // Foto de perfil com recurso às iniciais se a imagem não carregar (sem rede, URL expirado…)
  function avatar(u, cls) {
    const box = A.el('span', { class: 'avatar ' + (cls || '') });
    const fallback = () => { box.textContent = ''; box.append(A.el('span', { class: 'avatar-ini', text: initials(u) })); };
    if (u && u.photo) {
      const img = A.el('img', { src: u.photo, alt: '', referrerpolicy: 'no-referrer', draggable: 'false' });
      img.addEventListener('error', fallback);
      box.append(img);
    } else fallback();
    return box;
  }

  // ----- ícones de perfil (barra lateral e início) -----
  function paintButton(btn) {
    if (!btn) return;
    btn.textContent = '';
    const u = user();
    btn.classList.toggle('has-avatar', !!u);
    if (u) btn.append(avatar(u, 'small'));
    else btn.innerHTML = A.I.svg('user', 24);
    const st = C.info && C.info.sync;
    if (u && st && (st.state === 'error')) btn.append(A.el('span', { class: 'acct-dot err' }));
    btn.setAttribute('aria-label', u ? 'Conta: ' + u.name : 'Conta (entrar)');
  }
  function paintButtons() {
    paintButton(A.$('#rail-account'));
    paintButton(A.$('#btn-account-home'));
  }

  // ----- texto do estado de sincronização -----
  function syncLine() {
    const s = C.info && C.info.sync;
    if (!s) return { text: '', cls: '' };
    if (!C.info.autoSync) return { text: 'Sincronização automática desligada.', cls: '' };
    if (s.state === 'syncing') return { text: 'A sincronizar…', cls: 'busy' };
    if (s.state === 'offline') return { text: s.error || 'Sem ligação à internet.', cls: 'warn' };
    if (s.state === 'error') return { text: s.error || 'Erro de sincronização.', cls: 'err' };
    return { text: s.last ? 'Sincronizado ' + A.relTime(s.last) : 'Ainda sem sincronizações.', cls: 'ok' };
  }

  // ===================== Ecrã "Conta" =====================
  function open() {
    if (!A.hasNative) { A.toast('As contas só existem dentro da app Android.', true); return; }
    refresh();
    A.openModal((box, close) => {
      const render = () => {
        box.textContent = '';
        box.classList.add('acct');
        const info = C.info || {};
        const u = user();
        if (!info.available) { renderUnavailable(box, close, info); return; }
        if (u) renderProfile(box, close, u, render);
        else renderSignedOut(box, close, render);
      };
      C.view = { render, close };
      render();
    }).then(() => { C.view = null; });
  }

  function renderUnavailable(box, close, info) {
    box.append(
      A.el('h3', { text: 'Conta' }),
      A.el('p', { text: 'O início de sessão e a sincronização ainda não estão ativos neste APK.' }),
      A.el('p', { class: 'acct-note', text: info.reason || 'Falta configurar o Firebase.' }),
      A.el('p', { class: 'acct-note', text: 'O editor funciona na mesma: os teus projetos ficam guardados neste telemóvel.' }),
      A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn', text: 'Fechar', onclick: () => close(null) }))
    );
  }

  function providerButton(kind, label, svg, render) {
    const busy = C.busy === kind;
    return A.el('button', {
      class: 'btn provider ' + kind, disabled: !!C.busy,
      onclick: () => signIn(kind, render),
    }, A.el('span', { class: 'prov-ic', html: svg }), A.el('span', { text: busy ? 'A abrir…' : label }));
  }

  function renderSignedOut(box, close, render) {
    box.append(
      A.el('div', { class: 'acct-hero' },
        A.el('span', { class: 'acct-hero-ic', html: A.I.svg('cloud', 30) }),
        A.el('h3', { text: 'Entrar no CodeVerse' })),
      A.el('p', { text: 'Os teus projetos ficam sincronizados na nuvem: aparecem em todos os dispositivos e recuperas tudo se reinstalares a app.' }),
      providerButton('google', 'Continuar com Google', GOOGLE_G, render),
      providerButton('github', 'Continuar com GitHub', GITHUB_MARK, render),
      A.el('p', { class: 'acct-note', text: 'Não precisas de conta para programar: sem conta, os projetos ficam guardados só neste telemóvel. Podes entrar mais tarde e os projetos existentes são enviados para a tua conta.' }),
      A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn', text: 'Continuar sem conta', onclick: () => close(null) }))
    );
  }

  function renderProfile(box, close, u, render) {
    const line = syncLine();
    const s = (C.info && C.info.sync) || {};
    const prov = u.provider === 'github.com' ? 'GitHub' : u.provider === 'google.com' ? 'Google' : '';
    box.append(...[
      A.el('div', { class: 'acct-head' },
        avatar(u, 'big'),
        A.el('div', { class: 'acct-who' },
          A.el('div', { class: 'acct-name', text: u.name }),
          u.email ? A.el('div', { class: 'acct-mail', text: u.email }) : null,
          prov ? A.el('div', { class: 'acct-prov', text: 'Ligado com ' + prov }) : null)),
      A.el('div', { class: 'acct-sync ' + line.cls },
        A.el('span', { class: 'acct-sync-dot' }),
        A.el('span', { text: line.text })),
      s.skipped ? A.el('p', { class: 'acct-note', text: s.skipped + ' ficheiro(s) acima de 700 KB (ou além do limite de 3000 por projeto) não são sincronizados; continuam neste telemóvel.' }) : null,
      A.el('div', { class: 'acct-row' },
        A.el('div', { class: 'acct-row-t' },
          A.el('div', { text: 'Sincronização automática' }),
          A.el('div', { class: 'acct-note', text: 'Envia as alterações pouco depois de guardares e recebe as feitas noutros dispositivos.' })),
        A.el('button', {
          class: 'switch', role: 'switch', 'aria-checked': String(!!C.info.autoSync), 'aria-label': 'Sincronização automática',
          onclick: () => { try { A.nat('cloudSetAutoSync', !C.info.autoSync); } catch (e) { A.toast(e.message, true); } },
        })),
      A.el('button', {
        class: 'btn provider', disabled: (s.state === 'syncing') || null,
        onclick: () => { try { A.nat('cloudSyncNow'); } catch (e) { A.toast(e.message, true); } },
      }, A.icon('refresh', 18), A.el('span', { text: 'Sincronizar agora' })),
      A.el('button', { class: 'btn provider', onclick: () => signOut(close) }, A.icon('logout', 18), A.el('span', { text: 'Terminar sessão' })),
      A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn', text: 'Fechar', onclick: () => close(null) }))
    ].filter(Boolean));
  }

  // ===================== Ações =====================
  function refresh() {
    try { C.info = A.nat('cloudInfo'); } catch (_) { C.info = { available: false, signedIn: false, reason: 'Esta função só existe dentro da app Android.' }; }
    paintButtons();
  }

  function signIn(kind, render) {
    if (C.busy) return;
    C.busy = kind;
    render();
    try { A.nat('cloudSignIn', kind); }
    catch (e) { C.busy = ''; A.toast(e.message, true); render(); }
  }

  async function signOut(close) {
    const a = await A.uiSheet('Terminar sessão', [
      { id: 'keep', label: 'Terminar sessão e manter os projetos neste telemóvel', icon: 'logout' },
      { id: 'wipe', label: 'Terminar sessão e remover deste telemóvel os projetos sincronizados', icon: 'trash', danger: true },
    ]);
    if (!a) return;
    if (a === 'wipe') {
      const ok = await A.uiConfirm('Remover projetos deste telemóvel',
        'Os projetos sincronizados com esta conta são apagados deste telemóvel (continuam na nuvem e voltam quando entrares de novo). Projetos que nunca foram sincronizados não são tocados.',
        'Remover', true);
      if (!ok) return;
      if (A.S.project) { A.S.saveTimers.forEach((t) => clearTimeout(t)); A.S.saveTimers.clear(); A.S.dirty.clear(); }
    }
    try { A.nat('cloudSignOut', a === 'wipe'); close(null); A.toast('Sessão terminada'); }
    catch (e) { A.toast(e.message, true); }
  }

  // ===================== Eventos do nativo =====================
  function onAuth(m) {
    if (m.available !== undefined) C.info = m;
    paintButtons();
    if (m.op === 'signin') {
      C.busy = '';
      if (m.ok) { A.toast('Sessão iniciada'); if (C.view) C.view.render(); }
      else {
        if (!m.cancelled) A.toast(m.error || 'Não foi possível iniciar sessão.', true);
        if (C.view) C.view.render();
      }
      return;
    }
    if (C.view) C.view.render();
  }

  // Alterações vindas da nuvem (outro dispositivo, recuperação…): atualiza o ecrã atual.
  function onCloud(m) {
    if (m.op !== 'changed') return;
    const names = m.projects || [];
    if (A.S.screen === 'home') { A.loadHome(); return; }
    const p = A.S.project;
    if (!p || !(names.includes(p) || names.includes('*'))) return;
    applyChanged(p, 0);
  }

  function applyChanged(p, tries) {
    if (A.S.project !== p) return;
    let exists = true;
    try { exists = A.nat('listProjects').projects.some((x) => x.name === p); } catch (_) { /* ignora */ }
    if (!exists) {
      A.S.saveTimers.forEach((t) => clearTimeout(t)); A.S.saveTimers.clear(); A.S.dirty.clear();
      A.toast('Este projeto foi removido noutro dispositivo.');
      A.closeProject();
      return;
    }
    // não mexe no editor enquanto há texto por gravar
    if ((A.S.saveTimers.size || A.S.dirty.size) && tries < 6) { setTimeout(() => applyChanged(p, tries + 1), 1500); return; }
    A.reloadFromDisk();
    A.toast('Projeto atualizado a partir da nuvem');
  }

  // Atualiza o "há X min" enquanto o ecrã Conta está aberto
  setInterval(() => { if (C.view) C.view.render(); }, 30000);

  window.CVCloud = {
    init(api) {
      A = api;
      A.listeners.auth = onAuth;
      A.listeners.cloud = onCloud;
      for (const id of ['#rail-account', '#btn-account-home']) {
        const b = A.$(id);
        if (b) b.addEventListener('click', open);
      }
      if (A.hasNative) refresh(); else paintButtons();
    },
    open,
  };
})();
