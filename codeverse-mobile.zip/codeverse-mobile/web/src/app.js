/* CodeVerse Mobile — lógica da interface */
'use strict';
(function () {
  // ===================== Utilitários =====================
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  function el(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  }

  const basename = (p) => p.split('/').pop();
  const dirname = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '');
  const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(p); return m ? m[1].toLowerCase() : ''; };
  const joinPath = (a, b) => (a ? a + '/' + b : b);

  function normalizePath(p) {
    const out = [];
    for (const part of p.split('/')) {
      if (!part || part === '.') continue;
      if (part === '..') out.pop();
      else out.push(part);
    }
    return out.join('/');
  }

  function relTime(ms) {
    const s = Math.max(0, (Date.now() - ms) / 1000);
    if (s < 60) return 'agora mesmo';
    if (s < 3600) return 'há ' + Math.floor(s / 60) + ' min';
    if (s < 86400) return 'há ' + Math.floor(s / 3600) + ' h';
    return new Date(ms).toLocaleDateString('pt-PT');
  }

  // ===================== Definições =====================
  const DEFAULTS = {
    fontSize: 14,
    wrap: false,
    runnerUrl: 'https://emkc.org/api/v2/piston',
    runTimeout: 30,
  };
  let settings = Object.assign({}, DEFAULTS);
  try { settings = Object.assign(settings, JSON.parse(localStorage.getItem('cv.settings') || '{}')); } catch (_) { /* ignora */ }
  function saveSettings() { try { localStorage.setItem('cv.settings', JSON.stringify(settings)); } catch (_) { /* ignora */ } }
  function applySettings() {
    document.documentElement.style.setProperty('--editor-font-size', settings.fontSize + 'px');
    if (window.CVEditor && window.CVEditor.setWrap) window.CVEditor.setWrap(settings.wrap);
  }

  // ===================== Ponte nativa =====================
  const hasNative = typeof window.Native !== 'undefined';
  function nat(name, ...args) {
    if (!hasNative) throw new Error('Esta função só existe dentro da app Android.');
    const raw = window.Native[name](...args);
    const r = JSON.parse(raw);
    if (!r.ok) throw new Error(r.error || 'Erro desconhecido');
    return r;
  }

  const httpPending = new Map();
  let httpSeq = 0;
  function httpPost(url, bodyObj, timeoutSec) {
    const id = 'h' + (++httpSeq) + '_' + Date.now();
    const promise = new Promise((resolve, reject) => {
      httpPending.set(id, { resolve, reject });
      try { window.Native.httpPost(id, url, JSON.stringify(bodyObj), Math.round(timeoutSec * 1000)); }
      catch (e) { httpPending.delete(id); reject(e); }
    });
    return { id, promise };
  }
  function httpCancel(id) {
    httpPending.delete(id);
    try { window.Native.httpCancel(id); } catch (_) { /* ignora */ }
  }

  const nativeListeners = {};
  window.CV_onNative = function (msg) {
    if (!msg) return;
    if (msg.type === 'http') {
      const p = httpPending.get(msg.id);
      if (!p) return;
      httpPending.delete(msg.id);
      if (msg.ok) p.resolve(msg); else p.reject(new Error(msg.error || 'Falha de rede'));
    } else if (nativeListeners[msg.type]) {
      nativeListeners[msg.type](msg);
    }
  };

  // ===================== Interface: avisos e diálogos =====================
  let toastTimer = null;
  function toast(text, isError) {
    const t = $('#toast');
    t.textContent = text;
    t.className = 'toast' + (isError ? ' error' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add('hidden'), isError ? 4500 : 2200);
  }

  const modals = [];
  function openModal(build) {
    return new Promise((resolve) => {
      const back = el('div', { class: 'modal-back' });
      const box = el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' });
      back.append(box);
      let done = false;
      const close = (val) => {
        if (done) return;
        done = true;
        const i = modals.findIndex((m) => m.back === back);
        if (i >= 0) modals.splice(i, 1);
        back.remove();
        resolve(val);
      };
      back.addEventListener('pointerdown', (e) => { if (e.target === back) close(null); });
      build(box, close);
      $('#modal-root').append(back);
      modals.push({ back, close: () => close(null) });
      const first = box.querySelector('input,select');
      if (first) setTimeout(() => { first.focus(); if (first.select) first.select(); }, 50);
    });
  }

  function uiPrompt(title, value, placeholder, okLabel) {
    return openModal((box, close) => {
      const input = el('input', { type: 'text', value: value || '', placeholder: placeholder || '', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => close(input.value.trim() || null);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
      box.append(
        el('h3', { text: title }), input,
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          el('button', { class: 'btn primary', text: okLabel || 'OK', onclick: submit }))
      );
    });
  }

  function uiConfirm(title, message, okLabel, danger) {
    return openModal((box, close) => {
      box.append(
        el('h3', { text: title }), el('p', { text: message }),
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(false) }),
          el('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), text: okLabel || 'OK', onclick: () => close(true) }))
      );
    }).then((v) => v === true);
  }

  function uiSheet(title, items) {
    return openModal((box, close) => {
      box.append(el('h3', { text: title }));
      for (const it of items) {
        box.append(el('button', { class: 'sheet-item' + (it.danger ? ' danger' : ''), text: it.label, onclick: () => close(it.id) }));
      }
    });
  }

  // ===================== Estado da aplicação =====================
  const S = {
    project: null,
    tree: [],
    open: [],            // caminhos abertos (separadores)
    active: null,
    expanded: new Set(), // pastas expandidas
    saveTimers: new Map(),
    failed: new Set(),
    explorerOpen: false,
    panelOpen: false,
    panelTab: 'console',
    running: null,       // { stop() }
  };

  // ===================== Editor (CodeMirror ou reserva) =====================
  let Ed = window.CVEditor;
  let fallbackTa = null;

  function initEditor() {
    const host = $('#editor-host');
    if (Ed && Ed.available) {
      Ed.init(host, {
        change: (path) => scheduleSave(path),
        cursor: (l, c) => { $('#st-pos').textContent = 'Ln ' + l + ', Col ' + c; },
      });
      return;
    }
    // Reserva simples para a app continuar utilizável se o bundle do editor falhar
    toast('Editor avançado indisponível; a usar editor simples.', true);
    const texts = new Map();
    let cur = null;
    fallbackTa = el('textarea', { class: 'fallback-editor', spellcheck: 'false', autocapitalize: 'off', autocorrect: 'off' });
    fallbackTa.addEventListener('input', () => { if (cur) { texts.set(cur, fallbackTa.value); scheduleSave(cur); } });
    host.append(fallbackTa);
    Ed = {
      available: false,
      open(p, t) { if (cur) texts.set(cur, fallbackTa.value); cur = p; if (!texts.has(p)) texts.set(p, t); fallbackTa.value = texts.get(p); },
      getText(p) { return p === cur ? fallbackTa.value : (texts.has(p) ? texts.get(p) : null); },
      has(p) { return texts.has(p); },
      close(p) { texts.delete(p); if (cur === p) cur = null; },
      clearAll() { texts.clear(); cur = null; fallbackTa.value = ''; },
      languageOf: () => 'text',
      focus() { fallbackTa.focus(); },
      find() { toast('Pesquisa não disponível no editor simples.', true); },
      undo() { document.execCommand('undo'); }, redo() { document.execCommand('redo'); },
      selectAll() { fallbackTa.select(); },
      tab() { Ed.insert('    '); },
      insert(t) { const s = fallbackTa.selectionStart, e = fallbackTa.selectionEnd; fallbackTa.setRangeText(t, s, e, 'end'); fallbackTa.dispatchEvent(new Event('input')); fallbackTa.focus(); },
      moveCursor(d) { fallbackTa.selectionStart = fallbackTa.selectionEnd = Math.max(0, fallbackTa.selectionStart + d); fallbackTa.focus(); },
      setWrap(on) { fallbackTa.style.whiteSpace = on ? 'pre-wrap' : 'pre'; },
    };
  }

  // ===================== Gravação automática =====================
  function scheduleSave(path) {
    if (!S.project) return;
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.set(path, setTimeout(() => saveNow(path), 600));
  }

  function saveNow(path) {
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.delete(path);
    if (!S.project) return true;
    const text = Ed.getText(path);
    if (text == null) return true;
    try {
      nat('writeFile', S.project, path, text);
      if (S.failed.delete(path)) renderTabs();
      return true;
    } catch (e) {
      if (!S.failed.has(path)) { S.failed.add(path); renderTabs(); }
      toast('Erro ao guardar ' + basename(path) + ': ' + e.message, true);
      return false;
    }
  }

  function flushSaves() {
    for (const p of Array.from(S.saveTimers.keys())) saveNow(p);
  }

  // ===================== Ecrã inicial =====================
  function showScreen(name) {
    $('#home').classList.toggle('hidden', name !== 'home');
    $('#ide').classList.toggle('hidden', name !== 'ide');
  }

  function loadHome() {
    showScreen('home');
    const list = $('#project-list');
    list.textContent = '';
    let projects = [];
    try { projects = nat('listProjects').projects; } catch (e) { toast(e.message, true); }
    $('#home-empty').classList.toggle('hidden', projects.length > 0);
    const recent = JSON.parse(localStorage.getItem('cv.recent') || '{}');
    projects.sort((a, b) => Math.max(b.modified, recent[b.name] || 0) - Math.max(a.modified, recent[a.name] || 0));
    for (const p of projects) {
      const when = Math.max(p.modified, recent[p.name] || 0);
      list.append(
        el('li', { class: 'project-item', role: 'button', tabindex: '0', onclick: () => openProject(p.name) },
          el('div', { class: 'pmain' },
            el('div', { class: 'pname', text: p.name }),
            el('div', { class: 'pmeta', text: 'Modificado ' + relTime(when) })),
          el('button', {
            class: 'icon-btn', 'aria-label': 'Opções de ' + p.name, text: '⋮',
            onclick: (ev) => { ev.stopPropagation(); projectMenu(p.name); },
          }))
      );
    }
    updateStatus();
  }

  async function projectMenu(name) {
    const a = await uiSheet(name, [
      { id: 'open', label: 'Abrir' },
      { id: 'rename', label: 'Renomear' },
      { id: 'export', label: 'Exportar ZIP' },
      { id: 'delete', label: 'Eliminar', danger: true },
    ]);
    if (a === 'open') openProject(name);
    else if (a === 'rename') {
      const n = await uiPrompt('Renomear projeto', name, 'Novo nome', 'Renomear');
      if (!n) return;
      try { nat('renameProject', name, n); loadHome(); } catch (e) { toast(e.message, true); }
    } else if (a === 'export') exportProject(name);
    else if (a === 'delete') {
      if (await uiConfirm('Eliminar projeto', 'Eliminar “' + name + '” e todos os ficheiros? Isto não pode ser desfeito.', 'Eliminar', true)) {
        try { nat('deleteProject', name); loadHome(); toast('Projeto eliminado'); } catch (e) { toast(e.message, true); }
      }
    }
  }

  async function newProjectDialog() {
    const tpls = window.CV_TEMPLATES;
    let sel = tpls[0];
    const result = await openModal((box, close) => {
      const input = el('input', { type: 'text', placeholder: 'Nome do projeto', value: 'meu-projeto', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const choices = tpls.map((t) => {
        const c = el('div', { class: 'choice' + (t === sel ? ' sel' : ''), role: 'radio', tabindex: '0' },
          el('div', {}, el('div', { text: t.name }), el('span', { class: 'sub', text: t.desc })));
        c.addEventListener('click', () => { sel = t; choices.forEach((x) => x.classList.remove('sel')); c.classList.add('sel'); });
        return c;
      });
      box.append(
        el('h3', { text: 'Novo projeto' }),
        el('label', { class: 'field', text: 'Nome' }), input,
        el('label', { class: 'field', text: 'Modelo' }), ...choices,
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          el('button', { class: 'btn primary', text: 'Criar', onclick: () => close({ name: input.value.trim(), tpl: sel }) }))
      );
    });
    if (!result || !result.name) return;
    try {
      const r = nat('createProject', result.name);
      nat('writeFiles', r.name, JSON.stringify(result.tpl.files));
      openProject(r.name, result.tpl.main);
    } catch (e) { toast(e.message, true); }
  }

  function exportProject(name) {
    nativeListeners.export = (m) => {
      if (m.ok) toast('ZIP exportado com sucesso');
      else if (!m.cancelled) toast('Falha ao exportar: ' + (m.error || ''), true);
    };
    try { nat('exportZip', name); } catch (e) { toast(e.message, true); }
  }

  function importZip() {
    nativeListeners.import = (m) => {
      if (m.ok) { toast('Projeto “' + m.name + '” importado'); loadHome(); }
      else if (!m.cancelled) toast('Falha ao importar: ' + (m.error || ''), true);
    };
    try { nat('importZip'); } catch (e) { toast(e.message, true); }
  }

  // ===================== Projeto aberto =====================
  function openProject(name, firstFile) {
    S.project = name;
    S.open = []; S.active = null; S.failed.clear(); S.expanded.clear();
    Ed.clearAll();
    try {
      const recent = JSON.parse(localStorage.getItem('cv.recent') || '{}');
      recent[name] = Date.now();
      localStorage.setItem('cv.recent', JSON.stringify(recent));
    } catch (_) { /* ignora */ }
    $('#ide-title').textContent = name;
    $('#ex-project').textContent = name;
    clearConsole();
    showScreen('ide');
    refreshTree();
    closePanel();
    toggleExplorer(false);
    renderTabs();
    $('#empty-editor').classList.remove('hidden');
    $('#st-lang').textContent = '—';
    $('#st-pos').textContent = 'Ln 1, Col 1';
    // abrir ficheiro principal sugerido
    let target = firstFile;
    if (!target) {
      const files = S.tree.filter((i) => !i.dir).map((i) => i.path);
      target = ['index.html', 'main.py', 'Main.java', 'main.dart', 'lib/main.dart', 'README.md'].find((c) => files.includes(c)) || files[0];
    }
    if (target) openFile(target);
    else toggleExplorer(true);
    updateStatus();
  }

  function closeProject() {
    flushSaves();
    stopRun();
    S.project = null;
    resetPython();
    loadHome();
  }

  function refreshTree() {
    if (!S.project) return;
    try { S.tree = nat('tree', S.project).items; } catch (e) { toast(e.message, true); S.tree = []; }
    renderTree();
  }

  // ----- Explorador -----
  const FILE_ICONS = {
    html: ['<>', '#e37933'], htm: ['<>', '#e37933'], css: ['#', '#519aba'], js: ['JS', '#cbcb41'], mjs: ['JS', '#cbcb41'],
    ts: ['TS', '#519aba'], json: ['{}', '#cbcb41'], py: ['Py', '#4b8bbe'], java: ['J', '#cc3e44'], dart: ['D', '#4fc1ff'],
    md: ['M', '#9d9d9d'], yml: ['Y', '#a074c4'], yaml: ['Y', '#a074c4'], png: ['▣', '#a074c4'], jpg: ['▣', '#a074c4'], svg: ['▣', '#e37933'],
  };

  function buildTree(list) {
    const root = { children: new Map(), dir: true, path: '' };
    for (const it of list) {
      const parts = it.path.split('/');
      let n = root;
      parts.forEach((p, i) => {
        const last = i === parts.length - 1;
        let c = n.children.get(p);
        if (!c) {
          c = { name: p, path: parts.slice(0, i + 1).join('/'), dir: last ? it.dir : true, children: new Map() };
          n.children.set(p, c);
        } else if (last) c.dir = it.dir;
        n = c;
      });
    }
    return root;
  }

  function renderTree() {
    const host = $('#tree');
    host.textContent = '';
    if (!S.tree.length) { host.append(el('div', { class: 'empty-tree', text: 'Projeto vazio. Usa 📄＋ para criar um ficheiro.' })); return; }
    const root = buildTree(S.tree);
    const walk = (node, depth) => {
      const kids = Array.from(node.children.values()).sort((a, b) => (a.dir === b.dir ? a.name.localeCompare(b.name) : a.dir ? -1 : 1));
      for (const k of kids) {
        const open = S.expanded.has(k.path);
        const ico = k.dir ? [open ? '▾' : '▸', '#c5c5c5'] : (FILE_ICONS[extOf(k.name)] || ['•', '#9d9d9d']);
        const row = el('div', { class: 'row' + (k.path === S.active ? ' active' : ''), role: 'treeitem', style: 'padding-left:' + (8 + depth * 14) + 'px' },
          el('span', { class: 'ico', style: 'color:' + ico[1], text: ico[0] }),
          el('span', { class: 'nm', text: k.name }),
          el('button', { class: 'more', 'aria-label': 'Opções de ' + k.name, text: '⋮', onclick: (ev) => { ev.stopPropagation(); entryMenu(k); } }));
        row.addEventListener('click', () => {
          if (k.dir) { if (open) S.expanded.delete(k.path); else S.expanded.add(k.path); renderTree(); }
          else { openFile(k.path); toggleExplorer(false); }
        });
        host.append(row);
        if (k.dir && open) walk(k, depth + 1);
      }
    };
    walk(root, 0);
  }

  async function entryMenu(k) {
    const items = [];
    if (k.dir) items.push({ id: 'nf', label: 'Novo ficheiro aqui' }, { id: 'nd', label: 'Nova pasta aqui' });
    items.push({ id: 'rn', label: 'Renomear' }, { id: 'del', label: 'Eliminar', danger: true });
    const a = await uiSheet(k.name, items);
    if (a === 'nf') newEntry(false, k.path);
    else if (a === 'nd') newEntry(true, k.path);
    else if (a === 'rn') renameEntry(k);
    else if (a === 'del') deleteEntry(k);
  }

  async function newEntry(isDir, parent) {
    const base = parent === undefined ? '' : parent;
    const name = await uiPrompt(isDir ? 'Nova pasta' : 'Novo ficheiro', '', isDir ? 'nome-da-pasta' : 'ficheiro.ext', 'Criar');
    if (!name) return;
    if (/[\\:*?"<>|]/.test(name) || name.split('/').some((p) => p === '..')) { toast('Nome inválido', true); return; }
    const path = normalizePath(joinPath(base, name));
    try {
      if (isDir) nat('mkdir', S.project, path); else nat('createFile', S.project, path);
      if (base) S.expanded.add(base);
      let d = dirname(path);
      while (d) { S.expanded.add(d); d = dirname(d); }
      refreshTree();
      if (!isDir) { openFile(path); toggleExplorer(false); }
    } catch (e) { toast(e.message, true); }
  }

  async function renameEntry(k) {
    const n = await uiPrompt('Renomear', k.name, 'Novo nome', 'Renomear');
    if (!n || n === k.name) return;
    if (/[\\/:*?"<>|]/.test(n)) { toast('Nome inválido', true); return; }
    const to = joinPath(dirname(k.path), n);
    flushSaves();
    try {
      nat('renamePath', S.project, k.path, to);
      // atualizar separadores abertos afetados
      const affected = S.open.filter((p) => p === k.path || p.startsWith(k.path + '/'));
      const oldActive = S.active;
      for (const p of affected) {
        const np = to + p.slice(k.path.length);
        Ed.close(p);
        S.open[S.open.indexOf(p)] = np;
        if (S.active === p) S.active = np;
      }
      refreshTree();
      if (oldActive && affected.includes(oldActive)) activate(S.active, true);
      else renderTabs();
    } catch (e) { toast(e.message, true); }
  }

  async function deleteEntry(k) {
    if (!(await uiConfirm('Eliminar', 'Eliminar “' + k.name + '”' + (k.dir ? ' e todo o conteúdo' : '') + '?', 'Eliminar', true))) return;
    flushSaves();
    try {
      nat('deletePath', S.project, k.path);
      for (const p of S.open.filter((x) => x === k.path || x.startsWith(k.path + '/'))) closeTab(p, true);
      refreshTree();
    } catch (e) { toast(e.message, true); }
  }

  function toggleExplorer(open) {
    S.explorerOpen = open;
    $('#explorer').classList.toggle('open', open);
    $('#scrim').classList.toggle('hidden', !open);
  }

  // ----- Separadores / ficheiros -----
  function openFile(path) {
    if (S.open.includes(path)) { activate(path); return; }
    let res;
    try { res = nat('readFile', S.project, path); } catch (e) { toast(e.message, true); return; }
    if (res.binary) { toast('Ficheiro binário: não pode ser editado como texto.', true); return; }
    if (res.tooLarge) { toast('Ficheiro demasiado grande para editar (máx. 2 MB).', true); return; }
    Ed.open(path, res.text);
    S.open.push(path);
    S.active = path;
    afterActivate();
  }

  function activate(path, forceReload) {
    if (!S.open.includes(path)) return;
    if (forceReload || !Ed.has(path)) {
      let res;
      try { res = nat('readFile', S.project, path); } catch (e) { toast(e.message, true); return; }
      Ed.open(path, res.text || '');
    } else {
      Ed.open(path, '');
    }
    S.active = path;
    afterActivate();
  }

  function afterActivate() {
    $('#empty-editor').classList.add('hidden');
    $('#st-lang').textContent = langLabel(S.active);
    renderTabs();
    renderTree();
    const t = $('#tabs .tab.active');
    if (t && t.scrollIntoView) t.scrollIntoView({ inline: 'nearest', block: 'nearest' });
    Ed.focus();
  }

  function langLabel(path) {
    const names = { html: 'HTML', css: 'CSS', javascript: 'JavaScript', typescript: 'TypeScript', json: 'JSON', python: 'Python', java: 'Java', dart: 'Dart', markdown: 'Markdown', text: 'Texto' };
    return names[Ed.languageOf(path)] || 'Texto';
  }

  function closeTab(path, skipSave) {
    if (!skipSave) saveNow(path);
    const i = S.open.indexOf(path);
    if (i < 0) return;
    S.open.splice(i, 1);
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.delete(path);
    Ed.close(path);
    if (S.active === path) {
      S.active = null;
      const next = S.open[Math.min(i, S.open.length - 1)];
      if (next) activate(next);
      else {
        $('#empty-editor').classList.remove('hidden');
        $('#st-lang').textContent = '—';
      }
    }
    renderTabs();
    renderTree();
  }

  function renderTabs() {
    const host = $('#tabs');
    host.textContent = '';
    for (const p of S.open) {
      host.append(
        el('div', { class: 'tab' + (p === S.active ? ' active' : ''), role: 'tab', onclick: () => activate(p) },
          el('span', { text: basename(p) }),
          S.failed.has(p) ? el('span', { class: 'dot', title: 'Não guardado', text: '●' }) : null,
          el('button', { class: 'x', 'aria-label': 'Fechar ' + basename(p), text: '✕', onclick: (ev) => { ev.stopPropagation(); closeTab(p); } }))
      );
    }
  }

  // ===================== Teclas extra =====================
  function buildKeybar() {
    const bar = $('#keybar');
    const keys = [
      { t: 'Tab', w: true, f: () => Ed.tab() },
      { t: '↶', f: () => Ed.undo(), label: 'Desfazer' },
      { t: '↷', f: () => Ed.redo(), label: 'Refazer' },
      { t: '←', f: () => Ed.moveCursor(-1), label: 'Cursor para a esquerda' },
      { t: '→', f: () => Ed.moveCursor(1), label: 'Cursor para a direita' },
    ];
    for (const s of ['{', '}', '(', ')', '[', ']', '<', '>', ';', ':', '=', '"', "'", '`', '/', '\\', '.', ',', '!', '&', '|', '_', '-', '+', '*', '#', '$', '%', '?']) {
      keys.push({ t: s, f: () => Ed.insert(s) });
    }
    for (const k of keys) {
      const b = el('button', { class: 'key' + (k.w ? ' wide' : ''), text: k.t, 'aria-label': k.label || k.t });
      b.addEventListener('pointerdown', (e) => e.preventDefault()); // mantém o teclado aberto
      b.addEventListener('click', k.f);
      bar.append(b);
    }
  }

  // ===================== Consola e painel =====================
  const consoleEl = () => $('#console');
  let consoleCount = 0;

  function log(kind, text) {
    const c = consoleEl();
    const line = el('div', { class: 'l-' + kind, text: text });
    c.append(line);
    if (++consoleCount > 2000) { c.firstChild.remove(); consoleCount--; }
    c.scrollTop = c.scrollHeight;
  }
  function clearConsole() { consoleEl().textContent = ''; consoleCount = 0; }

  function openPanel(tab) {
    S.panelOpen = true;
    $('#panel').classList.remove('hidden');
    setPanelTab(tab || S.panelTab);
  }
  function closePanel() { S.panelOpen = false; $('#panel').classList.add('hidden'); $('#panel').classList.remove('max'); }
  function setPanelTab(tab) {
    S.panelTab = tab;
    $$('.ptab').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    $('#console').classList.toggle('hidden', tab !== 'console');
    $('#preview').classList.toggle('hidden', tab !== 'preview');
  }

  // ===================== Estado / barra inferior =====================
  function updateStatus() {
    const net = navigator.onLine ? '● Online' : '○ Offline';
    $('#st-net').textContent = net;
    $('#home-status').textContent = net + ' — web e Python funcionam offline; Java e Dart precisam de internet';
    $('#st-py').textContent = pyState === 'ready' ? 'Python pronto' : pyState === 'loading' ? 'Python: a carregar…' : '';
  }
  window.addEventListener('online', updateStatus);
  window.addEventListener('offline', updateStatus);

  // ===================== Execução =====================
  function setRunning(r) {
    S.running = r;
    const b = $('#btn-run');
    b.textContent = r ? '■' : '▶';
    b.classList.toggle('stop', !!r);
    b.setAttribute('aria-label', r ? 'Parar' : 'Executar');
  }

  function stopRun() {
    if (S.running) { const r = S.running; setRunning(null); r.stop(); log('info', 'Execução interrompida.'); }
  }

  function textFilesOfProject(filter) {
    const out = [];
    for (const it of S.tree) {
      if (it.dir || !filter(it.path) || it.size > 1024 * 1024) continue;
      if (out.length >= 200) break;
      let content = Ed.has(it.path) ? Ed.getText(it.path) : null;
      if (content == null) {
        try { const r = nat('readFile', S.project, it.path); if (r.binary || r.tooLarge) continue; content = r.text; } catch (_) { continue; }
      }
      out.push({ path: it.path, content });
    }
    return out;
  }

  async function run() {
    if (S.running) { stopRun(); return; }
    if (!S.active) { toast('Abre um ficheiro para executar.', true); return; }
    flushSaves();
    const path = S.active;
    const ext = extOf(path);
    const hasIndex = S.tree.some((i) => i.path === 'index.html');
    const isFlutter = S.tree.some((i) => i.path === 'pubspec.yaml') && /flutter/.test(readTextSafe('pubspec.yaml'));

    if (ext === 'html' || ext === 'htm') return runWeb(path);
    if ((ext === 'css' || ext === 'js' || ext === 'mjs') && hasIndex && !runsAsScript(path, hasIndex)) return runWeb('index.html');
    if (ext === 'js' || ext === 'mjs') return runJs(path);
    if (ext === 'py') return runPython(path);
    if (ext === 'java') return runRemote('java', path);
    if (ext === 'dart') {
      if (isFlutter) { openPanel('console'); clearConsole(); log('warn', 'Este é um projeto Flutter. O Flutter SDK não corre no Android.\nExporta o ZIP (⋮ → Exportar ZIP), envia para o GitHub e usa o workflow incluído para gerar o APK.'); return; }
      return runRemote('dart', path);
    }
    openPanel('console'); clearConsole();
    log('warn', 'Não há execução para ficheiros .' + (ext || 'sem extensão') + '. Suportado: HTML/CSS/JS, Python, Java e Dart.');
  }

  function runsAsScript(path, hasIndex) {
    // um .js dentro de um projeto web é pré-visualizado; só corre isolado se não for referenciado pelo index.html
    if (!hasIndex) return true;
    const html = readTextSafe('index.html');
    return !html.includes(basename(path));
  }

  function readTextSafe(path) {
    try { const t = Ed.has(path) ? Ed.getText(path) : null; if (t != null) return t; return nat('readFile', S.project, path).text || ''; } catch (_) { return ''; }
  }

  // ----- Web -----
  const IMG_MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon' };
  const isExternal = (u) => /^([a-z][a-z0-9+.-]*:|\/\/)/i.test(u) || u.startsWith('#');

  const CAPTURE = '(function(){var p=function(t,a){try{parent.postMessage({cv:1,type:t,text:Array.prototype.map.call(a,function(x){try{return typeof x==="object"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}};["log","info","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){p(k,arguments);o.apply(console,arguments)}});window.addEventListener("error",function(e){p("error",[e.message+" ("+(e.lineno||"?")+":"+(e.colno||"?")+")"])});window.addEventListener("unhandledrejection",function(e){p("error",["Promessa rejeitada: "+e.reason])});})();';

  function buildPreviewHtml(htmlPath) {
    const doc = new DOMParser().parseFromString(readTextSafe(htmlPath), 'text/html');
    const baseDir = dirname(htmlPath);
    const resolve = (u) => normalizePath(joinPath(baseDir, u.split('#')[0].split('?')[0]));
    const exists = (p) => S.tree.some((i) => !i.dir && i.path === p);
    const missing = [];

    doc.querySelectorAll('link[rel~="stylesheet"][href]').forEach((l) => {
      const href = l.getAttribute('href');
      if (isExternal(href)) return;
      const p = resolve(href);
      if (!exists(p)) { missing.push(p); return; }
      l.replaceWith(Object.assign(doc.createElement('style'), { textContent: readTextSafe(p) }));
    });
    doc.querySelectorAll('script[src]').forEach((s) => {
      const src = s.getAttribute('src');
      if (isExternal(src)) return;
      const p = resolve(src);
      if (!exists(p)) { missing.push(p); return; }
      const n = doc.createElement('script');
      if (s.getAttribute('type')) n.setAttribute('type', s.getAttribute('type'));
      n.textContent = readTextSafe(p).replace(/<\/script/gi, '<\\/script');
      s.replaceWith(n);
    });
    doc.querySelectorAll('img[src]').forEach((im) => {
      const src = im.getAttribute('src');
      if (isExternal(src)) return;
      const p = resolve(src);
      const mime = IMG_MIME[extOf(p)];
      if (!exists(p) || !mime) return;
      try { im.setAttribute('src', 'data:' + mime + ';base64,' + nat('readBase64', S.project, p).data); } catch (_) { /* ignora */ }
    });

    const cap = doc.createElement('script');
    cap.textContent = CAPTURE;
    doc.head.insertBefore(cap, doc.head.firstChild);
    return { html: '<!DOCTYPE html>\n' + doc.documentElement.outerHTML, missing };
  }

  function runWeb(htmlPath) {
    clearConsole();
    openPanel('preview');
    const { html, missing } = buildPreviewHtml(htmlPath);
    missing.forEach((m) => log('warn', 'Ficheiro referenciado não encontrado: ' + m));
    log('info', 'Pré-visualização de ' + htmlPath);
    $('#preview').srcdoc = html;
  }

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || !d.cv || ev.source !== $('#preview').contentWindow) return;
    log(d.type === 'error' ? 'err' : d.type === 'warn' ? 'warn' : 'out', d.text);
  });

  // ----- JavaScript isolado (Worker) -----
  function runJs(path) {
    clearConsole(); openPanel('console');
    log('info', '▶ node-like: ' + path + ' (sem DOM; usa console.log)');
    const code = Ed.getText(path) || '';
    const src = [
      'const send=(t,a)=>postMessage({t:t,x:Array.prototype.map.call(a,v=>{try{return typeof v==="object"?JSON.stringify(v):String(v)}catch(e){return String(v)}}).join(" ")});',
      '["log","info","warn","error"].forEach(k=>{console[k]=function(){send(k,arguments)}});',
      'self.onerror=(m)=>{send("error",[m]);postMessage({t:"done"})};',
      'self.addEventListener("unhandledrejection",e=>send("error",["Promessa rejeitada: "+e.reason]));',
      '(async()=>{',
      code,
      '\n})().then(()=>postMessage({t:"done"}),e=>{send("error",[String(e&&e.stack||e)]);postMessage({t:"done"})});',
    ].join('\n');
    const url = URL.createObjectURL(new Blob([src], { type: 'application/javascript' }));
    const w = new Worker(url);
    const finish = () => { URL.revokeObjectURL(url); w.terminate(); if (S.running && S.running.w === w) { setRunning(null); log('ok', 'Execução terminada.'); } };
    w.onmessage = (e) => {
      const m = e.data;
      if (m.t === 'done') finish();
      else log(m.t === 'error' ? 'err' : m.t === 'warn' ? 'warn' : 'out', m.x);
    };
    w.onerror = (e) => { log('err', e.message || 'Erro no script'); finish(); };
    setRunning({ w, stop() { URL.revokeObjectURL(url); w.terminate(); } });
  }

  // ----- Python (Pyodide, offline) -----
  let pyWorker = null;
  let pyReady = null;
  let pyState = 'none';
  let pyRunDone = null;

  function resetPython() { if (pyWorker) { pyWorker.terminate(); } pyWorker = null; pyReady = null; pyState = 'none'; pyRunDone = null; updateStatus(); }

  function ensurePython() {
    if (pyReady) return pyReady;
    pyState = 'loading'; updateStatus();
    pyReady = new Promise((resolve, reject) => {
      let w;
      try { w = new Worker('python-worker.js'); } catch (e) { pyState = 'none'; pyReady = null; reject(e); return; }
      pyWorker = w;
      w.onmessage = (e) => {
        const m = e.data;
        if (m.type === 'ready') { pyState = 'ready'; updateStatus(); resolve(); }
        else if (m.type === 'initError') { pyState = 'none'; pyReady = null; updateStatus(); reject(new Error(m.message)); }
        else if (m.type === 'out') log('out', m.text);
        else if (m.type === 'err') log('err', m.text);
        else if (m.type === 'done') { if (pyRunDone) { const f = pyRunDone; pyRunDone = null; f(m.ok); } }
      };
      w.onerror = (e) => { pyState = 'none'; pyReady = null; updateStatus(); reject(new Error(e.message || 'Falha ao iniciar o worker Python')); };
      w.postMessage({ type: 'init' });
    });
    return pyReady;
  }

  async function runPython(path) {
    clearConsole(); openPanel('console');
    const token = {};
    setRunning({ token, stop() { resetPython(); } });
    try {
      if (pyState !== 'ready') log('info', 'A iniciar o Python (primeira vez pode demorar alguns segundos)…');
      await ensurePython();
      if (S.running && S.running.token !== token) return;
      const files = textFilesOfProject((p) => /\.(py|txt|json|csv|md|ya?ml|toml|ini|html|xml)$/i.test(p));
      log('info', '▶ python ' + path);
      const ok = await new Promise((resolve) => { pyRunDone = resolve; pyWorker.postMessage({ type: 'run', files, main: path }); });
      if (S.running && S.running.token === token) { setRunning(null); log(ok ? 'ok' : 'err', ok ? 'Execução terminada.' : 'Execução terminada com erro.'); }
    } catch (e) {
      if (S.running && S.running.token === token) setRunning(null);
      log('err', 'Não foi possível iniciar o Python: ' + e.message + '\nSe estás a compilar o APK, confirma que o passo "Pyodide" do build terminou sem erros.');
    }
  }

  // ----- Java / Dart (serviço online compatível com Piston) -----
  async function runRemote(lang, path) {
    clearConsole(); openPanel('console');
    if (!navigator.onLine) { log('warn', 'Sem ligação à internet. ' + (lang === 'java' ? 'Java' : 'Dart') + ' só executa online (não há compilador local no Android).'); return; }
    const ext = lang === 'java' ? 'java' : 'dart';
    let files = textFilesOfProject((p) => extOf(p) === ext);
    if (!files.length) { log('err', 'Nenhum ficheiro .' + ext + ' encontrado.'); return; }
    // o ficheiro principal vai primeiro
    const hasMain = (c) => (lang === 'java' ? /static\s+void\s+main\s*\(/.test(c) : /\bmain\s*\(/.test(c));
    let main = files.find((f) => f.path === path && hasMain(f.content)) || files.find((f) => hasMain(f.content));
    if (!main) { log('err', lang === 'java' ? 'Não encontrei nenhuma classe com "public static void main(String[] args)".' : 'Não encontrei a função main().'); return; }
    files = [main].concat(files.filter((f) => f !== main));
    const payload = {
      language: lang, version: '*',
      files: files.map((f) => ({ name: basename(f.path), content: f.content })),
      stdin: '', compile_timeout: 15000, run_timeout: 10000,
    };
    const url = settings.runnerUrl.replace(/\/+$/, '') + '/execute';
    log('info', '▶ ' + lang + ' ' + basename(main.path) + ' → ' + new URL(url).host);
    let req;
    try { req = httpPost(url, payload, settings.runTimeout); } catch (e) { log('err', e.message); return; }
    setRunning({ stop() { httpCancel(req.id); } });
    try {
      const res = await req.promise;
      if (!S.running) return;
      setRunning(null);
      let data = null;
      try { data = JSON.parse(res.body); } catch (_) { /* resposta não-JSON */ }
      if (res.status < 200 || res.status >= 300 || !data) {
        log('err', 'O serviço de execução respondeu com erro (HTTP ' + res.status + '):\n' + (data && data.message ? data.message : res.body.slice(0, 400)) +
          '\n\nSe o serviço público estiver indisponível ou restrito, muda o endereço em Definições → Serviço de execução (API compatível com Piston).');
        return;
      }
      if (data.compile) {
        if (data.compile.stdout) log('out', data.compile.stdout);
        if (data.compile.stderr) log('err', data.compile.stderr);
        if (data.compile.code !== 0 && data.compile.code != null) { log('err', 'A compilação falhou (código ' + data.compile.code + ').'); return; }
      }
      const r = data.run || {};
      if (r.stdout) log('out', r.stdout);
      if (r.stderr) log('err', r.stderr);
      log(r.code === 0 ? 'ok' : 'err', 'Processo terminou com código ' + (r.code == null ? '?' : r.code) + (r.signal ? ' (' + r.signal + ')' : ''));
    } catch (e) {
      if (S.running) { setRunning(null); log('err', 'Falha de rede: ' + e.message); }
    }
  }

  // ===================== Menu e definições =====================
  async function ideMenu() {
    const a = await uiSheet(S.project, [
      { id: 'find', label: 'Procurar / substituir' },
      { id: 'undo', label: 'Desfazer' },
      { id: 'redo', label: 'Refazer' },
      { id: 'wrap', label: settings.wrap ? 'Desativar quebra de linha' : 'Ativar quebra de linha' },
      { id: 'fplus', label: 'Aumentar letra' },
      { id: 'fminus', label: 'Diminuir letra' },
      { id: 'export', label: 'Exportar projeto (ZIP)' },
      { id: 'refresh', label: 'Atualizar lista de ficheiros' },
      { id: 'settings', label: 'Definições' },
      { id: 'close', label: 'Fechar projeto' },
    ]);
    if (a === 'find') Ed.find();
    else if (a === 'undo') Ed.undo();
    else if (a === 'redo') Ed.redo();
    else if (a === 'wrap') { settings.wrap = !settings.wrap; saveSettings(); applySettings(); }
    else if (a === 'fplus') { settings.fontSize = Math.min(28, settings.fontSize + 1); saveSettings(); applySettings(); }
    else if (a === 'fminus') { settings.fontSize = Math.max(9, settings.fontSize - 1); saveSettings(); applySettings(); }
    else if (a === 'export') { flushSaves(); exportProject(S.project); }
    else if (a === 'refresh') refreshTree();
    else if (a === 'settings') settingsDialog();
    else if (a === 'close') closeProject();
  }

  async function settingsDialog() {
    await openModal((box, close) => {
      const font = el('input', { type: 'number', min: '9', max: '28', value: String(settings.fontSize) });
      const wrap = el('input', { type: 'checkbox', style: 'width:22px;height:22px' });
      wrap.checked = settings.wrap;
      const runner = el('input', { type: 'url', value: settings.runnerUrl, autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const tmo = el('input', { type: 'number', min: '5', max: '120', value: String(settings.runTimeout) });
      box.append(
        el('h3', { text: 'Definições' }),
        el('label', { class: 'field', text: 'Tamanho da letra do editor (px)' }), font,
        el('div', { class: 'toggle-row' }, el('span', { text: 'Quebra de linha automática' }), wrap),
        el('label', { class: 'field', text: 'Serviço de execução Java/Dart (API compatível com Piston, https)' }), runner,
        el('label', { class: 'field', text: 'Tempo limite de rede (segundos)' }), tmo,
        el('p', { class: 'muted', text: 'HTML/CSS/JS e Python funcionam offline. Java e Dart enviam o código para o serviço indicado acima — não uses código confidencial.' }),
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Repor', onclick: () => { settings = Object.assign({}, DEFAULTS); saveSettings(); applySettings(); close(true); } }),
          el('button', { class: 'btn primary', text: 'Guardar', onclick: () => {
            const url = runner.value.trim();
            if (!/^https:\/\//i.test(url)) { toast('O endereço tem de começar por https://', true); return; }
            settings.fontSize = Math.max(9, Math.min(28, parseInt(font.value, 10) || 14));
            settings.wrap = wrap.checked;
            settings.runnerUrl = url;
            settings.runTimeout = Math.max(5, Math.min(120, parseInt(tmo.value, 10) || 30));
            saveSettings(); applySettings(); close(true);
          } }))
      );
    });
  }

  // ===================== Botão Voltar do Android =====================
  window.CV_onBack = function () {
    if (modals.length) { modals[modals.length - 1].close(); return true; }
    if (S.explorerOpen) { toggleExplorer(false); return true; }
    if (S.panelOpen) { closePanel(); return true; }
    if (S.project) { closeProject(); return true; }
    return false;
  };
  window.CV_onPause = function () { flushSaves(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSaves(); });

  // ===================== Arranque =====================
  function bind() {
    $('#btn-new').addEventListener('click', newProjectDialog);
    $('#btn-import').addEventListener('click', importZip);
    $('#btn-settings').addEventListener('click', settingsDialog);
    $('#btn-explorer').addEventListener('click', () => toggleExplorer(!S.explorerOpen));
    $('#scrim').addEventListener('click', () => toggleExplorer(false));
    $('#btn-run').addEventListener('click', run);
    $('#btn-panel').addEventListener('click', () => (S.panelOpen ? closePanel() : openPanel()));
    $('#btn-menu').addEventListener('click', ideMenu);
    $('#ex-newfile').addEventListener('click', () => newEntry(false));
    $('#ex-newdir').addEventListener('click', () => newEntry(true));
    $('#ex-refresh').addEventListener('click', refreshTree);
    $$('.ptab').forEach((b) => b.addEventListener('click', () => setPanelTab(b.dataset.tab)));
    $('#panel-close').addEventListener('click', closePanel);
    $('#panel-clear').addEventListener('click', clearConsole);
    $('#panel-max').addEventListener('click', () => $('#panel').classList.toggle('max'));
  }

  function start() {
    initEditor();
    applySettings();
    buildKeybar();
    bind();
    if (!hasNative) {
      $('#home-empty').classList.remove('hidden');
      $('#home-empty').textContent = 'Esta interface precisa da app Android CodeVerse Mobile para guardar ficheiros.';
      showScreen('home');
      return;
    }
    loadHome();
  }

  start();
})();
