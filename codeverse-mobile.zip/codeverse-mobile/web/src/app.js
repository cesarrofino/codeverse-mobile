/* CodeVerse — lógica da interface (aparência VS Code Dark+) */
'use strict';
(function () {
  // ===================== Utilitários =====================
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const I = window.CVIcons;

  function el(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k === 'html') e.innerHTML = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  }
  const icon = (name, size) => el('span', { class: 'ico', html: I.svg(name, size || 20), style: 'display:flex' });
  const fileIcon = (name, size) => el('span', { class: 'ico', html: I.file(name, size || 16), style: 'display:flex' });

  const basename = (p) => p.split('/').pop();
  const dirname = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '');
  const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(p); return m ? m[1].toLowerCase() : ''; };
  const joinPath = (a, b) => (a ? a + '/' + b : b);
  const norm = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  function normalizePath(p) {
    const out = [];
    for (const part of p.split('/')) {
      if (!part || part === '.') continue;
      if (part === '..') out.pop();
      else out.push(part);
    }
    return out.join('/');
  }

  function relTime(ms) {
    const s = Math.max(0, (Date.now() - ms) / 1000);
    if (s < 60) return 'agora mesmo';
    if (s < 3600) return 'há ' + Math.floor(s / 60) + ' min';
    if (s < 86400) return 'há ' + Math.floor(s / 3600) + ' h';
    return new Date(ms).toLocaleDateString('pt-PT');
  }

  // ===================== Definições =====================
  const DEFAULTS = {
    fontSize: 14,
    tabSize: 0,
    wrap: false,
    lineNumbers: true,
    autoSaveMs: 600,
    keybar: true,
    breadcrumbs: true,
    statusBar: true,
    javaLevel: '1.8',
    runnerUrl: 'https://emkc.org/api/v2/piston',
    runTimeout: 30,
    updateUrl: '',
    autoUpdate: true,
    previewMode: 'mobile',
    previewTarget: 'internal',
    showErrors: true,
    activeLine: true,
    foldGutter: true,
    suggest: true,
    autoClose: true,
    lineHeight: 1.5,
    consoleFont: 13,
    haptics: true,
    confirmDelete: true,
  };
  let settings = Object.assign({}, DEFAULTS);
  try { settings = Object.assign(settings, JSON.parse(localStorage.getItem('cv.settings') || '{}')); } catch (_) { /* ignora */ }
  function saveSettings() { try { localStorage.setItem('cv.settings', JSON.stringify(settings)); } catch (_) { /* ignora */ } }

  function applySettings() {
    const root = document.documentElement;
    root.style.setProperty('--editor-font-size', settings.fontSize + 'px');
    root.classList.toggle('no-lines', !settings.lineNumbers);
    root.classList.toggle('no-keybar', !settings.keybar);
    root.classList.toggle('no-crumbs', !settings.breadcrumbs);
    root.classList.toggle('no-status', !settings.statusBar);
    root.classList.toggle('no-active-line', !settings.activeLine);
    root.classList.toggle('no-fold', !settings.foldGutter);
    root.classList.toggle('no-suggest', !settings.suggest);
    root.style.setProperty('--editor-lh', String(settings.lineHeight));
    root.style.setProperty('--term-fs', settings.consoleFont + 'px');
    if (window.CVEditor) {
      if (window.CVEditor.setWrap) window.CVEditor.setWrap(settings.wrap);
      if (window.CVEditor.setTabSize) window.CVEditor.setTabSize(settings.tabSize);
      if (window.CVEditor.setErrors) window.CVEditor.setErrors(settings.showErrors);
      if (window.CVEditor.setAutoClose) window.CVEditor.setAutoClose(settings.autoClose);
    }
    updateIndentLabel();
  }

  // Nota: o serviço online do Dart (runnerUrl / runTimeout) fica só no código, não aparece nas definições.
  const SCHEMA = [
    { id: 'editor', title: 'Editor', icon: 'code', items: [
      { key: 'fontSize', type: 'stepper', min: 9, max: 28, step: 1, unit: ' px', title: 'Tamanho da letra', desc: 'Tamanho do texto no editor.' },
      { key: 'lineHeight', type: 'select', title: 'Espaço entre linhas', desc: 'Altura de cada linha de código.', options: [[1.3, 'Compacto'], [1.5, 'Normal'], [1.8, 'Espaçado']] },
      { key: 'tabSize', type: 'select', title: 'Tamanho da tabulação', desc: 'Espaços por nível de indentação. “Automático” usa o valor habitual de cada linguagem.', options: [[0, 'Automático'], [2, '2 espaços'], [4, '4 espaços'], [8, '8 espaços']] },
      { key: 'wrap', type: 'bool', title: 'Quebra de linha automática', desc: 'Linhas longas passam para a linha seguinte em vez de deslizar na horizontal.' },
      { key: 'lineNumbers', type: 'bool', title: 'Números de linha', desc: 'Mostra a numeração à esquerda do código.' },
      { key: 'showErrors', type: 'bool', title: 'Mostrar erros de sintaxe', desc: 'Uma linha com erro mostra um “x” vermelho no lugar do número.' },
      { key: 'activeLine', type: 'bool', title: 'Destacar a linha atual', desc: 'Realça a linha onde está o cursor.' },
      { key: 'foldGutter', type: 'bool', title: 'Dobrar blocos de código', desc: 'Mostra as setas para esconder e mostrar blocos.' },
      { key: 'suggest', type: 'bool', title: 'Sugestões de código', desc: 'Lista de sugestões enquanto escreves.' },
      { key: 'autoClose', type: 'bool', title: 'Fechar parênteses e aspas', desc: 'Ao abrir ( [ { \' ou \", fecha automaticamente.' },
      { key: 'autoSaveMs', type: 'select', title: 'Gravação automática', desc: 'Tempo de espera após a última alteração antes de guardar o ficheiro.', options: [[300, 'Rápida (0,3 s)'], [600, 'Normal (0,6 s)'], [1500, 'Lenta (1,5 s)']] },
    ] },
    { id: 'ui', title: 'Interface', icon: 'layout', items: [
      { key: 'keybar', type: 'bool', title: 'Barra de teclas de programação', desc: 'Atalhos para { } ( ) ; Tab e outros símbolos por cima do teclado.' },
      { key: 'breadcrumbs', type: 'bool', title: 'Caminho do ficheiro', desc: 'Mostra a localização do ficheiro por baixo dos separadores.' },
      { key: 'statusBar', type: 'bool', title: 'Barra de estado do editor', desc: 'Linha, coluna, indentação e linguagem na parte de baixo do editor.' },
      { key: 'confirmDelete', type: 'bool', title: 'Confirmar antes de eliminar', desc: 'Pede confirmação ao eliminar ficheiros e pastas.' },
      { key: 'haptics', type: 'bool', title: 'Vibração', desc: 'Vibra ao tocar sem soltar na pasta do projeto.' },
    ] },
    { id: 'run', title: 'Execução', icon: 'play', items: [
      { key: 'previewTarget', type: 'select', title: 'Abrir páginas HTML em', desc: '“Navegador” abre em http://localhost no navegador do telemóvel. Na pré-visualização também há a opção “Abrir no navegador”.', options: [['internal', 'Pré-visualização do CodeVerse'], ['browser', 'Navegador do telemóvel']] },
      { key: 'previewMode', type: 'select', title: 'Modo da pré-visualização', desc: '“Computador” mostra o site com largura de PC, reduzida para caber no ecrã. Também podes trocar no menu ⋮ da pré-visualização.', options: [['mobile', 'Telemóvel'], ['desktop', 'Computador']] },
      { key: 'consoleFont', type: 'stepper', min: 10, max: 22, step: 1, unit: ' px', title: 'Letra da consola', desc: 'Tamanho do texto da consola e dos resultados.' },
      { key: 'javaLevel', type: 'select', title: 'Versão da linguagem Java', desc: 'Compilador Java local (ECJ). Funciona 100% offline. Java 11 é experimental.', options: [['1.8', 'Java 8 (recomendado)'], ['11', 'Java 11 (experimental)']] },
    ] },
    { id: 'upd', title: 'Atualizações', icon: 'download', items: [
      { key: 'autoUpdate', type: 'bool', title: 'Verificar ao abrir a app', desc: 'Procura uma versão nova (Release no GitHub) e avisa se houver.' },
      { type: 'link', icon: 'download', title: 'Verificar atualização agora', desc: 'Procurar uma nova versão da app', action: () => openUpdate() },
    ] },
    { id: 'about', title: 'Sobre', icon: 'info', about: true },
  ];

  let settingsFrom = 'home';

  function openSettings() {
    settingsFrom = S.screen === 'ide' ? 'ide' : 'home';
    toggleExplorer(false);
    $('#set-filter').value = '';
    renderSettings('');
    showScreen('settings');
  }
  function closeSettings() { showScreen(settingsFrom === 'ide' && S.project ? 'ide' : 'home'); }

  function commitSettings() { saveSettings(); applySettings(); }

  function controlFor(it) {
    const cast = (v) => (typeof DEFAULTS[it.key] === 'number' ? Number(v) : v);
    if (it.type === 'bool') {
      const b = el('button', { class: 'switch', role: 'switch', 'aria-label': it.title, 'aria-checked': String(!!settings[it.key]) });
      b.addEventListener('click', () => {
        settings[it.key] = !settings[it.key];
        b.setAttribute('aria-checked', String(!!settings[it.key]));
        commitSettings();
      });
      return b;
    }
    if (it.type === 'stepper') {
      const val = el('span', { class: 'val' });
      const show = () => { val.textContent = settings[it.key] + (it.unit || ''); };
      const step = (d) => { settings[it.key] = Math.max(it.min, Math.min(it.max, settings[it.key] + d * it.step)); show(); commitSettings(); };
      show();
      return el('div', { class: 'stepper' },
        el('button', { 'aria-label': 'Diminuir', html: I.svg('minus', 18), onclick: () => step(-1) }),
        val,
        el('button', { 'aria-label': 'Aumentar', html: I.svg('plus', 18), onclick: () => step(1) }));
    }
    if (it.type === 'select') {
      const s = el('select', { 'aria-label': it.title });
      for (const [v, label] of it.options) s.append(el('option', { value: String(v), text: label }));
      s.value = String(settings[it.key]);
      s.addEventListener('change', () => { settings[it.key] = cast(s.value); commitSettings(); });
      return s;
    }
    // url
    const inp = el('input', { type: 'url', value: settings[it.key], autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', 'aria-label': it.title });
    inp.addEventListener('change', () => {
      const v = inp.value.trim();
      if (!/^https:\/\//i.test(v)) { toast('O endereço tem de começar por https://', true); inp.value = settings[it.key]; return; }
      settings[it.key] = v; commitSettings();
    });
    return inp;
  }

  function renderSettings(filter) {
    const body = $('#set-body');
    const chips = $('#set-chips');
    body.textContent = ''; chips.textContent = '';
    const q = norm(filter.trim());
    let shown = 0;
    for (const g of SCHEMA) {
      const items = g.about ? [] : g.items.filter((it) => !q || norm(it.title + ' ' + it.desc + ' ' + g.title).includes(q));
      if (g.about) { if (q && !norm('sobre versão codeverse data').includes(q)) continue; }
      else if (!items.length) continue;
      shown++;
      const head = el('div', { class: 'set-group', id: 'sg-' + g.id }, icon(g.icon, 18), g.title);
      body.append(head);
      chips.append(el('button', { class: 'chip', onclick: () => head.scrollIntoView({ block: 'start', behavior: 'smooth' }) }, icon(g.icon, 16), g.title));
      if (g.about) {
        body.append(el('div', { class: 'set-item about' },
          el('div', { class: 'st', text: 'CodeVerse' }),
          el('div', { class: 'ver-line' }, el('span', { text: 'Versão' }), el('span', { text: appVersion() })),
          el('div', { class: 'ver-line' }, el('span', { text: 'Data de atualização' }), el('span', { text: APP_UPDATED }))));
        continue;
      }
      for (const it of items) {
        if (it.type === 'link') {
          body.append(el('button', { class: 'set-link', onclick: it.action },
            icon(it.icon, 20),
            el('div', { class: 'txt' }, el('div', { class: 'st', text: it.title }), el('div', { class: 'sd', text: it.desc })),
            icon('chevron-right', 18)));
          continue;
        }
        const ctl = controlFor(it);
        if (it.type === 'bool') {
          body.append(el('div', { class: 'set-item inline' },
            el('div', { class: 'txt' }, el('div', { class: 'st', text: it.title }), el('div', { class: 'sd', text: it.desc })), ctl));
        } else {
          body.append(el('div', { class: 'set-item' }, el('div', { class: 'st', text: it.title }), el('div', { class: 'sd', text: it.desc }), ctl));
        }
      }
    }
    if (!shown) body.append(el('div', { class: 'set-empty', text: 'Nenhuma definição encontrada.' }));
    else if (!q) {
      body.append(el('div', { class: 'set-foot' },
        el('button', { class: 'btn', text: 'Repor definições', onclick: async () => {
          if (await uiConfirm('Repor definições', 'Voltar a todos os valores predefinidos?', 'Repor')) {
            settings = Object.assign({}, DEFAULTS); commitSettings(); renderSettings('');
          }
        } })));
    }
  }

  // ===================== Versão e atualização =====================
  const APP_VERSION = '1.0.0';
  const APP_UPDATED = '21/10/2026';
  const DEFAULT_REPO = 'cesarrofino/codeverse-mobile';
  let _ver = null, _repo = '';
  function appVersion() {
    if (_ver) return _ver;
    try { const j = JSON.parse(window.Native.appVersion()); _ver = j.version || APP_VERSION; _repo = j.repo || ''; } catch (_) { _ver = APP_VERSION; }
    return _ver;
  }
  function cmpVersions(a, b) {
    const n = (v) => String(v).replace(/^[^0-9]*/, '').split(/[.\-+]/).map((x) => parseInt(x, 10) || 0);
    const x = n(a), y = n(b);
    for (let i = 0; i < Math.max(x.length, y.length, 3); i++) {
      const d = (x[i] || 0) - (y[i] || 0);
      if (d) return d > 0 ? 1 : -1;
    }
    return 0;
  }

  const U = { state: 'idle', info: null, dlId: null, seq: 0 };

  function openUpdate() {
    appVersion();
    showScreen('update');
    checkUpdate();
  }
  function closeUpdate() {
    cancelDownload();
    U.seq++;
    renderSettings($('#set-filter').value || '');
    showScreen('settings');
  }
  function cancelDownload() {
    if (U.dlId) { try { window.Native.httpCancel(U.dlId); } catch (_) { /* ignora */ } U.dlId = null; }
  }

  function updView(o) {
    const ic = $('#upd-icon');
    ic.className = 'upd-icon ' + (o.cls || '');
    ic.textContent = '';
    ic.append(icon(o.icon || 'info', 30));
    $('#upd-title').textContent = o.title || '';
    $('#upd-text').textContent = o.text || '';
    const prog = $('#upd-prog');
    prog.classList.toggle('hidden', o.progress === undefined);
    prog.classList.toggle('indet', o.progress === -1);
    $('#upd-bar').style.width = o.progress > 0 ? o.progress + '%' : '';
    const notes = $('#upd-notes');
    notes.classList.toggle('hidden', !o.notes);
    notes.textContent = o.notes || '';
    const b = $('#upd-btn');
    b.classList.toggle('hidden', !o.btn);
    b.textContent = o.btn ? o.btn.label : '';
    b.onclick = o.btn ? o.btn.fn : null;
  }

  function updateSourceUrl() {
    appVersion();
    let u = (settings.updateUrl || '').trim();
    if (!u) u = 'https://github.com/' + (_repo || DEFAULT_REPO);
    const m = u.match(/^https:\/\/github\.com\/([^/\s]+)\/([^/\s#?]+)/i);
    if (m) u = 'https://api.github.com/repos/' + m[1] + '/' + m[2].replace(/\.git$/i, '') + '/releases/latest';
    return u;
  }

  // Lê a última versão publicada (Release do GitHub ou JSON). Devolve {version, apk, notes} ou lança erro.
  async function fetchLatest(url) {
    const r = await httpGetUrl(url);
    if (r.status < 200 || r.status >= 300) throw new Error(r.status === 404 ? 'Não encontrei nenhuma versão publicada nesse endereço (se o repositório for privado, tem de ser público).' : 'O servidor respondeu com o código ' + r.status + '.');
    let j;
    try { j = JSON.parse(r.body); } catch (_) { throw new Error('A resposta não é um JSON válido.'); }
    let version, apk, notes;
    if (j.tag_name) {
      version = j.tag_name;
      const a = (j.assets || []).find((x) => /\.apk$/i.test(x.name || ''));
      apk = a && a.browser_download_url;
      notes = j.body;
    } else { version = j.version; apk = j.url || j.apk; notes = j.notes || j.changelog; }
    if (!version) throw new Error('A resposta não indica a versão.');
    return { version, apk, notes };
  }

  // Verificação automática ao abrir a app (no máximo de 6 em 6 horas, em silêncio se não houver nada).
  async function autoCheckUpdate() {
    if (!hasNative || !settings.autoUpdate) return;
    let last = 0;
    try { last = Number(localStorage.getItem('cv.updCheck')) || 0; } catch (_) { /* ignora */ }
    if (Date.now() - last < 6 * 3600 * 1000) return;
    const url = updateSourceUrl();
    if (!url) return;
    try {
      const info = await fetchLatest(url);
      try { localStorage.setItem('cv.updCheck', String(Date.now())); } catch (_) { /* ignora */ }
      if (!info.apk || cmpVersions(info.version, appVersion()) <= 0) return;
      const go = await uiConfirm('Nova versão disponível', 'O CodeVerse ' + String(info.version).replace(/^v/i, '') + ' já está disponível (tens a ' + appVersion() + ').', 'Atualizar');
      if (go) openUpdate();
    } catch (_) { /* sem rede ou sem Release: ignora */ }
  }

  async function checkUpdate() {
    const my = ++U.seq;
    cancelDownload();
    U.info = null;
    if (!hasNative) { updView({ icon: 'info', title: 'Indisponível', text: 'A verificação só funciona dentro da app Android.' }); return; }
    const url = updateSourceUrl();
    updView({ icon: 'refresh', cls: 'spin', title: 'A verificar…', text: 'Versão instalada: ' + appVersion(), progress: -1 });
    try {
      const latest = await fetchLatest(url);
      if (my !== U.seq) return;
      const { version, apk, notes } = latest;
      const cur = appVersion();
      if (cmpVersions(version, cur) <= 0) {
        updView({ icon: 'check', cls: 'ok', title: 'Já tens a versão mais recente', text: 'CodeVerse ' + cur,
          btn: { label: 'Verificar de novo', fn: checkUpdate } });
        return;
      }
      if (!apk) throw new Error('Há uma versão nova (' + version + '), mas não tem ficheiro .apk para descarregar.');
      U.info = { version: String(version).replace(/^v/i, ''), apk, notes: notes ? String(notes).slice(0, 1200) : '' };
      updView({ icon: 'download', title: 'Nova versão disponível', text: 'Versão ' + U.info.version + ' (tens a ' + cur + ')', notes: U.info.notes,
        btn: { label: 'Baixar e atualizar', fn: startDownload } });
    } catch (e) {
      if (my !== U.seq) return;
      updView({ icon: 'close', cls: 'err', title: 'Não foi possível verificar', text: e.message || 'Erro de rede.',
        btn: { label: 'Tentar de novo', fn: checkUpdate } });
    }
  }

  function startDownload() {
    if (!U.info) return;
    const id = 'd' + (++httpSeq) + '_' + Date.now();
    U.dlId = id;
    updView({ icon: 'download', title: 'A baixar a versão ' + U.info.version, text: 'A preparar…', progress: -1 });
    try { window.Native.downloadApk(id, U.info.apk); }
    catch (e) { U.dlId = null; updView({ icon: 'close', cls: 'err', title: 'Falha ao baixar', text: e.message, btn: { label: 'Tentar de novo', fn: startDownload } }); }
  }

  function installUpdate() {
    try { nat('installApk'); }
    catch (e) { toast(e.message, true); }
  }

  function mb(n) { return (n / 1048576).toFixed(1).replace('.', ',') + ' MB'; }

  // ===================== Ponte nativa =====================
  const hasNative = typeof window.Native !== 'undefined';
  function nat(name, ...args) {
    if (!hasNative) throw new Error('Esta função só existe dentro da app Android.');
    const raw = window.Native[name](...args);
    const r = JSON.parse(raw);
    if (!r.ok) throw new Error(r.error || 'Erro desconhecido');
    return r;
  }

  const httpPending = new Map();
  let httpSeq = 0;
  function httpPost(url, bodyObj, timeoutSec) {
    const id = 'h' + (++httpSeq) + '_' + Date.now();
    const promise = new Promise((resolve, reject) => {
      httpPending.set(id, { resolve, reject });
      try { window.Native.httpPost(id, url, JSON.stringify(bodyObj), Math.round(timeoutSec * 1000)); }
      catch (e) { httpPending.delete(id); reject(e); }
    });
    return { id, promise };
  }
  function httpGetUrl(url) {
    return new Promise((resolve, reject) => {
      const id = 'g' + (++httpSeq) + '_' + Date.now();
      httpPending.set(id, { resolve, reject });
      try { window.Native.httpGet(id, url, 20000); } catch (e) { httpPending.delete(id); reject(e); }
    });
  }
  function httpCancel(id) {
    httpPending.delete(id);
    try { window.Native.httpCancel(id); } catch (_) { /* ignora */ }
  }

  const nativeListeners = {};
  window.CV_onNative = function (msg) {
    if (!msg) return;
    if (msg.type === 'http') {
      const p = httpPending.get(msg.id);
      if (!p) return;
      httpPending.delete(msg.id);
      if (msg.ok) p.resolve(msg); else p.reject(new Error(msg.error || 'Falha de rede'));
    } else if (nativeListeners[msg.type]) {
      nativeListeners[msg.type](msg);
    }
  };

  // ===================== Avisos e diálogos =====================
  let toastTimer = null;
  function toast(text, isError) {
    const t = $('#toast');
    t.textContent = text;
    t.className = 'toast' + (isError ? ' error' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add('hidden'), isError ? 4500 : 2200);
  }

  const modals = [];
  function openModal(build) {
    return new Promise((resolve) => {
      const back = el('div', { class: 'modal-back' });
      const box = el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' });
      back.append(box);
      let done = false;
      const close = (val) => {
        if (done) return;
        done = true;
        const i = modals.findIndex((m) => m.back === back);
        if (i >= 0) modals.splice(i, 1);
        back.remove();
        resolve(val);
      };
      back.addEventListener('pointerdown', (e) => { if (e.target === back) close(null); });
      build(box, close);
      $('#modal-root').append(back);
      modals.push({ back, close: () => close(null) });
      const first = box.querySelector('input,select');
      if (first) setTimeout(() => { first.focus(); if (first.select) first.select(); }, 50);
    });
  }

  function uiPrompt(title, value, placeholder, okLabel) {
    return openModal((box, close) => {
      const input = el('input', { type: 'text', value: value || '', placeholder: placeholder || '', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => close(input.value.trim() || null);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
      box.append(
        el('h3', { text: title }), input,
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          el('button', { class: 'btn primary', text: okLabel || 'OK', onclick: submit }))
      );
    });
  }

  function uiConfirm(title, message, okLabel, danger) {
    return openModal((box, close) => {
      box.append(
        el('h3', { text: title }), el('p', { text: message }),
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(false) }),
          el('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), text: okLabel || 'OK', onclick: () => close(true) }))
      );
    }).then((v) => v === true);
  }

  function uiSheet(title, items) {
    return openModal((box, close) => {
      box.append(el('h3', { text: title }));
      for (const it of items) {
        box.append(el('button', { class: 'sheet-item' + (it.danger ? ' danger' : ''), onclick: () => close(it.id) },
          it.icon ? icon(it.icon, 20) : null, el('span', { text: it.label })));
      }
    });
  }

  // ===================== Estado =====================
  const S = {
    screen: 'home',
    project: null,
    tree: [],
    open: [],
    active: null,
    expanded: new Set(),
    treeHidden: false,
    saveTimers: new Map(),
    failed: new Set(),
    dirty: new Set(),
    link: null,
    explorerOpen: false,
    sideView: 'explorer',
    running: null,
  };

  function showScreen(name) {
    S.screen = name;
    for (const id of ['home', 'ide', 'run', 'settings', 'update']) $('#' + id).classList.toggle('hidden', id !== name);
  }

  // ===================== Editor =====================
  let Ed = window.CVEditor;
  let fallbackTa = null;

  function initEditor() {
    const host = $('#editor-host');
    if (Ed && Ed.available) {
      Ed.init(host, {
        change: (path) => scheduleSave(path),
        cursor: (l, c) => { $('#st-pos').textContent = 'Ln ' + l + ', Col ' + c; },
      });
      return;
    }
    toast('Editor avançado indisponível; a usar editor simples.', true);
    const texts = new Map();
    let cur = null;
    fallbackTa = el('textarea', { class: 'fallback-editor', spellcheck: 'false', autocapitalize: 'off', autocorrect: 'off' });
    fallbackTa.addEventListener('input', () => { if (cur) { texts.set(cur, fallbackTa.value); scheduleSave(cur); } });
    host.append(fallbackTa);
    Ed = {
      available: false,
      open(p, t) { if (cur) texts.set(cur, fallbackTa.value); cur = p; if (!texts.has(p)) texts.set(p, t); fallbackTa.value = texts.get(p); },
      getText(p) { return p === cur ? fallbackTa.value : (texts.has(p) ? texts.get(p) : null); },
      has(p) { return texts.has(p); },
      close(p) { texts.delete(p); if (cur === p) cur = null; },
      clearAll() { texts.clear(); cur = null; fallbackTa.value = ''; },
      languageOf: () => 'text',
      focus() { fallbackTa.focus(); },
      find() { toast('Pesquisa não disponível no editor simples.', true); },
      undo() { document.execCommand('undo'); }, redo() { document.execCommand('redo'); },
      selectAll() { fallbackTa.select(); },
      tab() { Ed.insert('    '); },
      insert(t) { const s = fallbackTa.selectionStart, e = fallbackTa.selectionEnd; fallbackTa.setRangeText(t, s, e, 'end'); fallbackTa.dispatchEvent(new Event('input')); fallbackTa.focus(); },
      moveCursor(d) { fallbackTa.selectionStart = fallbackTa.selectionEnd = Math.max(0, fallbackTa.selectionStart + d); fallbackTa.focus(); },
      goto() { fallbackTa.focus(); },
      setWrap(on) { fallbackTa.style.whiteSpace = on ? 'pre-wrap' : 'pre'; },
      setTabSize() {},
      tabSizeOf: () => 4,
    };
  }

  // ===================== Gravação automática =====================
  function scheduleSave(path) {
    if (!S.project) return;
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.set(path, setTimeout(() => saveNow(path), settings.autoSaveMs));
    if (!S.dirty.has(path)) { S.dirty.add(path); renderTabs(); }
    updateSaveBtn();
  }

  function updateSaveBtn() {
    const b = $('#btn-save');
    if (b) b.classList.toggle('dirty', S.dirty.size > 0);
  }

  // Botão Guardar: grava já tudo o que está pendente (e o ficheiro ativo), no projeto e na pasta ligada do telemóvel.
  function saveAll() {
    if (!S.project) return;
    const pending = S.dirty.size;
    flushSaves();
    if (S.active) saveNow(S.active);
    if (S.failed.size) return;
    if (S.link && S.link.linked) toast(pending ? 'Guardado no telemóvel (pasta ligada)' : 'Tudo guardado');
    else toast(pending ? 'Guardado' : 'Tudo guardado');
  }

  function saveNow(path) {
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.delete(path);
    if (!S.project) return true;
    const text = Ed.getText(path);
    if (text == null) return true;
    try {
      nat('writeFile', S.project, path, text);
      const wasDirty = S.dirty.delete(path);
      if (S.failed.delete(path) || wasDirty) renderTabs();
      updateSaveBtn();
      if (window.CVGit) window.CVGit.touch();
      return true;
    } catch (e) {
      if (!S.failed.has(path)) { S.failed.add(path); renderTabs(); }
      toast('Erro ao guardar ' + basename(path) + ': ' + e.message, true);
      return false;
    }
  }

  function flushSaves() { for (const p of Array.from(S.saveTimers.keys())) saveNow(p); }

  // ===================== Início =====================
  function loadHome() {
    showScreen('home');
    const list = $('#project-list');
    list.textContent = '';
    let projects = [];
    try { projects = nat('listProjects').projects; } catch (e) { toast(e.message, true); }
    $('#home-empty').classList.toggle('hidden', projects.length > 0);
    let recent = {};
    try { recent = JSON.parse(localStorage.getItem('cv.recent') || '{}'); } catch (_) { /* ignora */ }
    projects.sort((a, b) => Math.max(b.modified, recent[b.name] || 0) - Math.max(a.modified, recent[a.name] || 0));
    for (const p of projects) {
      const when = Math.max(p.modified, recent[p.name] || 0);
      list.append(
        el('li', { class: 'project-item', role: 'button', tabindex: '0', onclick: () => openProject(p.name) },
          el('span', { class: 'pico', html: I.svg('folder', 22) }),
          el('div', { class: 'pmain' },
            el('div', { class: 'pname', text: p.name }),
            el('div', { class: 'pmeta', text: 'Modificado ' + relTime(when) + linkText(p.name) })),
          el('button', {
            class: 'icon-btn', 'aria-label': 'Opções de ' + p.name, html: I.svg('more', 20),
            onclick: (ev) => { ev.stopPropagation(); projectMenu(p.name); },
          }))
      );
    }
  }

  function linkText(name) {
    try { const l = nat('linkInfo', name); if (l.linked) return ' · ligado ao telemóvel' + (l.label && l.type === 'tree' ? ' (' + l.label + ')' : ''); } catch (_) { /* ignora */ }
    return '';
  }

  function isLinked(name) { try { return !!nat('linkInfo', name).linked; } catch (_) { return false; } }

  function refreshFromStorage(name) {
    flushSaves();
    toast('A ler do armazenamento…');
    nativeListeners.storage = (m) => {
      if (m.op !== 'refresh') return;
      if (!m.ok) { toast('Falha ao atualizar: ' + (m.error || ''), true); return; }
      toast('Atualizado a partir do armazenamento');
      if (S.project === m.project && S.screen === 'ide') {
        const act = S.active;
        for (const p of S.open) { clearTimeout(S.saveTimers.get(p)); S.saveTimers.delete(p); S.dirty.delete(p); Ed.close(p); }
        updateSaveBtn();
        refreshTree();
        if (act) activate(act, true); else renderTabs();
      }
    };
    try { nat('storageRefresh', name); } catch (e) { toast(e.message, true); }
  }

  async function unlinkStorage(name) {
    if (!(await uiConfirm('Desligar do armazenamento', 'O projeto deixa de ser guardado na pasta do telemóvel. Os ficheiros da pasta ficam como estão.', 'Desligar'))) return;
    try { nat('storageUnlink', name); S.link = nat('linkInfo', name); $('#st-link').classList.add('hidden'); toast('Desligado'); if (S.screen === 'home') loadHome(); } catch (e) { toast(e.message, true); }
  }

  async function projectMenu(name) {
    const a = await uiSheet(name, [
      { id: 'open', label: 'Abrir', icon: 'folder' },
      { id: 'rename', label: 'Renomear', icon: 'edit' },
      { id: 'export', label: 'Exportar ZIP', icon: 'export' },
      ...(isLinked(name) ? [{ id: 'sync', label: 'Atualizar do armazenamento', icon: 'refresh' }, { id: 'unlink', label: 'Desligar do armazenamento', icon: 'close' }] : []),
      { id: 'delete', label: 'Eliminar', icon: 'trash', danger: true },
    ]);
    if (a === 'sync') refreshFromStorage(name);
    else if (a === 'unlink') unlinkStorage(name);
    else if (a === 'open') openProject(name);
    else if (a === 'rename') {
      const n = await uiPrompt('Renomear projeto', name, 'Novo nome', 'Renomear');
      if (!n) return;
      try { nat('renameProject', name, n); loadHome(); } catch (e) { toast(e.message, true); }
    } else if (a === 'export') exportProject(name);
    else if (a === 'delete') {
      if (await uiConfirm('Eliminar projeto', 'Eliminar “' + name + '” e todos os ficheiros? Isto não pode ser desfeito.', 'Eliminar', true)) {
        try { nat('deleteProject', name); loadHome(); toast('Projeto eliminado'); } catch (e) { toast(e.message, true); }
      }
    }
  }

  const TPL_ICON = { web: 'index.html', 'web-firebase': 'index.html', 'web-supabase': 'index.html', python: 'main.py', java: 'Main.java', dart: 'main.dart', flutter: 'main.dart' };

  async function newProjectDialog() {
    const tpls = window.CV_TEMPLATES;
    let sel = tpls[0];
    const result = await openModal((box, close) => {
      const input = el('input', { type: 'text', placeholder: 'Nome do projeto', value: 'meu-projeto', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const choices = tpls.map((t) => {
        const c = el('div', { class: 'choice' + (t === sel ? ' sel' : ''), role: 'radio', tabindex: '0' },
          fileIcon(TPL_ICON[t.id] || 'x.txt', 22),
          el('div', {}, el('div', { text: t.name }), el('span', { class: 'sub', text: t.desc })));
        c.addEventListener('click', () => { sel = t; choices.forEach((x) => x.classList.remove('sel')); c.classList.add('sel'); });
        return c;
      });
      box.append(
        el('h3', { text: 'Novo projeto' }),
        el('label', { class: 'field', text: 'Nome' }), input,
        el('label', { class: 'field', text: 'Modelo' }), ...choices,
        el('div', { class: 'modal-actions' },
          el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          el('button', { class: 'btn primary', text: 'Criar', onclick: () => close({ name: input.value.trim(), tpl: sel }) }))
      );
    });
    if (!result || !result.name) return;
    try {
      const r = nat('createProject', result.name);
      nat('writeFiles', r.name, JSON.stringify(result.tpl.files));
      openProject(r.name, result.tpl.main);
    } catch (e) { toast(e.message, true); }
  }

  function exportProject(name) {
    nativeListeners.export = (m) => {
      if (m.ok) toast('ZIP exportado com sucesso');
      else if (!m.cancelled) toast('Falha ao exportar: ' + (m.error || ''), true);
    };
    try { nat('exportZip', name); } catch (e) { toast(e.message, true); }
  }

  function pickFolder() { try { nat('pickFolder'); } catch (e) { toast(e.message, true); } }
  function pickFiles() { try { nat('pickFiles'); } catch (e) { toast(e.message, true); } }

  function importZip() {
    nativeListeners.import = (m) => {
      if (m.ok) { toast('Projeto “' + m.name + '” importado'); loadHome(); }
      else if (!m.cancelled) toast('Falha ao importar: ' + (m.error || ''), true);
    };
    try { nat('importZip'); } catch (e) { toast(e.message, true); }
  }

  // ===================== Projeto aberto =====================
  function openProject(name, firstFile) {
    if (S.project) flushSaves();
    S.project = name;
    S.open = []; S.active = null; S.failed.clear(); S.dirty.clear(); S.expanded.clear();
    updateSaveBtn();
    try { S.link = nat('linkInfo', name); } catch (_) { S.link = null; }
    const lk = $('#st-link');
    if (S.link && S.link.linked) { lk.textContent = 'Pasta do telemóvel: ' + (S.link.label || ''); lk.classList.remove('hidden'); }
    else lk.classList.add('hidden');
    Ed.clearAll();
    try {
      const recent = JSON.parse(localStorage.getItem('cv.recent') || '{}');
      recent[name] = Date.now();
      localStorage.setItem('cv.recent', JSON.stringify(recent));
    } catch (_) { /* ignora */ }
    $('#ide-title').textContent = name;
    S.treeHidden = false;
    renderProjectRow();
    $('#st-proj').textContent = name;
    $('#search-results').textContent = '';
    $('#search-input').value = '';
    if (window.CVGit) window.CVGit.onProject(name);
    showScreen('ide');
    setSideView('explorer');
    refreshTree();
    toggleExplorer(false);
    renderTabs();
    $('#empty-editor').classList.remove('hidden');
    $('#st-lang').textContent = '—';
    $('#st-pos').textContent = 'Ln 1, Col 1';
    updateIndentLabel();
    let target = firstFile;
    if (!target) {
      const files = S.tree.filter((i) => !i.dir).map((i) => i.path);
      target = ['index.html', 'main.py', 'Main.java', 'main.dart', 'lib/main.dart', 'README.md'].find((c) => files.includes(c)) || files[0];
    }
    if (target) openFile(target);
    else toggleExplorer(true);
  }

  function closeProject() {
    flushSaves();
    stopRun(true);
    S.project = null;
    if (window.CVGit) window.CVGit.onProject(null);
    resetPython();
    loadHome();
  }

  function refreshTree() {
    if (!S.project) return;
    try { S.tree = nat('tree', S.project).items; } catch (e) { toast(e.message, true); S.tree = []; }
    renderTree();
    if (window.CVGit) window.CVGit.touch();
  }

  // Volta a ler do disco tudo o que está aberto (depois de pull, mudar de branch, descartar…).
  function reloadFromDisk() {
    if (!S.project) return;
    const act = S.active;
    for (const p of S.open) { clearTimeout(S.saveTimers.get(p)); S.saveTimers.delete(p); S.dirty.delete(p); S.failed.delete(p); Ed.close(p); }
    updateSaveBtn();
    refreshTree();
    const files = new Set(S.tree.filter((i) => !i.dir).map((i) => i.path));
    S.open = S.open.filter((p) => files.has(p));
    if (act && files.has(act)) activate(act, true);
    else if (S.open.length) activate(S.open[0], true);
    else {
      S.active = null;
      $('#empty-editor').classList.remove('hidden');
      $('#st-lang').textContent = '—';
      renderCrumbs();
      renderTabs();
    }
  }

  // ----- Explorador -----
  function buildTree(list) {
    const root = { children: new Map(), dir: true, path: '' };
    for (const it of list) {
      const parts = it.path.split('/');
      let n = root;
      parts.forEach((p, i) => {
        const last = i === parts.length - 1;
        let c = n.children.get(p);
        if (!c) {
          c = { name: p, path: parts.slice(0, i + 1).join('/'), dir: last ? it.dir : true, children: new Map() };
          n.children.set(p, c);
        } else if (last) c.dir = it.dir;
        n = c;
      });
    }
    return root;
  }

  function renderProjectRow() {
    const h = $('#ex-project');
    h.textContent = '';
    if (!S.project) return;
    h.append(
      el('span', { class: 'chev', html: I.svg(S.treeHidden ? 'chevron-right' : 'chevron-down', 14) }),
      fileIcon(S.treeHidden ? 'folder' : 'folder-open', 18),
      el('span', { class: 'pn', text: S.project }),
      el('button', { class: 'more', 'aria-label': 'Opções da pasta', html: I.svg('more', 18), onclick: (ev) => { ev.stopPropagation(); projectFolderMenu(); } }));
    h.setAttribute('aria-expanded', String(!S.treeHidden));
  }

  function toggleTree(show) {
    S.treeHidden = show === undefined ? !S.treeHidden : !show;
    renderProjectRow();
    renderTree();
  }

  async function projectFolderMenu() {
    if (!S.project) return;
    const a = await uiSheet(S.project, [
      { id: 'close', label: 'Fechar', icon: 'close' },
      { id: 'nf', label: 'Criar novo ficheiro', icon: 'new-file' },
      { id: 'nd', label: 'Criar nova pasta', icon: 'new-folder' },
      { id: 'del', label: 'Eliminar pasta', icon: 'trash', danger: true },
    ]);
    if (a === 'close') closeProject();
    else if (a === 'nf') { toggleTree(true); newEntry(false); }
    else if (a === 'nd') { toggleTree(true); newEntry(true); }
    else if (a === 'del') {
      const name = S.project;
      if (!(await uiConfirm('Eliminar pasta', 'Eliminar “' + name + '” e todos os ficheiros? Isto não pode ser desfeito.', 'Eliminar', true))) return;
      try {
        for (const t of S.saveTimers.values()) clearTimeout(t);
        S.saveTimers.clear(); S.dirty.clear();
        stopRun(true);
        nat('deleteProject', name);
        S.project = null;
        resetPython();
        loadHome();
        toast('Pasta eliminada');
      } catch (e) { toast(e.message, true); }
    }
  }

  function bindProjectRow() {
    const h = $('#ex-project');
    let timer = null, fired = false, sx = 0, sy = 0;
    const cancel = () => { clearTimeout(timer); timer = null; };
    h.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.more')) return;
      fired = false; sx = e.clientX; sy = e.clientY;
      timer = setTimeout(() => {
        timer = null; fired = true;
        try { if (settings.haptics && navigator.vibrate) navigator.vibrate(15); } catch (_) { /* ignora */ }
        projectFolderMenu();
      }, 500);
    });
    h.addEventListener('pointermove', (e) => { if (timer && (Math.abs(e.clientX - sx) > 10 || Math.abs(e.clientY - sy) > 10)) cancel(); });
    for (const t of ['pointerup', 'pointercancel', 'pointerleave']) h.addEventListener(t, cancel);
    h.addEventListener('contextmenu', (e) => e.preventDefault());
    h.addEventListener('click', (e) => {
      if (fired) { fired = false; return; }
      if (e.target.closest('.more')) return;
      toggleTree();
    });
  }

  function renderTree() {
    const host = $('#tree');
    host.textContent = '';
    host.classList.toggle('hidden', S.treeHidden);
    if (S.treeHidden) return;
    if (!S.tree.length) { host.append(el('div', { class: 'empty-tree', text: 'Projeto vazio. Usa o botão “Novo ficheiro” acima.' })); return; }
    const root = buildTree(S.tree);
    const walk = (node, depth) => {
      const kids = Array.from(node.children.values()).sort((a, b) => (a.dir === b.dir ? a.name.localeCompare(b.name) : a.dir ? -1 : 1));
      for (const k of kids) {
        const open = S.expanded.has(k.path);
        const row = el('div', { class: 'row' + (k.path === S.active ? ' active' : ''), role: 'treeitem', style: 'padding-left:' + (6 + depth * 14) + 'px' },
          el('span', { class: 'chev', html: k.dir ? I.svg(open ? 'chevron-down' : 'chevron-right', 14) : '' }),
          fileIcon(k.dir ? (open ? 'folder-open' : 'folder') : k.name, 18),
          el('span', { class: 'nm', text: k.name }),
          window.CVGit ? window.CVGit.badge(k.path, k.dir) : null,
          el('button', { class: 'more', 'aria-label': 'Opções de ' + k.name, html: I.svg('more', 18), onclick: (ev) => { ev.stopPropagation(); entryMenu(k); } }));
        row.addEventListener('click', () => {
          if (k.dir) { if (open) S.expanded.delete(k.path); else S.expanded.add(k.path); renderTree(); }
          else { openFile(k.path); toggleExplorer(false); }
        });
        host.append(row);
        if (k.dir && open) walk(k, depth + 1);
      }
    };
    walk(root, 0);
  }

  async function entryMenu(k) {
    const items = [];
    if (k.dir) items.push({ id: 'nf', label: 'Novo ficheiro aqui', icon: 'new-file' }, { id: 'nd', label: 'Nova pasta aqui', icon: 'new-folder' });
    items.push({ id: 'rn', label: 'Renomear', icon: 'edit' }, { id: 'del', label: 'Eliminar', icon: 'trash', danger: true });
    const a = await uiSheet(k.name, items);
    if (a === 'nf') newEntry(false, k.path);
    else if (a === 'nd') newEntry(true, k.path);
    else if (a === 'rn') renameEntry(k);
    else if (a === 'del') deleteEntry(k);
  }

  function isFlutterProject() {
    return S.tree.some((i) => i.path === 'pubspec.yaml') && /flutter/.test(readTextSafe('pubspec.yaml'));
  }

  async function newEntry(isDir, parent) {
    const base = parent === undefined ? '' : parent;
    const name = await uiPrompt(isDir ? 'Nova pasta' : 'Novo ficheiro', '', isDir ? 'nome-da-pasta' : 'ficheiro.ext', 'Criar');
    if (!name) return;
    if (/[\\:*?"<>|]/.test(name) || name.split('/').some((p) => p === '..')) { toast('Nome inválido', true); return; }
    const path = normalizePath(joinPath(base, name));
    try {
      let cursor;
      if (isDir) nat('mkdir', S.project, path);
      else {
        nat('createFile', S.project, path);
        let flutter = isFlutterProject();
        if (extOf(path) === 'dart' && !flutter) {
          const k = await uiSheet('Tipo de ficheiro Dart', [
            { id: 'dart', label: 'Dart (consola)', icon: 'code' },
            { id: 'flutter', label: 'Flutter (widget)', icon: 'code' },
          ]);
          flutter = k === 'flutter';
        }
        const tpl = window.CV_fileTemplate ? window.CV_fileTemplate(path, { flutter }) : { text: '', cursor: 0 };
        if (tpl.text) { nat('writeFile', S.project, path, tpl.text); cursor = tpl.cursor; }
      }
      if (base) S.expanded.add(base);
      let d = dirname(path);
      while (d) { S.expanded.add(d); d = dirname(d); }
      refreshTree();
      if (!isDir) { openFile(path, cursor); toggleExplorer(false); }
    } catch (e) { toast(e.message, true); }
  }

  async function renameEntry(k) {
    const n = await uiPrompt('Renomear', k.name, 'Novo nome', 'Renomear');
    if (!n || n === k.name) return;
    if (/[\\/:*?"<>|]/.test(n)) { toast('Nome inválido', true); return; }
    const to = joinPath(dirname(k.path), n);
    flushSaves();
    try {
      nat('renamePath', S.project, k.path, to);
      const affected = S.open.filter((p) => p === k.path || p.startsWith(k.path + '/'));
      const oldActive = S.active;
      for (const p of affected) {
        const np = to + p.slice(k.path.length);
        Ed.close(p);
        S.open[S.open.indexOf(p)] = np;
        if (S.active === p) S.active = np;
      }
      refreshTree();
      if (oldActive && affected.includes(oldActive)) activate(S.active, true);
      else renderTabs();
    } catch (e) { toast(e.message, true); }
  }

  async function deleteEntry(k) {
    if (settings.confirmDelete && !(await uiConfirm('Eliminar', 'Eliminar “' + k.name + '”' + (k.dir ? ' e todo o conteúdo' : '') + '?', 'Eliminar', true))) return;
    flushSaves();
    try {
      nat('deletePath', S.project, k.path);
      for (const p of S.open.filter((x) => x === k.path || x.startsWith(k.path + '/'))) closeTab(p, true);
      refreshTree();
    } catch (e) { toast(e.message, true); }
  }

  function toggleExplorer(open) {
    S.explorerOpen = open;
    $('#explorer').classList.toggle('open', open);
    $('#scrim').classList.toggle('hidden', !open);
  }

  function setSideView(v) {
    S.sideView = v;
    $('#view-explorer').classList.toggle('hidden', v !== 'explorer');
    $('#view-search').classList.toggle('hidden', v !== 'search');
    $('#view-ext').classList.toggle('hidden', v !== 'ext');
    $('#view-git').classList.toggle('hidden', v !== 'git');
    $('#rail-git').classList.toggle('active', v === 'git');
    if (v === 'git' && window.CVGit) window.CVGit.show();
    $('#rail-explorer').classList.toggle('active', v === 'explorer');
    $('#rail-search').classList.toggle('active', v === 'search');
    $('#rail-ext').classList.toggle('active', v === 'ext');
    if (v === 'ext' && !X.store && !X.loading) loadStore(); else if (v === 'ext') renderExt();
    if (v === 'search') setTimeout(() => $('#search-input').focus(), 80);
  }

  // ----- Extensões (plugins) -----
  const X = { store: null, loading: false, error: null, filter: '', type: 'all', open: { explore: true, installed: true }, expanded: null };

  async function loadStore() {
    X.loading = true; X.error = null; renderExt();
    const sources = [window.CVPlugins.BUNDLED_REGISTRY].concat(window.CVPlugins.registries());
    const all = []; const errs = [];
    for (const u of sources) {
      try { const r = await window.CVPlugins.fetchRegistry(u); for (const p of r.plugins) { p.storeName = r.name; all.push(p); } }
      catch (e) { errs.push((u === window.CVPlugins.BUNDLED_REGISTRY ? 'Loja incluída' : u) + ': ' + e.message); }
    }
    X.store = all; X.error = errs.length ? errs.join('\n') : null; X.loading = false;
    renderExt();
  }

  async function installEntry(p) {
    try {
      toast('A instalar “' + p.name + '”…');
      const m = await window.CVPlugins.installFromUrl(p.url);
      toast('Instalado: ' + m.name);
      if (m.type === 'theme' && await uiConfirm('Usar o tema?', 'Aplicar já o tema “' + m.name + '”?', 'Usar')) window.CVPlugins.setActiveTheme(m.id);
    } catch (e) { toast('Falha ao instalar: ' + e.message, true); }
    renderExt();
  }

  async function installFromUrlDialog() {
    const url = await uiPrompt('Instalar plugin por URL', '', 'https://…/plugin.json', 'Instalar');
    if (!url) return;
    if (!/^https:\/\//i.test(url.trim())) { toast('O endereço tem de começar por https://', true); return; }
    await installEntry({ name: 'plugin', url: url.trim() });
  }

  async function addStoreDialog() {
    const url = await uiPrompt('Adicionar loja de plugins', '', 'https://…/registry.json', 'Adicionar');
    if (!url) return;
    try { window.CVPlugins.addRegistry(url.trim()); toast('Loja adicionada'); X.store = null; loadStore(); } catch (e) { toast(e.message, true); }
  }

  const fmtSize = (n) => (n >= 1024 * 1024 ? (n / 1048576).toFixed(1) + ' MB' : n >= 1024 ? (n / 1024).toFixed(1) + ' KB' : n + ' B');

  // Pequeno menu de escolha (modal) para os botões do cabeçalho.
  function uiChoice(title, options) {
    return openModal((box, close) => {
      box.append(el('h3', { text: title }),
        el('div', { class: 'choice-list' }, ...options.map((o) => el('button', { class: 'choice' + (o.on ? ' on' : ''), text: o.label, onclick: () => close(o.value) }))));
    });
  }

  function iconFor(m) {
    if (m.icon) return m.icon;
    if (m.type === 'theme' && m.theme && m.theme.colors) {
      const c = m.theme.colors;
      return { bg: c.bg, fg: c.keyword, text: '{ }', dots: [c.control, c.string, c.func, c.type].filter(Boolean) };
    }
    const hit = (X.store || []).find((x) => x.id === m.id);
    return hit && hit.icon ? hit.icon : null;
  }

  function extIcon(m) {
    const ic = iconFor(m);
    const t = el('div', { class: 'ext-ico' });
    if (ic) {
      t.style.background = ic.bg; t.style.color = ic.fg;
      t.append(el('span', { class: 'ext-ico-text', text: ic.text || '' }));
      if (ic.dots && ic.dots.length) {
        const dots = el('span', { class: 'ext-dots' });
        for (const c of ic.dots) { const d = el('i'); d.style.background = c; dots.append(d); }
        t.append(dots);
      }
    } else {
      let h = 0; for (const ch of m.name) h = (h * 31 + ch.charCodeAt(0)) % 360;
      t.style.background = 'hsl(' + h + ',45%,38%)'; t.style.color = '#fff';
      t.append(el('span', { class: 'ext-ico-text', text: m.name.slice(0, 1).toUpperCase() }));
    }
    return t;
  }

  // Linha no estilo da loja de plugins do Acode: ícone, nome, "vX • tipo • tamanho" e botão à direita.
  function extRow(p, state) {
    const P = window.CVPlugins;
    const inst = P.get(p.id);
    const isTheme = p.type === 'theme';
    const core = p.id === 'dark-plus';
    const version = core ? '' : 'v' + (inst ? inst.version : p.version);
    const meta = [version, isTheme ? 'Tema' : 'Snippets', p.size ? fmtSize(p.size) : (p.publisher || '')].filter(Boolean).join(' • ');
    const hasUpdate = !!(inst && p.url && p.version && inst.version !== p.version);
    const open = X.expanded === p.id;

    let side;
    if (state === 'explore' || hasUpdate) {
      side = el('button', { class: 'ext-dl' + (hasUpdate ? ' upd' : ''), 'aria-label': hasUpdate ? 'Atualizar' : 'Instalar', html: I.svg('download', 20),
        onclick: (e) => { e.stopPropagation(); installEntry(p); } });
    } else if (isTheme) {
      const on = P.activeTheme() === p.id;
      side = el('span', { class: 'ext-state' + (on ? ' on' : ''), text: on ? 'Em uso' : '' });
    } else {
      side = el('span', { class: 'ext-state' + (inst && inst.enabled !== false ? ' on' : ''), text: inst && inst.enabled === false ? 'Desativado' : '' });
    }

    const row = el('div', { class: 'ext-row' + (open ? ' open' : '') },
      el('div', { class: 'ext-line', onclick: () => { X.expanded = open ? null : p.id; renderExt(); } },
        extIcon(p),
        el('div', { class: 'ext-main' },
          el('div', { class: 'ext-name', text: p.name }),
          el('div', { class: 'ext-meta', text: meta })),
        side));
    if (open) {
      const actions = [];
      if (core) {
        const on = P.activeTheme() === 'dark-plus';
        actions.push(el('button', { class: 'btn', text: on ? 'Em uso' : 'Usar', disabled: on ? '' : null, onclick: () => P.setActiveTheme('dark-plus') }));
      } else if (!inst) {
        actions.push(el('button', { class: 'btn primary', text: 'Instalar', onclick: () => installEntry(p) }));
      } else {
        if (hasUpdate) actions.push(el('button', { class: 'btn primary', text: 'Atualizar', onclick: () => installEntry(p) }));
        if (isTheme) {
          const on = P.activeTheme() === p.id;
          actions.push(el('button', { class: 'btn', text: on ? 'Em uso' : 'Usar', disabled: on ? '' : null, onclick: () => P.setActiveTheme(p.id) }));
        } else {
          const en = inst.enabled !== false;
          actions.push(el('button', { class: 'btn', text: en ? 'Desativar' : 'Ativar', onclick: () => P.setEnabled(p.id, !en) }));
        }
        actions.push(el('button', { class: 'btn danger', text: 'Desinstalar', onclick: async () => { if (await uiConfirm('Desinstalar', 'Desinstalar “' + p.name + '”?', 'Desinstalar', true)) P.uninstall(p.id); } }));
      }
      row.append(el('div', { class: 'ext-detail' },
        el('div', { class: 'ext-desc', text: p.description || '' }),
        p.publisher ? el('div', { class: 'ext-pub', text: 'Autor: ' + p.publisher }) : null,
        el('div', { class: 'ext-actions' }, ...actions)));
    }
    return row;
  }

  function extSection(key, title, count, rows, emptyText) {
    const open = X.open[key];
    const head = el('button', { class: 'ext-sec-head', onclick: () => { X.open[key] = !open; renderExt(); } },
      el('span', { class: 'ext-chev' + (open ? ' open' : ''), html: I.svg('chevron-down', 16) }),
      el('span', { class: 'ext-sec-title', text: title }),
      el('span', { class: 'ext-sec-count', text: String(count) }));
    const sec = el('div', { class: 'ext-sec' }, head);
    if (open) {
      if (rows.length) sec.append(...rows);
      else sec.append(el('p', { class: 'muted ext-empty', text: emptyText }));
    }
    return sec;
  }

  function renderExt() {
    const host = $('#ext-list');
    if (!host) return;
    host.textContent = '';
    const q = norm(X.filter.trim());
    const match = (p) => (X.type === 'all' || p.type === X.type) && (!q || norm(p.name + ' ' + (p.description || '') + ' ' + (p.type === 'theme' ? 'tema theme' : 'snippets') + ' ' + (p.publisher || '')).includes(q));
    const P = window.CVPlugins;
    $('#ext-filter-btn').classList.toggle('active', X.type !== 'all');

    if (X.error) host.append(el('p', { class: 'ext-error', text: X.error }));

    // Explorar: o que ainda não está instalado (e atualizações)
    let explore = [];
    if (X.loading) host.append(el('p', { class: 'muted ext-empty', text: 'A carregar a loja…' }));
    else explore = (X.store || []).filter((p) => (!P.isInstalled(p.id) || (P.get(p.id).version !== p.version)) && match(p));
    if (!X.loading) host.append(extSection('explore', 'Explorar', explore.length, explore.map((p) => extRow(p, 'explore')), q ? 'Nenhum plugin encontrado.' : 'Já instalaste tudo o que a loja tem.'));

    // Instalado (com o tema predefinido incluído)
    const core = { id: 'dark-plus', name: 'Dark+ (VS Code)', type: 'theme', version: '', publisher: 'CodeVerse', description: 'Tema predefinido: cores do Dark+ do VS Code sobre azul-escuro.', icon: { bg: '#0f141d', fg: '#569cd6', text: '{ }', dots: ['#c586c0', '#ce9178', '#dcdcaa', '#4ec9b0'] } };
    const inst = P.installed().filter(match).map((m) => Object.assign({ icon: null }, m));
    const rows = [];
    if (match(core)) rows.push(extRow(core, 'installed'));
    for (const m of inst) rows.push(extRow(m, 'installed'));
    host.append(extSection('installed', 'Instalado', rows.length, rows, 'Ainda não instalaste plugins.'));
  }

  async function extFilterMenu() {
    const v = await uiChoice('Mostrar', [
      { label: 'Todos', value: 'all', on: X.type === 'all' },
      { label: 'Temas', value: 'theme', on: X.type === 'theme' },
      { label: 'Snippets', value: 'snippets', on: X.type === 'snippets' },
    ]);
    if (v) { X.type = v; renderExt(); }
  }

  async function extPlusMenu() {
    const v = await uiChoice('Adicionar', [
      { label: 'Instalar por URL…', value: 'url' },
      { label: 'Adicionar loja…', value: 'store' },
      { label: 'Atualizar lista', value: 'reload' },
    ]);
    if (v === 'url') installFromUrlDialog();
    else if (v === 'store') addStoreDialog();
    else if (v === 'reload') { X.store = null; loadStore(); }
  }

  // ----- Pesquisa em todos os ficheiros -----
  function searchAll(q) {
    const host = $('#search-results');
    host.textContent = '';
    q = q.trim();
    if (!q || !S.project) return;
    flushSaves();
    const needle = q.toLowerCase();
    const files = textFilesOfProject(() => true, 400);
    let total = 0;
    for (const f of files) {
      const hits = [];
      f.content.split('\n').forEach((ln, i) => {
        const idx = ln.toLowerCase().indexOf(needle);
        if (idx >= 0 && hits.length < 40) hits.push({ line: i + 1, idx, text: ln });
      });
      if (!hits.length) continue;
      host.append(el('div', { class: 'res-file' }, fileIcon(basename(f.path), 16), el('span', { text: f.path }), el('span', { class: 'cnt', text: String(hits.length) })));
      for (const h of hits) {
        const trimmed = h.text.trimStart();
        const i = h.idx - (h.text.length - trimmed.length);
        const from = Math.max(0, i - 24);
        const chunk = trimmed.slice(from, from + 140);
        const li = i - from;
        const b = el('button', { class: 'res-line' },
          chunk.slice(0, li), el('mark', { text: chunk.slice(li, li + q.length) }), chunk.slice(li + q.length));
        b.addEventListener('click', () => { openFile(f.path); Ed.goto(h.line, h.idx + 1); toggleExplorer(false); });
        host.append(b);
        if (++total >= 300) break;
      }
      if (total >= 300) break;
    }
    if (!total) host.append(el('div', { class: 'empty-tree', text: 'Sem resultados.' }));
  }

  // ----- Separadores / ficheiros -----
  function openFile(path, cursor) {
    if (S.open.includes(path)) { activate(path); return; }
    let res;
    try { res = nat('readFile', S.project, path); } catch (e) { toast(e.message, true); return; }
    if (res.binary) { toast('Ficheiro binário: não pode ser editado como texto.', true); return; }
    if (res.tooLarge) { toast('Ficheiro demasiado grande para editar (máx. 2 MB).', true); return; }
    Ed.open(path, res.text, cursor);
    S.open.push(path);
    S.active = path;
    afterActivate();
  }

  function activate(path, forceReload) {
    if (!S.open.includes(path)) return;
    if (forceReload || !Ed.has(path)) {
      let res;
      try { res = nat('readFile', S.project, path); } catch (e) { toast(e.message, true); return; }
      Ed.open(path, res.text || '');
    } else {
      Ed.open(path, '');
    }
    S.active = path;
    afterActivate();
  }

  function afterActivate() {
    $('#empty-editor').classList.add('hidden');
    $('#st-lang').textContent = langLabel(S.active);
    updateIndentLabel();
    renderTabs();
    renderCrumbs();
    renderTree();
    const t = $('#tabs .tab.active');
    if (t && t.scrollIntoView) t.scrollIntoView({ inline: 'nearest', block: 'nearest' });
    Ed.focus();
  }

  function updateIndentLabel() {
    const n = S.active && Ed && Ed.tabSizeOf ? Ed.tabSizeOf(S.active) : (settings.tabSize || 4);
    const e = $('#st-indent');
    if (e) e.textContent = 'Espaços: ' + n;
  }

  function langLabel(path) {
    const names = { html: 'HTML', css: 'CSS', javascript: 'JavaScript', typescript: 'TypeScript', json: 'JSON', python: 'Python', java: 'Java', dart: 'Dart', markdown: 'Markdown', text: 'Texto' };
    return names[Ed.languageOf(path)] || 'Texto';
  }

  function closeTab(path, skipSave) {
    if (!skipSave) saveNow(path);
    const i = S.open.indexOf(path);
    if (i < 0) return;
    S.open.splice(i, 1);
    clearTimeout(S.saveTimers.get(path));
    S.saveTimers.delete(path);
    S.dirty.delete(path);
    updateSaveBtn();
    Ed.close(path);
    if (S.active === path) {
      S.active = null;
      const next = S.open[Math.min(i, S.open.length - 1)];
      if (next) activate(next);
      else {
        $('#empty-editor').classList.remove('hidden');
        $('#st-lang').textContent = '—';
        renderCrumbs();
      }
    }
    renderTabs();
    renderTree();
  }

  function renderTabs() {
    $('#ide').classList.toggle('no-file', !S.active);
    const host = $('#tabs');
    host.textContent = '';
    for (const p of S.open) {
      host.append(
        el('div', { class: 'tab' + (p === S.active ? ' active' : ''), role: 'tab', onclick: () => activate(p) },
          fileIcon(basename(p), 16),
          el('span', { class: 'tname', text: basename(p) }),
          S.failed.has(p) ? el('span', { class: 'dot', title: 'Não guardado', html: I.svg('warning', 12) }) : null,
          (!S.failed.has(p) && S.dirty.has(p)) ? el('span', { class: 'dirty', title: 'Alterações por guardar', text: '●' }) : null,
          el('button', { class: 'x', 'aria-label': 'Fechar ' + basename(p), html: I.svg('close', 14), onclick: (ev) => { ev.stopPropagation(); closeTab(p); } }))
      );
    }
  }

  function renderCrumbs() {
    const host = $('#crumbs');
    host.textContent = '';
    if (!S.active) return;
    const parts = S.active.split('/');
    parts.forEach((p, i) => {
      if (i) host.append(el('span', { class: 'sep', html: I.svg('chevron-right', 12) }));
      const last = i === parts.length - 1;
      host.append(el('span', { class: last ? 'last' : '', text: p }));
    });
  }

  // ===================== Teclas extra =====================
  function buildKeybar() {
    const bar = $('#keybar');
    const keys = [
      { t: 'Tab', w: true, f: () => Ed.tab(), label: 'Tabulação' },
      { i: 'undo', f: () => Ed.undo(), label: 'Desfazer' },
      { i: 'redo', f: () => Ed.redo(), label: 'Refazer' },
      { i: 'back', f: () => Ed.moveCursor(-1), label: 'Cursor para a esquerda' },
      { i: 'send', f: () => Ed.moveCursor(1), label: 'Cursor para a direita' },
    ];
    for (const s of ['{', '}', '(', ')', '[', ']', '<', '>', ';', ':', '=', '"', "'", '`', '/', '\\', '.', ',', '!', '&', '|', '_', '-', '+', '*', '#', '$', '%', '?']) {
      keys.push({ t: s, f: () => Ed.insert(s) });
    }
    for (const k of keys) {
      const b = el('button', { class: 'key' + (k.w ? ' wide' : ''), 'aria-label': k.label || k.t });
      if (k.i) b.innerHTML = I.svg(k.i, 18); else b.textContent = k.t;
      b.addEventListener('pointerdown', (e) => e.preventDefault());
      b.addEventListener('click', k.f);
      bar.append(b);
    }
  }

  // ===================== Ecrã de execução =====================
  const R = { mode: 'term', restart: null, count: 0, open: false, openEl: null, openKind: null, errors: 0, hasInput: false };

  const logHost = () => (R.mode === 'web' ? $('#wc-body') : $('#term'));

  function openRun(o) {
    R.mode = o.mode;
    R.restart = o.restart;
    R.hasInput = !!o.input;
    $('#run-title').textContent = o.title;
    $('#run-sub').textContent = o.sub || '';
    $('#preview').classList.toggle('hidden', o.mode !== 'web');
    $('#term').classList.toggle('hidden', o.mode !== 'term');
    const web = o.mode === 'web';
    $('#run-titlebox').classList.toggle('hidden', web);
    $('#run-addr').classList.toggle('hidden', !web);
    $('#run-menu').classList.toggle('hidden', !web);
    $('#run-clear').classList.toggle('hidden', web);
    const ad = String(o.address || 'localhost'), cut = ad.indexOf('/');
    $('#run-addr-host').textContent = cut < 0 ? ad : ad.slice(0, cut);
    $('#run-addr-path').textContent = cut < 0 ? '' : ad.slice(cut);
    $('#web-console').classList.add('hidden');
    $('#run-input-row').classList.add('hidden');
    clearLog();
    setBadge(0);
    setRunState('', '');
    updateRunUi();
    showScreen('run');
    if (o.mode === 'web') { applyPreviewMode(); requestAnimationFrame(applyPreviewMode); }
  }

  // ----- Pré-visualização: modo telemóvel / computador -----
  const DESKTOP_W = 1280;
  function applyPreviewMode() {
    const f = $('#preview'), body = $('#run-body');
    const desk = settings.previewMode === 'desktop';
    f.classList.toggle('desktop', desk);
    if (!desk) { f.style.width = ''; f.style.height = ''; f.style.transform = ''; return; }
    const w = body.clientWidth, h = body.clientHeight;
    if (!w || !h) return;
    const sc = Math.min(1, w / DESKTOP_W);
    f.style.width = (w / sc) + 'px';
    f.style.height = (h / sc) + 'px';
    f.style.transform = 'scale(' + sc + ')';
  }
  function togglePreviewMode() {
    settings.previewMode = settings.previewMode === 'desktop' ? 'mobile' : 'desktop';
    commitSettings();
    applyPreviewMode();
    toast(settings.previewMode === 'desktop' ? 'Modo computador' : 'Modo telemóvel');
  }
  window.addEventListener('resize', () => { if (S.screen === 'run' && R.mode === 'web') applyPreviewMode(); });

  function clearLog() {
    TI.keep = false;
    termInputHide();
    $('#term').textContent = '';
    $('#wc-body').textContent = '';
    R.count = 0; R.open = false; R.openEl = null; R.openKind = null;
  }

  function setBadge(n) {
    R.errors = n;
    const b = $('#run-menu');
    let badge = $('.badge', b);
    if (!n) { if (badge) badge.remove(); return; }
    if (!badge) { badge = el('span', { class: 'badge' }); b.append(badge); }
    badge.textContent = n > 99 ? '99+' : String(n);
  }

  function logLine(kind, text) { termWrite(kind, String(text) + '\n'); }
  const log = logLine;

  function termWrite(kind, text) {
    const host = logHost();
    const keepInput = host === $('#term') && TI.active;
    if (host === $('#term')) termInputDetach();
    const parts = String(text).split('\n');
    parts.forEach((seg, i) => {
      const isLast = i === parts.length - 1;
      if (isLast && seg === '') return;
      let line = R.open && R.openKind === kind ? R.openEl : null;
      if (!line) { line = el('div', { class: 'l-' + kind }); host.append(line); R.count++; }
      line.textContent += seg;
      if (isLast) { R.open = true; R.openEl = line; R.openKind = kind; } else { R.open = false; }
    });
    while (R.count > 3000 && host.firstChild) { host.firstChild.remove(); R.count--; }
    host.scrollTop = host.scrollHeight;
    if (keepInput) termInputShow(TI.send, false);
  }

  // ----- Entrada do programa DENTRO do ecrã (cursor a piscar logo a seguir ao texto) -----
  const TI = { wrap: null, input: null, send: null, active: false };

  function termInputEnsure() {
    if (TI.wrap) return;
    TI.input = el('input', { class: 'term-inline', type: 'text', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', autocomplete: 'off', enterkeyhint: 'send', 'aria-label': 'Entrada do programa' });
    TI.wrap = el('span', { class: 'term-in' }, TI.input);
    const fit = () => { TI.input.style.width = Math.max(2, TI.input.value.length + 1) + 'ch'; };
    TI.input.addEventListener('input', fit);
    TI.input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); termInputSubmit(); } });
    fit();
  }

  // Tira o campo do ecrã (para o termWrite poder escrever) sem perder o que foi escrito.
  function termInputDetach() {
    if (!TI.wrap || !TI.wrap.parentNode) return;
    const line = TI.wrap.parentNode;
    TI.wrap.remove();
    if (line.classList && line.classList.contains('l-in-line') && !line.textContent) {
      line.remove(); R.count--;
    }
  }

  function termInputShow(send, focus) {
    const host = $('#term');
    termInputEnsure();
    TI.send = send; TI.active = true;
    if (TI.wrap.parentNode) TI.wrap.remove();
    // O cursor fica sempre numa linha própria, por baixo do texto (e não ao lado do pedido).
    R.open = false; R.openEl = null; R.openKind = null;
    const line = el('div', { class: 'l-in-line' });
    host.append(line); R.count++;
    line.append(TI.wrap);
    host.scrollTop = host.scrollHeight;
    if (focus) setTimeout(() => { if (TI.input) TI.input.focus(); }, 30);
  }

  function termInputHide() {
    TI.active = false; TI.send = null;
    termInputDetach();
  }

  function termInputSubmit() {
    if (!TI.wrap || !TI.send || !TI.wrap.parentNode) return;
    const text = TI.input.value;
    const send = TI.send;
    const keep = TI.keep;
    const line = TI.wrap.parentNode;
    TI.input.value = '';
    TI.input.style.width = '2ch';
    TI.wrap.remove();
    line.append(el('span', { class: 'l-in', text }));
    R.open = false; R.openEl = null; R.openKind = null;
    TI.active = false; TI.send = null;
    try { send(text); } catch (_) { /* ignora */ }
    if (keep) termInputShow(send, true);
  }

  function setRunState(text, kind) {
    const e = $('#run-state');
    e.textContent = text;
    e.className = 'st-item' + (kind ? ' ' + kind : '');
  }

  function updateRunUi() {
    $('#run-stop').classList.toggle('hidden', !S.running);
    $('#run-restart').classList.toggle('hidden', !!S.running || R.mode === 'web');
  }

  function setRunning(r, state) {
    S.running = r;
    updateRunUi();
    if (state !== undefined) setRunState(state, '');
  }

  function finishRun(ok, text) {
    S.running = null;
    updateRunUi();
    termInputHide();
    setRunState((ok ? '✓ ' : '✗ ') + text, ok ? 'ok' : 'err');
    if (!ok) log('err', text);
  }

  function stopRun(silent) {
    if (!S.running) return;
    const r = S.running;
    S.running = null;
    try { r.stop(); } catch (_) { /* ignora */ }
    termInputHide();
    updateRunUi();
    if (!silent) { log('info', 'Execução interrompida.'); setRunState('Interrompido', ''); }
  }

  function closeRun() {
    stopRun(true);
    $('#preview').removeAttribute('srcdoc');
    $('#preview').src = 'about:blank';
    showScreen('ide');
  }

  function textFilesOfProject(filter, max) {
    const out = [];
    for (const it of S.tree) {
      if (it.dir || !filter(it.path) || it.size > 1024 * 1024) continue;
      if (out.length >= (max || 200)) break;
      let content = Ed.has(it.path) ? Ed.getText(it.path) : null;
      if (content == null) {
        try { const r = nat('readFile', S.project, it.path); if (r.binary || r.tooLarge) continue; content = r.text; } catch (_) { continue; }
      }
      out.push({ path: it.path, content });
    }
    return out;
  }

  function readTextSafe(path) {
    try { const t = Ed.has(path) ? Ed.getText(path) : null; if (t != null) return t; return nat('readFile', S.project, path).text || ''; } catch (_) { return ''; }
  }

  async function run() {
    if (!S.active) { toast('Abre um ficheiro para executar.', true); return; }
    flushSaves();
    stopRun(true);
    const path = S.active;
    const ext = extOf(path);
    const hasIndex = S.tree.some((i) => i.path === 'index.html');
    const isFlutter = S.tree.some((i) => i.path === 'pubspec.yaml') && /flutter/.test(readTextSafe('pubspec.yaml'));

    if (ext === 'html' || ext === 'htm') return runWeb(path);
    if ((ext === 'css' || ext === 'js' || ext === 'mjs') && hasIndex && !runsAsScript(path, hasIndex)) return runWeb('index.html');
    if (ext === 'js' || ext === 'mjs') return runJs(path);
    if (ext === 'py') return runPython(path);
    if (ext === 'java') return runJava(path);
    if (ext === 'dart') {
      if (isFlutter) {
        openRun({ title: basename(path), sub: 'Flutter', mode: 'term', restart: () => run() });
        log('warn', 'Este é um projeto Flutter. O Flutter SDK não corre no Android.\nExporta o ZIP (menu → Exportar projeto), envia para o GitHub e usa o workflow incluído para gerar o APK.');
        return;
      }
      return runRemote('dart', path);
    }
    openRun({ title: basename(path), sub: 'Sem execução', mode: 'term', restart: () => run() });
    log('warn', 'Não há execução para ficheiros .' + (ext || 'sem extensão') + '.\nSuportado: HTML/CSS/JS, Python, Java e Dart.');
  }

  function runsAsScript(path, hasIndex) {
    if (!hasIndex) return true;
    return !readTextSafe('index.html').includes(basename(path));
  }

  // ----- Web (pré-visualização em ecrã inteiro) -----
  const IMG_MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon' };
  const isExternal = (u) => /^([a-z][a-z0-9+.-]*:|\/\/)/i.test(u) || u.startsWith('#');

  const CAPTURE = '(function(){var p=function(t,a){try{parent.postMessage({cv:1,type:t,text:Array.prototype.map.call(a,function(x){try{return typeof x===\"object\"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(\" \")},\"*\")}catch(e){}};[\"log\",\"info\",\"warn\",\"error\"].forEach(function(k){var o=console[k];console[k]=function(){p(k,arguments);o.apply(console,arguments)}});window.addEventListener(\"error\",function(e){p(\"error\",[e.message+\" (\"+(e.lineno||\"?\")+\":\"+(e.colno||\"?\")+\")\"])});window.addEventListener(\"unhandledrejection\",function(e){p(\"error\",[\"Promessa rejeitada: \"+e.reason])});})();';

  function buildPreviewHtml(htmlPath) {
    const doc = new DOMParser().parseFromString(readTextSafe(htmlPath), 'text/html');
    const baseDir = dirname(htmlPath);
    const resolve = (u) => normalizePath(joinPath(baseDir, u.split('#')[0].split('?')[0]));
    const exists = (p) => S.tree.some((i) => !i.dir && i.path === p);
    const missing = [];

    doc.querySelectorAll('link[rel~="stylesheet"][href]').forEach((l) => {
      const href = l.getAttribute('href');
      if (isExternal(href)) return;
      const p = resolve(href);
      if (!exists(p)) { missing.push(p); return; }
      l.replaceWith(Object.assign(doc.createElement('style'), { textContent: readTextSafe(p) }));
    });
    doc.querySelectorAll('script[src]').forEach((s) => {
      const src = s.getAttribute('src');
      if (isExternal(src)) return;
      const p = resolve(src);
      if (!exists(p)) { missing.push(p); return; }
      const n = doc.createElement('script');
      if (s.getAttribute('type')) n.setAttribute('type', s.getAttribute('type'));
      n.textContent = readTextSafe(p).replace(/<\/script/gi, '<\\/script');
      s.replaceWith(n);
    });
    doc.querySelectorAll('img[src]').forEach((im) => {
      const src = im.getAttribute('src');
      if (isExternal(src)) return;
      const p = resolve(src);
      const mime = IMG_MIME[extOf(p)];
      if (!exists(p) || !mime) return;
      try { im.setAttribute('src', 'data:' + mime + ';base64,' + nat('readBase64', S.project, p).data); } catch (_) { /* ignora */ }
    });

    const cap = doc.createElement('script');
    cap.textContent = CAPTURE;
    doc.head.insertBefore(cap, doc.head.firstChild);
    return { html: '<!DOCTYPE html>\n' + doc.documentElement.outerHTML, missing };
  }

  // Abre a página no navegador do telemóvel (servidor http://localhost dentro da app).
  function openInBrowser(htmlPath) {
    if (!hasNative) { toast('Só disponível dentro da app Android.', true); return; }
    flushSaves();
    try { nat('openInBrowser', S.project, htmlPath); }
    catch (e) { toast(e.message, true); }
  }

  async function runMenu() {
    const desk = settings.previewMode === 'desktop';
    const items = [
      { id: 'reload', label: 'Recarregar página', icon: 'refresh' },
      { id: 'device', label: desk ? 'Modo telemóvel' : 'Modo computador', icon: desk ? 'phone' : 'desktop' },
      { id: 'console', label: 'Consola' + (R.errors ? ' (' + R.errors + (R.errors > 1 ? ' erros' : ' erro') + ')' : ''), icon: 'terminal' },
    ];
    if (hasNative && R.htmlPath) items.push({ id: 'browser', label: 'Abrir no navegador', icon: 'globe' });
    const a = await uiSheet('Pré-visualização', items);
    if (a === 'reload') { if (R.restart) R.restart(); }
    else if (a === 'device') togglePreviewMode();
    else if (a === 'console') { $('#web-console').classList.toggle('hidden'); setBadge(0); }
    else if (a === 'browser') openInBrowser(R.htmlPath);
  }

  function runWeb(htmlPath) {
    if (hasNative && settings.previewTarget === 'browser') { openInBrowser(htmlPath); return; }
    let port = 0;
    if (hasNative) { try { port = nat('previewPort').port; } catch (_) { /* sem servidor */ } }
    const address = 'localhost' + (port ? ':' + port : '') + '/' + htmlPath.split('/').map(encodeURIComponent).join('/');
    openRun({ title: basename(htmlPath), sub: 'Pré-visualização', mode: 'web', address, restart: () => runWeb(htmlPath) });
    R.htmlPath = htmlPath;
    if (hasNative) {
      // Servido pela app como um servidor local: CSS, JS, imagens, fontes, módulos e fetch() funcionam com caminhos relativos.
      flushSaves();
      const base = 'https://preview.' + location.host + '/' + encodeURIComponent(S.project) + '/';
      $('#preview').removeAttribute('srcdoc');
      $('#preview').src = base + htmlPath.split('/').map(encodeURIComponent).join('/') + '?cv=' + Date.now();
      return;
    }
    const { html, missing } = buildPreviewHtml(htmlPath);
    missing.forEach((m) => { log('warn', 'Ficheiro referenciado não encontrado: ' + m); setBadge(R.errors + 1); });
    $('#preview').srcdoc = html;
  }

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || !d.cv || ev.source !== $('#preview').contentWindow) return;
    const kind = d.type === 'error' ? 'err' : d.type === 'warn' ? 'warn' : d.type === 'info' ? 'info' : 'out';
    log(kind, d.text);
    if (d.type === 'error') setBadge(R.errors + 1);
  });

  // ----- JavaScript isolado (Worker) -----
  function runJs(path) {
    openRun({ title: basename(path), sub: 'JavaScript (sem DOM)', mode: 'term', restart: () => runJs(path) });
    const code = Ed.getText(path) || '';
    const src = [
      'const send=(t,a)=>postMessage({t:t,x:Array.prototype.map.call(a,v=>{try{return typeof v===\"object\"?JSON.stringify(v):String(v)}catch(e){return String(v)}}).join(\" \")});',
      '[\"log\",\"info\",\"warn\",\"error\"].forEach(k=>{console[k]=function(){send(k,arguments)}});',
      'self.onerror=(m)=>{send(\"error\",[m]);postMessage({t:\"done\"})};',
      'self.addEventListener(\"unhandledrejection\",e=>send(\"error\",[\"Promessa rejeitada: \"+e.reason]));',
      '(async()=>{',
      code,
      '\n})().then(()=>postMessage({t:\"done\"}),e=>{send(\"error\",[String(e&&e.stack||e)]);postMessage({t:\"done\"})});',
    ].join('\n');
    const url = URL.createObjectURL(new Blob([src], { type: 'application/javascript' }));
    const w = new Worker(url);
    const token = {};
    const finish = (ok, text) => { URL.revokeObjectURL(url); w.terminate(); if (S.running && S.running.token === token) finishRun(ok, text); };
    w.onmessage = (e) => {
      const m = e.data;
      if (m.t === 'done') finish(true, 'Execução terminada.');
      else log(m.t === 'error' ? 'err' : m.t === 'warn' ? 'warn' : m.t === 'info' ? 'info' : 'out', m.x);
    };
    w.onerror = (e) => { log('err', e.message || 'Erro no script'); finish(false, 'Execução terminada com erro.'); };
    setRunning({ token, stop() { URL.revokeObjectURL(url); w.terminate(); } }, '● A executar…');
  }

  // ----- Python (Pyodide, offline) -----
  let pyWorker = null;
  let pyReady = null;
  let pyState = 'none';
  let pyRunDone = null;

  function resetPython() {
    try { if (hasNative) window.Native.pyInputCancel(); } catch (_) { /* ignora */ }
    if (pyWorker) pyWorker.terminate(); pyWorker = null; pyReady = null; pyState = 'none'; pyRunDone = null; }

  function ensurePython() {
    if (pyReady) return pyReady;
    pyState = 'loading';
    pyReady = new Promise((resolve, reject) => {
      let w;
      try { w = new Worker('python-worker.js'); } catch (e) { pyState = 'none'; pyReady = null; reject(e); return; }
      pyWorker = w;
      w.onmessage = (e) => {
        const m = e.data;
        if (m.type === 'ready') { pyState = 'ready'; resolve(); }
        else if (m.type === 'initError') { pyState = 'none'; pyReady = null; reject(new Error(m.message)); }
        else if (m.type === 'out') termWrite('out', m.text + '\n');
        else if (m.type === 'err') termWrite('err', m.text + '\n');
        else if (m.type === 'needInput') {
          if (m.prompt) termWrite('out', m.prompt);
          TI.keep = false;
          termInputShow((t) => window.Native.pyInput(t), true);
        }
        else if (m.type === 'done') { if (pyRunDone) { const f = pyRunDone; pyRunDone = null; f(m.ok); } }
      };
      w.onerror = (e) => { pyState = 'none'; pyReady = null; reject(new Error(e.message || 'Falha ao iniciar o worker Python')); };
      w.postMessage({ type: 'init' });
    });
    return pyReady;
  }

  async function runPython(path) {
    openRun({ title: basename(path), sub: '', mode: 'term', input: true, restart: () => runPython(path) });
    try { window.Native.pyInputReset(); } catch (_) { /* ignora */ }
    const token = { py: true };
    setRunning({ token, stop() { resetPython(); } }, pyState === 'ready' ? '● A executar…' : '● A iniciar o Python…');
    try {
      await ensurePython();
      if (!S.running || S.running.token !== token) return;
      setRunState('● A executar…', '');
      const files = textFilesOfProject((p) => /\.(py|txt|json|csv|md|ya?ml|toml|ini|html|xml)$/i.test(p));
      const ok = await new Promise((resolve) => { pyRunDone = resolve; pyWorker.postMessage({ type: 'run', files, main: path }); });
      if (S.running && S.running.token === token) finishRun(ok, ok ? 'Execução terminada.' : 'Execução terminada com erro.');
    } catch (e) {
      if (S.running && S.running.token === token) { S.running = null; updateRunUi(); setRunState('✗ Falhou', 'err'); }
      log('err', 'Não foi possível iniciar o Python: ' + e.message);
    }
  }

  // ----- Java (offline: compilador ECJ + D8 dentro da app) -----
  let javaSeq = 0;

  function runJava(path) {
    const files = textFilesOfProject((p) => extOf(p) === 'java');
    const hasMain = (c) => /static\s+void\s+main\s*\(/.test(c);
    const main = files.find((f) => f.path === path && hasMain(f.content)) || files.find((f) => hasMain(f.content));
    openRun({ title: basename(main ? main.path : path), sub: '', mode: 'term', input: true, restart: () => runJava(path) });
    if (!files.length) { log('err', 'Nenhum ficheiro .java encontrado.'); return; }
    if (!main) { log('err', 'Não encontrei nenhuma classe com "public static void main(String[] args)".'); return; }
    const id = 'j' + (++javaSeq) + '_' + Date.now();
    const token = { id };
    setRunning({ token, stop() { try { window.Native.javaStop(id); } catch (_) { /* ignora */ } } }, '● A compilar…');
    nativeListeners.java = (m) => {
      if (m.id !== id || !S.running || S.running.token !== token) return;
      if (m.kind === 'phase') {
        setRunState('● ' + m.text, '');
        if (/execu|run/i.test(m.text) && !TI.active) { TI.keep = true; termInputShow((t) => window.Native.javaInput(id, t + '\n'), true); }
      }
      else if (m.kind === 'out') {
        termWrite('out', m.text);
        if (!TI.active) { TI.keep = true; termInputShow((t) => window.Native.javaInput(id, t + '\n'), true); }
      }
      else if (m.kind === 'err') termWrite('err', m.text);
      else if (m.kind === 'done') {
        if (m.code === 0) finishRun(true, 'Programa terminado (código 0).');
        else if (m.compile) finishRun(false, 'Erro de compilação.');
        else finishRun(false, m.text || ('Programa terminado (código ' + m.code + ').'));
      }
    };
    try { nat('javaRun', id, S.project, main.path, settings.javaLevel); }
    catch (e) { S.running = null; updateRunUi(); log('err', e.message); setRunState('✗ Falhou', 'err'); }
  }

  // ----- Dart (serviço online compatível com Piston) -----
  async function runRemote(lang, path) {
    openRun({ title: basename(path), sub: 'Dart (online)', mode: 'term', restart: () => runRemote(lang, path) });
    if (!navigator.onLine) { log('warn', 'Sem ligação à internet. O Dart só executa online (não há compilador Dart local no Android).'); return; }
    let files = textFilesOfProject((p) => extOf(p) === 'dart');
    if (!files.length) { log('err', 'Nenhum ficheiro .dart encontrado.'); return; }
    const hasMain = (c) => /\bmain\s*\(/.test(c);
    const main = files.find((f) => f.path === path && hasMain(f.content)) || files.find((f) => hasMain(f.content));
    if (!main) { log('err', 'Não encontrei a função main().'); return; }
    files = [main].concat(files.filter((f) => f !== main));
    const payload = {
      language: lang, version: '*',
      files: files.map((f) => ({ name: basename(f.path), content: f.content })),
      stdin: '', compile_timeout: 15000, run_timeout: 10000,
    };
    const url = settings.runnerUrl.replace(/\/+$/, '') + '/execute';
    let req;
    try { req = httpPost(url, payload, settings.runTimeout); } catch (e) { log('err', e.message); return; }
    const token = {};
    setRunning({ token, stop() { httpCancel(req.id); } }, '● A executar (online)…');
    try {
      const res = await req.promise;
      if (!S.running || S.running.token !== token) return;
      let data = null;
      try { data = JSON.parse(res.body); } catch (_) { /* resposta não-JSON */ }
      if (res.status < 200 || res.status >= 300 || !data) {
        log('err', 'O serviço respondeu com erro (HTTP ' + res.status + '):\n' + (data && data.message ? data.message : res.body.slice(0, 400)));
        finishRun(false, 'Falha no serviço online.');
        return;
      }
      if (data.compile) {
        if (data.compile.stdout) termWrite('out', data.compile.stdout);
        if (data.compile.stderr) termWrite('err', data.compile.stderr);
        if (data.compile.code !== 0 && data.compile.code != null) { finishRun(false, 'A compilação falhou.'); return; }
      }
      const r = data.run || {};
      if (r.stdout) termWrite('out', r.stdout);
      if (r.stderr) termWrite('err', r.stderr);
      finishRun(r.code === 0, 'Processo terminou com código ' + (r.code == null ? '?' : r.code) + '.');
    } catch (e) {
      if (S.running && S.running.token === token) { log('err', 'Falha de rede: ' + e.message); finishRun(false, 'Falha de rede.'); }
    }
  }

  // ===================== Menu =====================
  async function ideMenu() {
    const a = await uiSheet(S.project, [
      { id: 'find', label: 'Procurar / substituir', icon: 'search' },
      { id: 'undo', label: 'Desfazer', icon: 'undo' },
      { id: 'redo', label: 'Refazer', icon: 'redo' },
      { id: 'export', label: 'Exportar projeto (ZIP)', icon: 'export' },
      { id: 'refresh', label: 'Atualizar lista de ficheiros', icon: 'refresh' },
      ...(S.link && S.link.linked ? [{ id: 'sync', label: 'Atualizar do armazenamento', icon: 'refresh' }, { id: 'unlink', label: 'Desligar do armazenamento', icon: 'close' }] : []),
      { id: 'settings', label: 'Definições', icon: 'settings' },
      { id: 'close', label: 'Fechar projeto', icon: 'close' },
    ]);
    if (a === 'find') Ed.find();
    else if (a === 'undo') Ed.undo();
    else if (a === 'redo') Ed.redo();
    else if (a === 'export') { flushSaves(); exportProject(S.project); }
    else if (a === 'refresh') refreshTree();
    else if (a === 'sync') refreshFromStorage(S.project);
    else if (a === 'unlink') unlinkStorage(S.project);
    else if (a === 'settings') openSettings();
    else if (a === 'close') closeProject();
  }

  // ===================== Botão Voltar do Android =====================
  window.CV_onBack = function () {
    if (modals.length) { modals[modals.length - 1].close(); return true; }
    if (S.screen === 'update') { closeUpdate(); return true; }
    if (S.screen === 'settings') { closeSettings(); return true; }
    if (S.screen === 'run') {
      if (!$('#web-console').classList.contains('hidden')) { $('#web-console').classList.add('hidden'); return true; }
      closeRun(); return true;
    }
    if (S.explorerOpen) { toggleExplorer(false); return true; }
    if (S.project && S.screen === 'ide') { closeProject(); return true; }
    return false;
  };
  window.CV_onPause = function () { flushSaves(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSaves(); });

  // ===================== Arranque =====================
  function bind() {
    $('#btn-new').addEventListener('click', newProjectDialog);
    $('#btn-import').addEventListener('click', importZip);
    $('#btn-open-folder').addEventListener('click', pickFolder);
    $('#btn-open-files').addEventListener('click', pickFiles);
    $('#btn-save').addEventListener('click', saveAll);
    $('#rail-ext').addEventListener('click', () => setSideView('ext'));
    $('#rail-git').addEventListener('click', () => setSideView('git'));
    $('#btn-clone').addEventListener('click', () => { if (window.CVGit) window.CVGit.cloneDialog(); });
    $('#ext-filter').addEventListener('input', (e) => { X.filter = e.target.value; renderExt(); });
    $('#ext-filter-btn').addEventListener('click', extFilterMenu);
    $('#ext-plus-btn').addEventListener('click', extPlusMenu);
    $('#btn-settings-home').addEventListener('click', openSettings);
    $('#btn-explorer').addEventListener('click', () => toggleExplorer(!S.explorerOpen));
    $('#scrim').addEventListener('click', () => toggleExplorer(false));
    $('#btn-run').addEventListener('click', run);
    $('#btn-menu').addEventListener('click', ideMenu);
    bindProjectRow();
    $('#ex-newfile').addEventListener('click', () => { toggleTree(true); newEntry(false); });
    $('#ex-newdir').addEventListener('click', () => { toggleTree(true); newEntry(true); });
    $('#ex-refresh').addEventListener('click', refreshTree);
    $('#rail-explorer').addEventListener('click', () => setSideView('explorer'));
    $('#rail-search').addEventListener('click', () => setSideView('search'));
    $('#rail-settings').addEventListener('click', openSettings);
    $('#search-form').addEventListener('submit', (e) => { e.preventDefault(); searchAll($('#search-input').value); });

    $('#run-back').addEventListener('click', closeRun);
    $('#run-stop').addEventListener('click', () => stopRun(false));
    $('#run-restart').addEventListener('click', () => { if (R.restart) R.restart(); });
    $('#run-clear').addEventListener('click', clearLog);
    $('#run-menu').addEventListener('click', runMenu);
    $('#wc-close').addEventListener('click', () => $('#web-console').classList.add('hidden'));
    $('#wc-clear').addEventListener('click', () => { $('#wc-body').textContent = ''; R.count = 0; R.open = false; setBadge(0); });
    // tocar no terminal foca a entrada do programa (se existir)
    $('#term').addEventListener('click', () => { if (TI.input && TI.wrap && TI.wrap.parentNode) TI.input.focus(); });

    $('#set-back').addEventListener('click', closeSettings);
    $('#upd-back').addEventListener('click', closeUpdate);
    $('#set-filter').addEventListener('input', (e) => renderSettings(e.target.value));
  }

  function start() {
    I.hydrate(document);
    initEditor();
    if (window.CVPlugins) {
      window.CVPlugins.init({ httpGet: hasNative ? httpGetUrl : null });
      window.CVPlugins.onChange(() => { if (S.sideView === 'ext') renderExt(); });
    }
    if (window.CVGit) {
      window.CVGit.init({
        $, el, icon, fileIcon, I, S, nat, listeners: nativeListeners, toast, openModal, uiPrompt, uiConfirm, uiSheet,
        basename, dirname, relTime, flushSaves, renderTree, reloadFromDisk, openProject, openFile,
        closeExplorer: () => toggleExplorer(false),
      });
    }
    nativeListeners.pick = (m) => {
      if (!m.ok) { if (!m.cancelled) toast('Falha ao abrir: ' + (m.error || 'erro desconhecido'), true); return; }
      if (m.kind === 'folder') { toast('Pasta aberta: ' + m.project); openProject(m.project); }
      else openProject(m.project, m.path);
    };
    nativeListeners.download = (m) => {
      if (m.kind === 'needperm') {
        updView({ icon: 'download', title: 'Permitir instalação', text: 'Ativa “Permitir desta fonte” para o CodeVerse, volta atrás e toca em Instalar.',
          btn: { label: 'Instalar', fn: installUpdate } });
        return;
      }
      if (m.id && m.id !== U.dlId) return;
      if (m.kind === 'progress') {
        const pct = m.total > 0 ? Math.min(100, Math.round(m.done * 100 / m.total)) : -1;
        updView({ icon: 'download', title: 'A baixar a versão ' + (U.info ? U.info.version : ''),
          text: (pct >= 0 ? pct + '% · ' + mb(m.done) + ' de ' + mb(m.total) : mb(m.done)), progress: pct });
      } else if (m.kind === 'done') {
        U.dlId = null;
        updView({ icon: 'check', cls: 'ok', title: 'Download concluído', text: 'Toca em Instalar para atualizar o CodeVerse.',
          btn: { label: 'Instalar', fn: installUpdate } });
        installUpdate();
      } else if (m.kind === 'error') {
        if (!m.id) { toast(m.error || 'Erro', true); return; }
        U.dlId = null;
        updView({ icon: 'close', cls: 'err', title: 'Falha ao baixar', text: m.error || 'Erro de rede.',
          btn: { label: 'Tentar de novo', fn: startDownload } });
      }
    };
    nativeListeners.sync = (m) => {
      if (!m.ok) toast('Não foi possível guardar no armazenamento' + (m.path ? ' (' + basename(m.path) + ')' : '') + ': ' + (m.error || ''), true);
    };
    applySettings();
    setTimeout(autoCheckUpdate, 4000);
    buildKeybar();
    bind();
    if (!hasNative) {
      $('#home-empty').classList.remove('hidden');
      $('#home-empty').textContent = 'Esta interface precisa da app Android CodeVerse para guardar ficheiros.';
      showScreen('home');
      return;
    }
    loadHome();
  }

  start();
})();
