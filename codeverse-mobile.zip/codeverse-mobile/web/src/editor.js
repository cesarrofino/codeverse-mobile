// Editor de código: CodeMirror 6 + tema inspirado no "Dark+" do VS Code.
// Exposto como window.CVEditor (usado por app.js).
import { EditorState, Compartment, RangeSetBuilder, StateField } from '@codemirror/state';
import { EditorView, keymap, Decoration, ViewPlugin, GutterMarker, lineNumberMarkers } from '@codemirror/view';
import { autocompletion, snippetCompletion } from '@codemirror/autocomplete';
import { basicSetup } from 'codemirror';
import { indentWithTab, insertTab, undo, redo, selectAll } from '@codemirror/commands';
import { indentUnit, StreamLanguage, HighlightStyle, syntaxHighlighting, syntaxTree, ensureSyntaxTree } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { tags as t } from '@lezer/highlight';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { javascript } from '@codemirror/lang-javascript';
import { json } from '@codemirror/lang-json';
import { python } from '@codemirror/lang-python';
import { java } from '@codemirror/lang-java';
import { markdown } from '@codemirror/lang-markdown';
import { dart } from '@codemirror/legacy-modes/mode/clike';
import { cpp } from '@codemirror/lang-cpp';
import { go } from '@codemirror/lang-go';
import { rust } from '@codemirror/lang-rust';
import { php } from '@codemirror/lang-php';
import { sql } from '@codemirror/lang-sql';
import { yaml } from '@codemirror/lang-yaml';
// Modos antigos (StreamLanguage). Importados como namespace: se um nome faltar, a linguagem cai para texto simples.
import * as LMclike from '@codemirror/legacy-modes/mode/clike';
import * as LMshell from '@codemirror/legacy-modes/mode/shell';
import * as LMtoml from '@codemirror/legacy-modes/mode/toml';
import * as LMruby from '@codemirror/legacy-modes/mode/ruby';
import * as LMlua from '@codemirror/legacy-modes/mode/lua';
import * as LMswift from '@codemirror/legacy-modes/mode/swift';
import * as LMdocker from '@codemirror/legacy-modes/mode/dockerfile';
import * as LMps from '@codemirror/legacy-modes/mode/powershell';
const legacy = (mode) => () => (mode ? StreamLanguage.define(mode) : []);

// ---------- Temas ----------
// Paleta "Dark+" do VS Code (a predefinida). Os plugins de tema trazem outra paleta com as mesmas chaves.
const DARK_PLUS = {
  id: 'dark-plus', name: 'Dark+ (VS Code)', dark: true,
  colors: {
    bg: '#0f141d', fg: '#d4d4d4', sel: '#1f3a5f', line: '#1d2532', gutter: '#5c6a80', caret: '#aeafad',
    keyword: '#569cd6', control: '#c586c0', string: '#ce9178', comment: '#6a9955',
    number: '#b5cea8', func: '#dcdcaa', type: '#4ec9b0', variable: '#9cdcfe',
    constant: '#4fc1ff', regexp: '#d16969', escape: '#d7ba7d', invalid: '#f44747',
    tag: '#569cd6', bracket: '#808080', link: '#3794ff', cssClass: '#d7ba7d',
  },
};

function makeTheme(p) {
  const C = Object.assign({}, DARK_PLUS.colors, p.colors || {});
  const dark = p.dark !== false;
  const base = EditorView.theme(
    {
      '&': { color: C.fg, backgroundColor: C.bg, height: '100%' },
      '.cm-content': { caretColor: C.caret },
      '.cm-cursor, .cm-dropCursor': { borderLeftColor: C.caret },
      '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection': {
        backgroundColor: C.sel,
      },
      '.cm-activeLine': { backgroundColor: C.line },
      '.cm-gutters': { backgroundColor: C.bg, color: C.gutter, border: 'none' },
      '.cm-activeLineGutter': { backgroundColor: 'transparent', color: C.fg },
      '.cm-selectionMatch': { backgroundColor: '#add6ff26' },
      '&.cm-focused .cm-matchingBracket': { backgroundColor: '#0064001a', outline: '1px solid #888888' },
      '&.cm-focused .cm-nonmatchingBracket': { backgroundColor: '#f4474733' },
      '.cm-searchMatch': { backgroundColor: '#515c6a', outline: '1px solid #74879f' },
      '.cm-searchMatch.cm-searchMatch-selected': { backgroundColor: '#613214' },
      '.cm-panels': { backgroundColor: dark ? '#252526' : '#f3f3f3', color: dark ? '#cccccc' : '#333333' },
      '.cm-panels.cm-panels-top': { borderBottom: '1px solid ' + (dark ? '#3c3c3c' : '#cccccc') },
      '.cm-tooltip': { backgroundColor: dark ? '#252526' : '#f3f3f3', border: '1px solid ' + (dark ? '#454545' : '#c8c8c8'), color: dark ? '#cccccc' : '#333333' },
      '.cm-tooltip-autocomplete > ul > li[aria-selected]': { backgroundColor: dark ? '#04395e' : '#0060c0', color: '#ffffff' },
      '.cm-foldPlaceholder': { backgroundColor: dark ? '#3a3d41' : '#e4e6f1', border: 'none', color: dark ? '#cccccc' : '#333333' },
      // classes acrescentadas pelo plugin de realce extra (ver typeDecorations)
      '.cm-cv-type, .cm-cv-type *': { color: C.type + ' !important' },
      '.cm-cv-const, .cm-cv-const *': { color: C.constant + ' !important' },
      '.cm-cv-self, .cm-cv-self *': { color: C.keyword + ' !important' },
    },
    { dark }
  );
  const hl = HighlightStyle.define([
    { tag: [t.keyword, t.operatorKeyword, t.definitionKeyword, t.modifier, t.self, t.null, t.bool, t.atom], color: C.keyword },
    { tag: [t.controlKeyword, t.moduleKeyword], color: C.control },
    { tag: [t.string, t.special(t.string), t.attributeValue], color: C.string },
    { tag: t.regexp, color: C.regexp },
    { tag: t.escape, color: C.escape },
    { tag: [t.number, t.unit], color: C.number },
    { tag: [t.comment, t.lineComment, t.blockComment, t.docComment], color: C.comment },
    { tag: [t.variableName, t.propertyName, t.attributeName, t.labelName], color: C.variable },
    { tag: [t.function(t.variableName), t.function(t.propertyName)], color: C.func },
    { tag: [t.function(t.definition(t.variableName)), t.function(t.definition(t.propertyName))], color: C.func },
    { tag: [t.className, t.typeName, t.namespace], color: C.type },
    { tag: [t.constant(t.variableName), t.standard(t.variableName)], color: C.constant },
    { tag: t.definition(t.variableName), color: C.variable },
    { tag: t.tagName, color: C.tag },
    { tag: t.angleBracket, color: C.bracket },
    { tag: [t.meta, t.annotation], color: C.func },
    { tag: [t.operator, t.punctuation, t.bracket, t.separator], color: C.fg },
    { tag: t.heading, color: C.keyword, fontWeight: 'bold' },
    { tag: t.link, color: C.link, textDecoration: 'underline' },
    { tag: t.emphasis, fontStyle: 'italic' },
    { tag: t.strong, fontWeight: 'bold' },
    { tag: [t.processingInstruction, t.documentMeta], color: C.keyword },
    { tag: t.invalid, color: C.invalid },
  ]);
  // Sem 'fallback': assim o estilo do tema tem prioridade sobre o estilo claro predefinido do basicSetup.
  return [base, syntaxHighlighting(hl)];
}

// Realce extra que o VS Code (Pylance / TextMate) faz e o analisador do CodeMirror não distingue:
// classes e exceções (ValueError, Exception…) e tipos nativos (int, float, str…) a verde-azulado,
// CONSTANTES a azul-claro e self/cls a azul.
const PY_BUILTIN_TYPES = new Set(['int', 'float', 'str', 'bool', 'list', 'dict', 'set', 'tuple', 'frozenset', 'bytes', 'bytearray', 'object', 'type', 'range', 'complex', 'slice', 'memoryview', 'property', 'staticmethod', 'classmethod', 'super']);
function classify(name, lang) {
  if (lang === 'python') {
    if (name === 'self' || name === 'cls') return 'cm-cv-self';
    if (PY_BUILTIN_TYPES.has(name)) return 'cm-cv-type';
  }
  if (/^_*[A-Z][A-Z0-9_]+$/.test(name) && name.length > 1) return 'cm-cv-const';
  if (/^_*[A-Z][A-Za-z0-9]*[a-z][A-Za-z0-9]*$/.test(name)) return 'cm-cv-type';
  return null;
}
const DECO_NODES = new Set(['VariableName', 'VariableDefinition']);
function typeDecorations(lang) {
  const marks = {};
  const mark = (c) => marks[c] || (marks[c] = Decoration.mark({ class: c }));
  function build(view) {
    const b = new RangeSetBuilder();
    const tree = syntaxTree(view.state);
    for (const { from, to } of view.visibleRanges) {
      tree.iterate({
        from, to,
        enter(node) {
          if (!DECO_NODES.has(node.name)) return;
          const c = classify(view.state.doc.sliceString(node.from, node.to), lang);
          if (c) b.add(node.from, node.to, mark(c));
        },
      });
    }
    return b.finish();
  }
  return ViewPlugin.fromClass(class {
    constructor(view) { this.decorations = build(view); }
    update(u) { if (u.docChanged || u.viewportChanged || syntaxTree(u.startState) !== syntaxTree(u.state)) this.decorations = build(u.view); }
  }, { decorations: (v) => v.decorations });
}

const themeCompartment = new Compartment();
let currentTheme = makeTheme(DARK_PLUS);
let currentThemeMeta = DARK_PLUS;

// ---------- Snippets (autocompletar) ----------
// Mapa linguagem -> lista de { prefix, name, body }. Preenchido pelos snippets básicos e pelos plugins.
let snippetMap = {};
const snippetCompartment = new Compartment();

// Sintaxe VS Code ($1, ${1:texto}, $0) -> sintaxe do CodeMirror (${1}, ${1:texto}, ${})
function toCmSnippet(body) {
  return String(body)
    .replace(/\$\{(\d+):([^}]*)\}/g, '${$1:$2}')
    .replace(/\$0/g, '${}')
    .replace(/\$(\d+)/g, '${$1}');
}

function snippetExtension(id) {
  const source = (ctx) => {
    const word = ctx.matchBefore(/[\w!.\-]+/);
    if (!word || (word.from === word.to && !ctx.explicit)) return null;
    const list = [].concat(snippetMap[id] || [], snippetMap.all || []);
    if (!list.length) return null;
    return {
      from: word.from,
      options: list.map((s) => snippetCompletion(toCmSnippet(s.body), { label: s.prefix, detail: s.name || 'snippet', type: 'snippet', boost: 50 })),
      validFor: /^[\w!.\-]*$/,
    };
  };
  return EditorState.languageData.of(() => [{ autocomplete: source }]);
}

// ---------- Linguagens ----------
const LANGS = {
  html: { ext: () => html(), indent: 2 },
  css: { ext: () => css(), indent: 2 },
  javascript: { ext: () => javascript({ jsx: true }), indent: 2 },
  typescript: { ext: () => javascript({ jsx: true, typescript: true }), indent: 2 },
  json: { ext: () => json(), indent: 2 },
  python: { ext: () => python(), indent: 4 },
  java: { ext: () => java(), indent: 4 },
  dart: { ext: () => StreamLanguage.define(dart), indent: 2 },
  markdown: { ext: () => markdown(), indent: 2 },
  c: { ext: () => cpp(), indent: 4, quiet: true },
  cpp: { ext: () => cpp(), indent: 4, quiet: true },
  csharp: { ext: legacy(LMclike.csharp), indent: 4 },
  kotlin: { ext: legacy(LMclike.kotlin), indent: 4 },
  scala: { ext: legacy(LMclike.scala), indent: 2 },
  go: { ext: () => go(), indent: 4 },
  rust: { ext: () => rust(), indent: 4 },
  php: { ext: () => php(), indent: 4, quiet: true },
  sql: { ext: () => sql(), indent: 2, quiet: true },
  yaml: { ext: () => yaml(), indent: 2 },
  shell: { ext: legacy(LMshell.shell), indent: 2 },
  toml: { ext: legacy(LMtoml.toml), indent: 2 },
  ruby: { ext: legacy(LMruby.ruby), indent: 2 },
  lua: { ext: legacy(LMlua.lua), indent: 2 },
  swift: { ext: legacy(LMswift.swift), indent: 4 },
  dockerfile: { ext: legacy(LMdocker.dockerFile), indent: 2 },
  powershell: { ext: legacy(LMps.powerShell), indent: 4 },
  text: { ext: () => [], indent: 2 },
};

const EXT_TO_LANG = {
  html: 'html', htm: 'html', xml: 'html', svg: 'html',
  css: 'css',
  js: 'javascript', mjs: 'javascript', cjs: 'javascript', jsx: 'javascript',
  ts: 'typescript', tsx: 'typescript',
  json: 'json',
  py: 'python',
  java: 'java',
  dart: 'dart',
  md: 'markdown', markdown: 'markdown',
  c: 'c', h: 'c',
  cpp: 'cpp', cc: 'cpp', cxx: 'cpp', hpp: 'cpp', hh: 'cpp', hxx: 'cpp',
  cs: 'csharp', kt: 'kotlin', kts: 'kotlin', scala: 'scala',
  go: 'go', rs: 'rust', php: 'php', sql: 'sql',
  yml: 'yaml', yaml: 'yaml', toml: 'toml',
  sh: 'shell', bash: 'shell', zsh: 'shell',
  rb: 'ruby', lua: 'lua', swift: 'swift', ps1: 'powershell',
  dockerfile: 'dockerfile',
};

function langIdFor(path) {
  if (/(^|\/)Dockerfile(\.[\w.-]+)?$/i.test(path || '')) return 'dockerfile';
  const m = /\.([A-Za-z0-9]+)$/.exec(path || '');
  return (m && EXT_TO_LANG[m[1].toLowerCase()]) || 'text';
}

// ---------- Estado ----------
// ---------- Erros de sintaxe: um "x" vermelho no lugar do número da linha ----------
class ErrorMark extends GutterMarker {
  toDOM() {
    const w = document.createElement('span');
    w.className = 'cv-errx';
    w.title = 'Erro de sintaxe nesta linha';
    w.innerHTML = '<svg viewBox="0 0 10 10" width="0.72em" height="0.72em" aria-hidden="true"><path d="M1.5 1.5l7 7M8.5 1.5l-7 7" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" fill="none"/></svg>';
    return w;
  }
}
const errorMark = new ErrorMark();
// Nós do analisador que indicam erro (além dos nós de erro genéricos "⚠"). O HTML marca tags por fechar/trocadas com nós próprios.
const ERROR_NODE_NAMES = new Set(['MismatchedCloseTag', 'MissingCloseTag', 'IncompleteCloseTag', 'IncompleteStartCloseTag']);
const errLine = Decoration.line({ class: 'cv-errline' });
const errWave = Decoration.mark({ class: 'cv-errwave' });

function computeErrors(state) {
  const gutter = new RangeSetBuilder();
  const ranges = [];
  const lines = new Set();
  try {
    const doc = state.doc;
    const tree = ensureSyntaxTree(state, doc.length, 100) || syntaxTree(state);
    let count = 0;
    tree.iterate({
      enter(n) {
        if (count > 200) return false;
        if (!(n.type.isError || ERROR_NODE_NAMES.has(n.name))) return;
        count++;
        const from = Math.min(n.from, doc.length);
        const line = doc.lineAt(from);
        lines.add(line.number);
        let a = from, b = Math.min(n.to, line.to);
        if (b <= a) { b = Math.min(line.to, a + 1); if (b <= a) { a = Math.max(line.from, a - 1); b = line.to; } }
        if (b > a) ranges.push(errWave.range(a, b));
      },
    });
    for (const ln of [...lines].sort((x, y) => x - y)) {
      const l = doc.line(ln);
      gutter.add(l.from, l.from, errorMark);
      ranges.push(errLine.range(l.from));
    }
  } catch (_) { /* sem árvore: sem marcas */ }
  return { gutter: gutter.finish(), deco: Decoration.set(ranges, true) };
}
const errorField = StateField.define({
  create: (state) => computeErrors(state),
  update(value, tr) {
    if (tr.docChanged || syntaxTree(tr.state) !== syntaxTree(tr.startState)) return computeErrors(tr.state);
    return value;
  },
  provide: (f) => [
    lineNumberMarkers.from(f, (v) => v.gutter),
    EditorView.decorations.from(f, (v) => v.deco),
  ],
});
const errCompartment = new Compartment();
let errorsOn = true;
// Linguagens com 'quiet' (SQL, PHP, C/C++) não mostram o x vermelho: dialetos e macros dariam falsos erros.
const errExt = (id) => (errorsOn && !(LANGS[id] || {}).quiet ? errorField : []);
const closeCompartment = new Compartment();
let autoCloseOn = true;
const noAutoClose = () => EditorState.languageData.of(() => [{ closeBrackets: { brackets: [] } }]);

const wrapCompartment = new Compartment();
const tabCompartment = new Compartment();
let tabOverride = 0; // 0 = automático (por linguagem)
const tabExt = (id) => {
  const n = tabOverride || (LANGS[id] || LANGS.text).indent;
  return [indentUnit.of(' '.repeat(n)), EditorState.tabSize.of(n)];
};
const states = new Map(); // path -> EditorState (mantém histórico de desfazer por ficheiro)
let view = null;
let current = null;
let wrapOn = false;
let callbacks = { change() {}, cursor() {} };

function makeState(path, text) {
  const id = langIdFor(path);
  const lang = LANGS[id] || LANGS.text;
  return EditorState.create({
    doc: text,
    extensions: [
      closeCompartment.of(autoCloseOn ? [] : noAutoClose()),
      basicSetup,
      keymap.of([indentWithTab]),
      themeCompartment.of(currentTheme),
      lang.ext(),
      (id === 'python' || id === 'javascript' || id === 'typescript') ? typeDecorations(id) : [],
      snippetCompartment.of(snippetExtension(id)),
      tabCompartment.of(tabExt(id)),
      wrapCompartment.of(wrapOn ? EditorView.lineWrapping : []),
      errCompartment.of(errExt(id)),
      // Evita que o teclado do Android corrija/capitalize o código
      EditorView.contentAttributes.of({
        autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', autocomplete: 'off',
      }),
      EditorView.updateListener.of((u) => {
        if (!current) return;
        if (u.docChanged) callbacks.change(current);
        if (u.selectionSet || u.docChanged) {
          const head = u.state.selection.main.head;
          const line = u.state.doc.lineAt(head);
          callbacks.cursor(line.number, head - line.from + 1);
        }
      }),
    ],
  });
}

window.CVEditor = {
  available: true,

  init(parent, cb) {
    callbacks = Object.assign(callbacks, cb || {});
    view = new EditorView({ parent, state: EditorState.create({ doc: '', extensions: [themeCompartment.of(currentTheme)] }) });
  },

  open(path, text, cursor) {
    if (current && view) states.set(current, view.state);
    let st = states.get(path);
    if (!st) {
      st = makeState(path, text);
      states.set(path, st);
    }
    current = path;
    view.setState(st);
    view.dispatch({ effects: [
      wrapCompartment.reconfigure(wrapOn ? EditorView.lineWrapping : []),
      tabCompartment.reconfigure(tabExt(langIdFor(path))),
      themeCompartment.reconfigure(currentTheme),
      snippetCompartment.reconfigure(snippetExtension(langIdFor(path))),
      errCompartment.reconfigure(errExt(langIdFor(path))),
      closeCompartment.reconfigure(autoCloseOn ? [] : noAutoClose()),
    ] });
    if (typeof cursor === 'number' && cursor >= 0) {
      const pos = Math.min(cursor, view.state.doc.length);
      view.dispatch({ selection: { anchor: pos }, scrollIntoView: true });
    }
    const head = view.state.selection.main.head;
    const line = view.state.doc.lineAt(head);
    callbacks.cursor(line.number, head - line.from + 1);
  },

  getText(path) {
    if (path === current && view) return view.state.doc.toString();
    const st = states.get(path);
    return st ? st.doc.toString() : null;
  },

  has(path) { return states.has(path); },

  close(path) {
    states.delete(path);
    if (current === path) current = null;
  },

  rename(from, to) {
    // ao renomear mudamos de chave; o realce é recriado na próxima abertura (a extensão pode ter mudado)
    const text = this.getText(from);
    states.delete(from);
    if (current === from) current = null;
    return text;
  },

  clearAll() { states.clear(); current = null; },

  languageOf(path) { return langIdFor(path); },

  focus() { if (view) view.focus(); },

  find() { if (view) { openSearchPanel(view); } },
  undo() { if (view) { undo(view); } },
  redo() { if (view) { redo(view); } },
  selectAll() { if (view) { selectAll(view); } },
  tab() { if (view) { insertTab(view); view.focus(); } },

  insert(text) {
    if (!view) return;
    const r = view.state.selection.main;
    view.dispatch({
      changes: { from: r.from, to: r.to, insert: text },
      selection: { anchor: r.from + text.length },
      scrollIntoView: true,
    });
    view.focus();
  },

  getSelection() {
    if (!view) return { text: '', from: 0, to: 0 };
    const r = view.state.selection.main;
    return { text: view.state.sliceDoc(r.from, r.to), from: r.from, to: r.to };
  },

  replaceRange(from, to, text) {
    if (!view) return;
    const len = view.state.doc.length;
    const a = Math.max(0, Math.min(from, len)), b = Math.max(a, Math.min(to, len));
    view.dispatch({ changes: { from: a, to: b, insert: text }, selection: { anchor: a + text.length }, scrollIntoView: true });
    view.focus();
  },

  replaceAll(text) {
    if (!view) return;
    view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: text }, selection: { anchor: 0 }, scrollIntoView: true });
    view.focus();
  },

  moveCursor(delta) {
    if (!view) return;
    const pos = Math.max(0, Math.min(view.state.doc.length, view.state.selection.main.head + delta));
    view.dispatch({ selection: { anchor: pos }, scrollIntoView: true });
    view.focus();
  },

  goto(line, col) {
    if (!view) return;
    const ln = Math.max(1, Math.min(view.state.doc.lines, line | 0));
    const l = view.state.doc.line(ln);
    const pos = Math.min(l.to, l.from + Math.max(0, (col || 1) - 1));
    view.dispatch({ selection: { anchor: pos }, scrollIntoView: true });
    view.focus();
  },

  setTabSize(n) {
    tabOverride = n | 0;
    if (view && current) view.dispatch({ effects: tabCompartment.reconfigure(tabExt(langIdFor(current))) });
  },

  setTheme(p) {
    currentThemeMeta = p || DARK_PLUS;
    currentTheme = makeTheme(currentThemeMeta);
    if (view) view.dispatch({ effects: themeCompartment.reconfigure(currentTheme) });
  },

  themeMeta() { return currentThemeMeta; },

  setSnippets(map) {
    snippetMap = map || {};
    if (view && current) view.dispatch({ effects: snippetCompartment.reconfigure(snippetExtension(langIdFor(current))) });
  },

  tabSizeOf(path) { return tabOverride || (LANGS[langIdFor(path)] || LANGS.text).indent; },

  setErrors(on) {
    errorsOn = !!on;
    if (view && current) view.dispatch({ effects: errCompartment.reconfigure(errExt(langIdFor(current))) });
  },

  setAutoClose(on) {
    autoCloseOn = !!on;
    if (view && current) view.dispatch({ effects: closeCompartment.reconfigure(autoCloseOn ? [] : noAutoClose()) });
  },

  setWrap(on) {
    wrapOn = !!on;
    if (view) view.dispatch({ effects: wrapCompartment.reconfigure(wrapOn ? EditorView.lineWrapping : []) });
  },
};
