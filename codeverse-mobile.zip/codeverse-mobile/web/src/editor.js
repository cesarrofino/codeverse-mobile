// Editor de código: CodeMirror 6 + tema inspirado no "Dark+" do VS Code.
// Exposto como window.CVEditor (usado por app.js).
import { EditorState, Compartment } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { basicSetup } from 'codemirror';
import { indentWithTab, insertTab, undo, redo, selectAll } from '@codemirror/commands';
import { indentUnit, StreamLanguage, HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { tags as t } from '@lezer/highlight';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { javascript } from '@codemirror/lang-javascript';
import { json } from '@codemirror/lang-json';
import { python } from '@codemirror/lang-python';
import { java } from '@codemirror/lang-java';
import { markdown } from '@codemirror/lang-markdown';
import { dart } from '@codemirror/legacy-modes/mode/clike';

// ---------- Tema Dark+ ----------
const C = {
  bg: '#1e1e1e', fg: '#d4d4d4', sel: '#264f78', line: '#2a2d2e', gutter: '#858585',
  keyword: '#569cd6', control: '#c586c0', string: '#ce9178', comment: '#6a9955',
  number: '#b5cea8', func: '#dcdcaa', type: '#4ec9b0', variable: '#9cdcfe',
  constant: '#4fc1ff', regexp: '#d16969', escape: '#d7ba7d', invalid: '#f44747',
};

const darkTheme = EditorView.theme(
  {
    '&': { color: C.fg, backgroundColor: C.bg, height: '100%' },
    '.cm-content': { caretColor: '#aeafad' },
    '.cm-cursor, .cm-dropCursor': { borderLeftColor: '#aeafad' },
    '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection': {
      backgroundColor: C.sel,
    },
    '.cm-activeLine': { backgroundColor: '#ffffff0b' },
    '.cm-gutters': { backgroundColor: C.bg, color: C.gutter, border: 'none' },
    '.cm-activeLineGutter': { backgroundColor: 'transparent', color: '#c6c6c6' },
    '.cm-selectionMatch': { backgroundColor: '#add6ff26' },
    '&.cm-focused .cm-matchingBracket': { backgroundColor: '#0064001a', outline: '1px solid #888888' },
    '&.cm-focused .cm-nonmatchingBracket': { backgroundColor: '#f4474733' },
    '.cm-searchMatch': { backgroundColor: '#515c6a', outline: '1px solid #74879f' },
    '.cm-searchMatch.cm-searchMatch-selected': { backgroundColor: '#613214' },
    '.cm-panels': { backgroundColor: '#252526', color: '#cccccc' },
    '.cm-panels.cm-panels-top': { borderBottom: '1px solid #3c3c3c' },
    '.cm-tooltip': { backgroundColor: '#252526', border: '1px solid #454545', color: '#cccccc' },
    '.cm-tooltip-autocomplete > ul > li[aria-selected]': { backgroundColor: '#04395e', color: '#ffffff' },
    '.cm-foldPlaceholder': { backgroundColor: '#3a3d41', border: 'none', color: '#cccccc' },
  },
  { dark: true }
);

const darkHighlight = HighlightStyle.define([
  { tag: [t.keyword, t.operatorKeyword, t.definitionKeyword, t.modifier, t.self, t.null, t.bool, t.atom], color: C.keyword },
  { tag: [t.controlKeyword, t.moduleKeyword], color: C.control },
  { tag: [t.string, t.special(t.string), t.attributeValue], color: C.string },
  { tag: t.regexp, color: C.regexp },
  { tag: t.escape, color: C.escape },
  { tag: [t.number, t.unit], color: C.number },
  { tag: [t.comment, t.lineComment, t.blockComment, t.docComment], color: C.comment },
  { tag: [t.variableName, t.propertyName, t.attributeName, t.labelName], color: C.variable },
  { tag: [t.function(t.variableName), t.function(t.propertyName)], color: C.func },
  { tag: [t.className, t.typeName, t.namespace], color: C.type },
  { tag: [t.constant(t.variableName), t.standard(t.variableName)], color: C.constant },
  { tag: t.definition(t.variableName), color: C.variable },
  { tag: t.tagName, color: C.keyword },
  { tag: t.angleBracket, color: '#808080' },
  { tag: [t.meta, t.annotation], color: C.func },
  { tag: [t.operator, t.punctuation, t.bracket, t.separator], color: C.fg },
  { tag: t.heading, color: C.keyword, fontWeight: 'bold' },
  { tag: t.link, color: '#3794ff', textDecoration: 'underline' },
  { tag: t.emphasis, fontStyle: 'italic' },
  { tag: t.strong, fontWeight: 'bold' },
  { tag: [t.processingInstruction, t.documentMeta], color: C.keyword },
  { tag: t.invalid, color: C.invalid },
]);

// ---------- Linguagens ----------
const LANGS = {
  html: { ext: () => html(), indent: 2 },
  css: { ext: () => css(), indent: 2 },
  javascript: { ext: () => javascript({ jsx: true }), indent: 2 },
  typescript: { ext: () => javascript({ jsx: true, typescript: true }), indent: 2 },
  json: { ext: () => json(), indent: 2 },
  python: { ext: () => python(), indent: 4 },
  java: { ext: () => java(), indent: 4 },
  dart: { ext: () => StreamLanguage.define(dart), indent: 2 },
  markdown: { ext: () => markdown(), indent: 2 },
  text: { ext: () => [], indent: 2 },
};

const EXT_TO_LANG = {
  html: 'html', htm: 'html', xml: 'html', svg: 'html',
  css: 'css',
  js: 'javascript', mjs: 'javascript', cjs: 'javascript', jsx: 'javascript',
  ts: 'typescript', tsx: 'typescript',
  json: 'json',
  py: 'python',
  java: 'java',
  dart: 'dart',
  md: 'markdown', markdown: 'markdown',
};

function langIdFor(path) {
  const m = /\.([A-Za-z0-9]+)$/.exec(path || '');
  return (m && EXT_TO_LANG[m[1].toLowerCase()]) || 'text';
}

// ---------- Estado ----------
const wrapCompartment = new Compartment();
const states = new Map(); // path -> EditorState (mantém histórico de desfazer por ficheiro)
let view = null;
let current = null;
let wrapOn = false;
let callbacks = { change() {}, cursor() {} };

function makeState(path, text) {
  const id = langIdFor(path);
  const lang = LANGS[id] || LANGS.text;
  return EditorState.create({
    doc: text,
    extensions: [
      basicSetup,
      keymap.of([indentWithTab]),
      darkTheme,
      syntaxHighlighting(darkHighlight, { fallback: true }),
      lang.ext(),
      indentUnit.of(' '.repeat(lang.indent)),
      EditorState.tabSize.of(lang.indent),
      wrapCompartment.of(wrapOn ? EditorView.lineWrapping : []),
      // Evita que o teclado do Android corrija/capitalize o código
      EditorView.contentAttributes.of({
        autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', autocomplete: 'off',
      }),
      EditorView.updateListener.of((u) => {
        if (!current) return;
        if (u.docChanged) callbacks.change(current);
        if (u.selectionSet || u.docChanged) {
          const head = u.state.selection.main.head;
          const line = u.state.doc.lineAt(head);
          callbacks.cursor(line.number, head - line.from + 1);
        }
      }),
    ],
  });
}

window.CVEditor = {
  available: true,

  init(parent, cb) {
    callbacks = Object.assign(callbacks, cb || {});
    view = new EditorView({ parent, state: EditorState.create({ doc: '', extensions: [darkTheme] }) });
  },

  open(path, text) {
    if (current && view) states.set(current, view.state);
    let st = states.get(path);
    if (!st) {
      st = makeState(path, text);
      states.set(path, st);
    }
    current = path;
    view.setState(st);
    view.dispatch({ effects: wrapCompartment.reconfigure(wrapOn ? EditorView.lineWrapping : []) });
    const head = view.state.selection.main.head;
    const line = view.state.doc.lineAt(head);
    callbacks.cursor(line.number, head - line.from + 1);
  },

  getText(path) {
    if (path === current && view) return view.state.doc.toString();
    const st = states.get(path);
    return st ? st.doc.toString() : null;
  },

  has(path) { return states.has(path); },

  close(path) {
    states.delete(path);
    if (current === path) current = null;
  },

  rename(from, to) {
    // ao renomear mudamos de chave; o realce é recriado na próxima abertura (a extensão pode ter mudado)
    const text = this.getText(from);
    states.delete(from);
    if (current === from) current = null;
    return text;
  },

  clearAll() { states.clear(); current = null; },

  languageOf(path) { return langIdFor(path); },

  focus() { if (view) view.focus(); },

  find() { if (view) { openSearchPanel(view); } },
  undo() { if (view) { undo(view); } },
  redo() { if (view) { redo(view); } },
  selectAll() { if (view) { selectAll(view); } },
  tab() { if (view) { insertTab(view); view.focus(); } },

  insert(text) {
    if (!view) return;
    const r = view.state.selection.main;
    view.dispatch({
      changes: { from: r.from, to: r.to, insert: text },
      selection: { anchor: r.from + text.length },
      scrollIntoView: true,
    });
    view.focus();
  },

  moveCursor(delta) {
    if (!view) return;
    const pos = Math.max(0, Math.min(view.state.doc.length, view.state.selection.main.head + delta));
    view.dispatch({ selection: { anchor: pos }, scrollIntoView: true });
    view.focus();
  },

  setWrap(on) {
    wrapOn = !!on;
    if (view) view.dispatch({ effects: wrapCompartment.reconfigure(wrapOn ? EditorView.lineWrapping : []) });
  },
};
