/* CodeVerse — utilidades do terminal: interpretação de cores ANSI e das marcas que a shell envia
 * (\x01...\x01). Funções puras, sem DOM, para se poderem testar fora do telemóvel. */
'use strict';
(function (root) {
  // Paleta "Tango", a do terminal do Ubuntu/GNOME.
  const BASE = ['#2e3436', '#cc0000', '#4e9a06', '#c4a000', '#3465a4', '#75507b', '#06989a', '#d3d7cf'];
  const BRIGHT = ['#555753', '#ef2929', '#8ae234', '#fce94f', '#729fcf', '#ad7fa8', '#34e2e2', '#eeeeec'];

  function color256(n) {
    if (n < 8) return BASE[n];
    if (n < 16) return BRIGHT[n - 8];
    if (n < 232) {
      const k = n - 16, v = [0, 95, 135, 175, 215, 255];
      return 'rgb(' + v[Math.floor(k / 36)] + ',' + v[Math.floor(k / 6) % 6] + ',' + v[k % 6] + ')';
    }
    const g = 8 + (n - 232) * 10;
    return 'rgb(' + g + ',' + g + ',' + g + ')';
  }

  function newAnsi() { return { fg: null, bg: null, b: false, d: false, u: false, v: false, carry: '' }; }
  function newSplit() { return { mbuf: '' }; }

  function sgr(st, params) {
    const p = params === '' ? [0] : params.split(';').map((x) => (x === '' ? 0 : parseInt(x, 10)));
    for (let i = 0; i < p.length; i++) {
      const n = p[i];
      if (n === 0) { st.fg = st.bg = null; st.b = st.d = st.u = st.v = false; }
      else if (n === 1) st.b = true;
      else if (n === 2) st.d = true;
      else if (n === 4) st.u = true;
      else if (n === 7) st.v = true;
      else if (n === 22) st.b = st.d = false;
      else if (n === 24) st.u = false;
      else if (n === 27) st.v = false;
      else if (n >= 30 && n <= 37) st.fg = BASE[n - 30];
      else if (n === 39) st.fg = null;
      else if (n >= 40 && n <= 47) st.bg = BASE[n - 40];
      else if (n === 49) st.bg = null;
      else if (n >= 90 && n <= 97) st.fg = BRIGHT[n - 90];
      else if (n >= 100 && n <= 107) st.bg = BRIGHT[n - 100];
      else if (n === 38 || n === 48) {
        let c = null;
        if (p[i + 1] === 5) { c = color256(p[i + 2] | 0); i += 2; }
        else if (p[i + 1] === 2) { c = 'rgb(' + (p[i + 2] | 0) + ',' + (p[i + 3] | 0) + ',' + (p[i + 4] | 0) + ')'; i += 4; }
        if (c) { if (n === 38) st.fg = c; else st.bg = c; }
      }
    }
  }

  // Texto -> operações: {t:'text', s, fg, bg, b, d, u, v} | {t:'nl'} | {t:'cr'}
  function parse(st, input) {
    const s = st.carry + input;
    st.carry = '';
    const ops = [];
    let buf = '';
    const flush = () => {
      if (buf) { ops.push({ t: 'text', s: buf, fg: st.fg, bg: st.bg, b: st.b, d: st.d, u: st.u, v: st.v }); buf = ''; }
    };
    let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (c === '\x1b') {
        if (i + 1 >= s.length) { st.carry = s.slice(i); break; }
        const n = s[i + 1];
        if (n === '[') {
          let j = i + 2;
          while (j < s.length && !(s.charCodeAt(j) >= 0x40 && s.charCodeAt(j) <= 0x7e)) j++;
          if (j >= s.length) { st.carry = s.slice(i); break; }
          if (s[j] === 'm') { flush(); sgr(st, s.slice(i + 2, j)); }
          i = j + 1; continue;
        }
        if (n === ']') {
          let j = i + 2;
          while (j < s.length && s[j] !== '\x07' && !(s[j] === '\x1b' && s[j + 1] === '\\')) j++;
          if (j >= s.length) { st.carry = s.slice(i); break; }
          i = s[j] === '\x07' ? j + 1 : j + 2; continue;
        }
        i += 2; continue;
      }
      if (c === '\r') {
        if (i + 1 >= s.length) { st.carry = '\r'; break; }   // pode vir "\n" no bloco seguinte
        if (s[i + 1] === '\n') { i++; continue; }
        flush(); ops.push({ t: 'cr' }); i++; continue;
      }
      if (c === '\n') { flush(); ops.push({ t: 'nl' }); i++; continue; }
      if (c === '\t') { buf += '    '; i++; continue; }
      if (c < ' ' || c === '\x7f') { i++; continue; }
      buf += c; i++;
    }
    flush();
    return ops;
  }

  // Separa o texto normal das marcas da shell: \x01<texto>\x01 (uma "\n" logo a seguir é descartada).
  function split(st, text) {
    const s = (st.mbuf || '') + text;
    st.mbuf = '';
    const ev = [];
    let i = 0;
    while (i < s.length) {
      const a = s.indexOf('\x01', i);
      if (a < 0) { ev.push({ t: 'out', s: s.slice(i) }); break; }
      if (a > i) ev.push({ t: 'out', s: s.slice(i, a) });
      const b = s.indexOf('\x01', a + 1);
      if (b < 0) { st.mbuf = s.slice(a); break; }
      ev.push({ t: 'mark', v: s.slice(a + 1, b) });
      i = b + 1;
    }
    return ev;
  }

  // Parte comum dos nomes a completar com Tab.
  function commonPrefix(list) {
    if (!list.length) return '';
    let pre = list[0];
    for (const x of list) while (!x.startsWith(pre)) pre = pre.slice(0, -1);
    return pre;
  }

  // Caminho curto para o prompt: ~ para a home; só os 2 últimos níveis se for longo.
  function shortPath(cwd, home) {
    const c = cwd || '', h = home || '';
    let p = c;
    if (h && c === h) p = '~';
    else if (h && c.startsWith(h + '/')) p = '~' + c.slice(h.length);
    if (!p) p = '~';
    if (p.length > 24) {
      const segs = p.split('/').filter(Boolean);
      p = '…/' + segs.slice(-2).join('/');
    }
    return p;
  }

  const api = { newAnsi, newSplit, parse, split, commonPrefix, shortPath };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.CVTerm = api;
})(typeof window !== 'undefined' ? window : globalThis);
