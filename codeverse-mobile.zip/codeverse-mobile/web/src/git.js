/* CodeVerse — Git / GitHub: aba "Git" (controlo de código-fonte), clonar, login, branches, histórico.
 * A parte pesada corre no lado nativo (JGit, ver GitService.kt); aqui só há interface.
 * Usa a API que o app.js entrega em CVGit.init({...}). */
'use strict';
(function () {
  let A = null;
  const G = {
    auth: null,       // { loggedIn, login, name, email, hasClientId, clientId }
    st: null,         // último estado do repositório
    map: {},          // caminho -> letra (M, A, D, U, C)
    dirs: {},         // pasta -> tem alterações
    pending: new Map(),
    seq: 0,
    timer: null,
    busy: '',         // texto da operação longa em curso
    msg: '',          // mensagem de commit (mantida entre renderizações)
    version: 0,
  };

  // ===================== Chamadas nativas =====================
  function run(op, args, opts) {
    opts = opts || {};
    const id = 'git' + (++G.seq) + '_' + Date.now();
    const project = opts.project === undefined ? (A.S.project || '') : opts.project;
    const p = new Promise((resolve, reject) => {
      G.pending.set(id, { resolve, reject, onProgress: opts.onProgress, onPhase: opts.onPhase });
      try { A.nat('gitRun', id, op, project, JSON.stringify(args || {})); }
      catch (e) { G.pending.delete(id); reject(e); }
    });
    p.id = id;
    return p;
  }

  function onNative(m) {
    const p = G.pending.get(m.id);
    if (!p) return;
    if (m.phase === 'progress') { if (p.onProgress) p.onProgress(m.text); return; }
    if (m.phase && m.phase !== 'done') { if (p.onPhase) p.onPhase(m); return; }
    G.pending.delete(m.id);
    if (m.ok) p.resolve(m);
    else { const e = new Error(m.error || 'Erro'); e.code = m.code || ''; p.reject(e); }
  }

  function loadAuth() {
    try { G.auth = A.nat('gitAuth'); } catch (_) { G.auth = { loggedIn: false }; }
    return G.auth;
  }
  function setAuth(r) {
    G.auth = { loggedIn: r.loggedIn, login: r.login, name: r.name, email: r.email, hasClientId: r.hasClientId, clientId: r.clientId };
  }

  // ===================== Estado do repositório =====================
  function computeMap() {
    G.map = {}; G.dirs = {};
    const st = G.st;
    if (!st || !st.repo) return;
    const mark = (path, letter, force) => {
      if (force || !G.map[path]) G.map[path] = letter;
      const parts = path.split('/');
      for (let i = 1; i < parts.length; i++) G.dirs[parts.slice(0, i).join('/')] = true;
    };
    (st.staged || []).forEach((f) => mark(f.path, f.s, false));
    (st.changes || []).forEach((f) => mark(f.path, f.s, true));
  }

  async function refresh() {
    const proj = A.S.project;
    if (!proj) return;
    A.flushSaves();
    const ver = G.version;
    try {
      const st = await run('status', {}, { project: proj });
      if (A.S.project !== proj || ver !== G.version) return;
      G.st = st;
    } catch (e) {
      if (A.S.project !== proj || ver !== G.version) return;
      G.st = { repo: false, error: e.message };
    }
    computeMap();
    render();
    A.renderTree();
    updateStatusBar();
    updateRailBadge();
  }

  function touch() {
    if (!A || !A.S.project) return;
    clearTimeout(G.timer);
    G.timer = setTimeout(() => { if (!G.busy) refresh(); }, 1500);
  }

  function onProject(name) {
    G.version++;
    clearTimeout(G.timer);
    G.st = null; G.map = {}; G.dirs = {}; G.busy = ''; G.msg = '';
    updateStatusBar(); updateRailBadge();
    if (name) { loadAuth(); render(); refresh(); }
  }

  function badge(path, isDir) {
    if (!G.st || !G.st.repo) return null;
    if (isDir) return G.dirs[path] ? A.el('span', { class: 'gdot' }) : null;
    const l = G.map[path];
    return l ? A.el('span', { class: 'gbadge g-' + l, text: l }) : null;
  }

  function updateStatusBar() {
    const e = A.$('#st-branch');
    if (!e) return;
    const st = G.st;
    if (!A.S.project || !st || !st.repo) { e.classList.add('hidden'); return; }
    e.classList.remove('hidden');
    e.textContent = '';
    e.append(A.el('span', { html: A.I.svg('branch', 13), style: 'display:flex' }),
      A.el('span', { text: st.branch }), counts(st, 11));
  }

  // Commits à frente/atrás do remoto, com setas em ícone (sem símbolos de texto).
  function counts(st, size) {
    const one = (name, n) => A.el('span', { class: 'gcnt', html: A.I.svg(name, size) + '<b>' + Number(n) + '</b>' });
    return [st.ahead ? one('arrow-up', st.ahead) : null, st.behind ? one('arrow-down', st.behind) : null];
  }

  function updateRailBadge() {
    const b = A.$('#rail-git');
    if (!b) return;
    let e = b.querySelector('.rail-badge');
    const n = G.st && G.st.repo ? ((G.st.staged || []).length + (G.st.changes || []).length) : 0;
    if (!n) { if (e) e.remove(); return; }
    if (!e) { e = A.el('span', { class: 'rail-badge' }); b.append(e); }
    e.textContent = n > 99 ? '99+' : String(n);
  }

  // ===================== Erros e ações =====================
  function handleErr(e, retry) {
    if (e.code === 'need_login') { loginFlow().then((ok) => { if (ok && retry) retry(); }); return; }
    if (e.code === 'need_identity') { identityDialog().then((ok) => { if (ok && retry) retry(); }); return; }
    if (e.code === 'need_remote') { remoteDialog().then((ok) => { if (ok && retry) retry(); }); return; }
    A.toast(e.message || 'Erro', true);
  }

  function setBusy(text) { G.busy = text || ''; render(); }

  async function longOp(label, op, args, onOk, retry) {
    if (G.busy) { A.toast('Aguarda a operação em curso…'); return; }
    setBusy(label + '…');
    try {
      const r = await run(op, args || {}, { onProgress: (t) => { G.busy = t; const b = A.$('#git-busy'); if (b) b.textContent = t; } });
      G.busy = '';
      if (onOk) await onOk(r);
    } catch (e) {
      G.busy = '';
      handleErr(e, retry);
    }
    await refresh();
  }

  const doInit = () => longOp('A inicializar', 'init', {}, () => A.toast('Repositório Git criado'));

  async function doCommit(amend) {
    const message = G.msg;
    const st = G.st;
    if (!amend && st && !(st.staged || []).length && (st.changes || []).length && !st.merging) {
      const ok = await A.uiConfirm('Nada em stage', 'Fazer stage de todas as alterações e criar o commit?', 'Stage + commit');
      if (!ok) return;
      try { await run('stage', { all: true }); } catch (e) { handleErr(e); return; }
    }
    await longOp('A criar commit', 'commit', { message, amend: !!amend }, (r) => {
      G.msg = '';
      A.toast('Commit ' + r.id + ' criado');
    }, () => doCommit(amend));
  }

  const doPush = () => longOp('A enviar', 'push', {}, (r) => A.toast(r.upToDate ? 'Já está tudo enviado' : 'Enviado para o GitHub'), doPush);

  const doPull = () => longOp('A receber', 'pull', {}, (r) => {
    if (r.conflicts && r.conflicts.length) {
      A.toast('Conflitos em ' + r.conflicts.length + ' ficheiro(s). Resolve-os e faz stage.', true);
      A.reloadFromDisk();
    } else if (r.upToDate) A.toast('Já está atualizado');
    else { A.toast('Atualizado'); A.reloadFromDisk(); }
  }, doPull);

  async function stage(paths) { try { await run('stage', { paths }); } catch (e) { handleErr(e); } refresh(); }
  async function stageAll() { try { await run('stage', { all: true }); } catch (e) { handleErr(e); } refresh(); }
  async function unstage(paths) { try { await run('unstage', { paths }); } catch (e) { handleErr(e); } refresh(); }

  async function discard(files) {
    const one = files.length === 1;
    const onlyNew = files.every((f) => f.s === 'U');
    const msg = one
      ? (onlyNew ? '“' + A.basename(files[0].path) + '” é um ficheiro novo e será apagado.' : 'Descartar as alterações de “' + A.basename(files[0].path) + '”? Não pode ser desfeito.')
      : 'Descartar as alterações de ' + files.length + ' ficheiros? Ficheiros novos serão apagados. Não pode ser desfeito.';
    if (!(await A.uiConfirm('Descartar alterações', msg, 'Descartar', true))) return;
    try {
      await run('discard', { items: files.map((f) => ({ path: f.path, s: f.s })) });
      A.reloadFromDisk();
    } catch (e) { handleErr(e); }
    refresh();
  }

  // ===================== Vista =====================
  function sectionHead(title, count, buttons) {
    return A.el('div', { class: 'git-sec' },
      A.el('span', { class: 't', text: title }),
      A.el('span', { class: 'cnt', text: String(count) }),
      ...buttons.map((b) => A.el('button', { class: 'more', 'aria-label': b.label, html: A.I.svg(b.icon, 17), onclick: b.fn })));
  }

  function fileRow(f, staged) {
    const name = A.basename(f.path);
    const dir = A.dirname(f.path);
    const btns = staged
      ? [{ icon: 'minus', label: 'Remover do stage', fn: () => unstage([f.path]) }]
      : [{ icon: 'undo', label: 'Descartar', fn: () => discard([f]) }, { icon: 'plus', label: 'Fazer stage', fn: () => stage([f.path]) }];
    const row = A.el('div', { class: 'row grow', role: 'button' },
      A.fileIcon(name, 16),
      A.el('span', { class: 'nm' }, name, dir ? A.el('span', { class: 'gdir', text: '  ' + dir }) : null),
      ...btns.map((b) => A.el('button', { class: 'more', 'aria-label': b.label, html: A.I.svg(b.icon, 17), onclick: (ev) => { ev.stopPropagation(); b.fn(); } })),
      A.el('span', { class: 'gbadge g-' + f.s, text: f.s }));
    row.addEventListener('click', () => showDiff(f, staged));
    return row;
  }

  function render() {
    const host = A.$('#git-body');
    if (!host) return;
    const keep = host.scrollTop;
    host.textContent = '';
    if (!A.S.project) return;
    const st = G.st;
    if (!st) { host.append(A.el('div', { class: 'git-note', text: 'A carregar…' })); return; }

    if (!st.repo) {
      host.append(A.el('div', { class: 'git-note' },
        A.el('div', { text: 'Esta pasta ainda não é um repositório Git.' }),
        A.el('div', { class: 'muted', style: 'margin-top:8px;font-size:12.5px', text: 'Para guardar o histórico e enviar o projeto para o GitHub, inicializa o repositório. Para trazer um projeto que já existe no GitHub, usa “Clonar” no ecrã inicial.' }),
        A.el('button', { class: 'btn primary', text: 'Inicializar repositório', onclick: doInit })));
      return;
    }

    if (G.busy) host.append(A.el('div', { class: 'git-busy', id: 'git-busy', text: G.busy }));
    const conflicts = (st.changes || []).filter((f) => f.s === 'C');
    if (conflicts.length) host.append(A.el('div', { class: 'git-warn', text: conflicts.length + ' ficheiro(s) com conflitos. Edita-os (procura <<<<<<<), depois toca em “+” e faz commit.' }));

    host.append(A.el('div', { class: 'git-branch' },
      A.el('div', { class: 'bn', role: 'button', onclick: branchMenu },
        A.el('span', { html: A.I.svg('branch', 18), style: 'display:flex' }),
        A.el('span', { text: st.branch || '—' }),
        (st.ahead || st.behind) ? A.el('span', { class: 'cnt' }, counts(st, 12)) : null),
      A.el('button', { class: 'icon-btn small', 'aria-label': 'Pull (receber)', html: A.I.svg('download', 19), onclick: doPull }),
      A.el('button', { class: 'icon-btn small', 'aria-label': 'Push (enviar)', html: A.I.svg('import', 19), onclick: doPush })));

    host.append(st.remote
      ? A.el('div', { class: 'git-remote', text: st.remote })
      : A.el('div', { class: 'git-remote' }, 'Sem repositório remoto. ', A.el('a', { href: '#', style: 'color:var(--link)', text: 'Definir', onclick: (ev) => { ev.preventDefault(); remoteDialog().then((ok) => ok && refresh()); } })));

    const ta = A.el('textarea', { id: 'git-msg', placeholder: 'Mensagem do commit', rows: '2', autocapitalize: 'sentences' });
    ta.value = G.msg;
    ta.addEventListener('input', () => { G.msg = ta.value; });
    const n = (st.staged || []).length;
    host.append(A.el('div', { class: 'git-commit' }, ta,
      A.el('button', { class: 'btn primary', onclick: () => doCommit(false) },
        A.el('span', { html: A.I.svg('check', 18), style: 'display:flex' }),
        A.el('span', { text: 'Commit' + (n ? ' (' + n + ')' : '') }))));

    if (n) {
      host.append(sectionHead('Em stage', n, [{ icon: 'minus', label: 'Remover tudo do stage', fn: () => unstage(st.staged.map((f) => f.path)) }]));
      st.staged.forEach((f) => host.append(fileRow(f, true)));
    }
    const ch = st.changes || [];
    if (ch.length) {
      host.append(sectionHead('Alterações', ch.length, [
        { icon: 'undo', label: 'Descartar tudo', fn: () => discard(ch) },
        { icon: 'plus', label: 'Fazer stage de tudo', fn: stageAll },
      ]));
      ch.forEach((f) => host.append(fileRow(f, false)));
    }
    if (!n && !ch.length) host.append(A.el('div', { class: 'git-note', text: st.hasCommits ? 'Sem alterações.' : 'Ainda não há commits. Adiciona ficheiros e faz o primeiro commit.' }));
    host.scrollTop = keep;
  }

  // ===================== Diff =====================
  async function showDiff(f, staged) {
    let text = '';
    try { text = (await run('diff', { path: f.path, staged, s: f.s })).text || ''; }
    catch (e) { A.toast(e.message, true); return; }
    A.openModal((box, close) => {
      const pre = A.el('div', { class: 'gdiff' });
      const lines = text.split('\n');
      const cap = Math.min(lines.length, 3000);
      for (let i = 0; i < cap; i++) {
        const l = lines[i];
        let cls = '';
        if (l.startsWith('@@')) cls = 'hunk';
        else if (l.startsWith('+++') || l.startsWith('---') || l.startsWith('diff ') || l.startsWith('index ') || l.startsWith('novo ficheiro')) cls = 'meta';
        else if (l.startsWith('+')) cls = 'add';
        else if (l.startsWith('-')) cls = 'del';
        pre.append(A.el('div', { class: cls, text: l || ' ' }));
      }
      if (lines.length > cap) pre.append(A.el('div', { class: 'meta', text: '… (' + (lines.length - cap) + ' linhas escondidas)' }));
      box.append(A.el('h3', { text: A.basename(f.path) + (staged ? ' (em stage)' : '') }), pre,
        A.el('div', { class: 'modal-actions' },
          f.s !== 'D' ? A.el('button', { class: 'btn', text: 'Abrir ficheiro', onclick: () => { close(null); A.openFile(f.path); A.closeExplorer(); } }) : null,
          A.el('button', { class: 'btn primary', text: 'Fechar', onclick: () => close(null) })));
    });
  }

  // ===================== Branches e histórico =====================
  async function branchMenu() {
    let r;
    try { r = await run('branches', {}); } catch (e) { handleErr(e); return; }
    const items = [{ id: 'new', label: 'Nova branch…', icon: 'plus' }];
    r.local.forEach((b) => items.push({ id: 'b:' + b, label: b + (b === r.current ? '  (atual)' : ''), icon: b === r.current ? 'check' : 'branch' }));
    r.remote.forEach((b) => items.push({ id: 'r:' + b, label: 'origin/' + b, icon: 'download' }));
    const a = await A.uiSheet('Branches', items);
    if (!a) return;
    if (a === 'new') {
      const name = await A.uiPrompt('Nova branch', '', 'nome-da-branch', 'Criar');
      if (name) switchBranch(name.trim(), true);
    } else if (a.startsWith('b:') || a.startsWith('r:')) {
      const name = a.slice(2);
      if (name !== r.current) switchBranch(name, false);
    }
  }

  async function switchBranch(name, create) {
    await longOp('A mudar de branch', 'checkout', { name, create }, () => {
      A.toast('Branch: ' + name);
      A.reloadFromDisk();
    });
  }

  async function historyDialog() {
    let r;
    try { r = await run('log', { max: 40 }); } catch (e) { handleErr(e); return; }
    A.openModal((box, close) => {
      box.append(A.el('h3', { text: 'Histórico' }));
      if (!r.commits.length) box.append(A.el('p', { text: 'Ainda não há commits.' }));
      const list = A.el('div', { class: 'glist' });
      r.commits.forEach((c) => list.append(A.el('div', { class: 'sheet-item' },
        A.el('span', { text: c.msg }),
        A.el('span', { class: 'sub', text: c.id + ' · ' + c.author + ' · ' + A.relTime(c.time) }))));
      box.append(list, A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn primary', text: 'Fechar', onclick: () => close(null) })));
    });
  }

  // ===================== Conta GitHub =====================
  function identityDialog() {
    const a = G.auth || {};
    return A.openModal((box, close) => {
      const n = A.el('input', { type: 'text', value: a.name || '', placeholder: 'O teu nome', autocapitalize: 'words', autocorrect: 'off', spellcheck: 'false' });
      const e = A.el('input', { type: 'email', value: a.email || '', placeholder: 'email@exemplo.com', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => {
        try { setAuth(A.nat('gitSetIdentity', n.value, e.value)); close(true); A.toast('Identidade guardada'); }
        catch (er) { A.toast(er.message, true); }
      };
      box.append(A.el('h3', { text: 'Nome e email do Git' }),
        A.el('p', { text: 'Aparecem nos teus commits. Podes usar o email privado “noreply” do GitHub.' }),
        A.el('label', { class: 'field', text: 'Nome' }), n,
        A.el('label', { class: 'field', text: 'Email' }), e,
        A.el('div', { class: 'modal-actions' },
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          A.el('button', { class: 'btn primary', text: 'Guardar', onclick: submit })));
    }).then((v) => v === true);
  }

  function tokenDialog() {
    return A.openModal((box, close) => {
      const input = A.el('input', { type: 'password', placeholder: 'ghp_… ou github_pat_…', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => close(input.value.trim() || null);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
      box.append(A.el('h3', { text: 'Token de acesso do GitHub' }),
        A.el('p', { text: 'Toca em “Criar token no GitHub”, desce até ao fim e toca em “Generate token”. Copia o token e cola-o aqui. Só tens de fazer isto uma vez; fica guardado cifrado neste telemóvel.' }),
        input,
        A.el('div', { class: 'modal-actions wrap' },
          A.el('button', { class: 'btn', text: 'Criar token no GitHub', onclick: () => { try { A.nat('gitOpenUrl', 'https://github.com/settings/tokens/new?scopes=repo,workflow&description=CodeVerse'); } catch (e) { A.toast(e.message, true); } } }),
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          A.el('button', { class: 'btn primary', text: 'Entrar', onclick: submit })));
    });
  }

  async function loginWithToken() {
    const token = await tokenDialog();
    if (!token) return false;
    try {
      const r = await run('login', { token }, { project: '' });
      setAuth(r);
      A.toast('Sessão iniciada como @' + r.login);
      return true;
    } catch (e) { A.toast(e.message, true); return false; }
  }

  function clientIdDialog() {
    return A.openModal((box, close) => {
      const input = A.el('input', { type: 'text', value: (G.auth && G.auth.clientId) || '', placeholder: 'Client ID (Iv1.… ou Ov23…)', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => close(input.value.trim() || null);
      box.append(A.el('h3', { text: 'Client ID da OAuth App' }),
        A.el('p', { text: 'Para entrar com código, cria uma OAuth App em github.com/settings/developers, ativa “Enable Device Flow” e cola aqui o Client ID. (Não precisas de segredo.)' }),
        input,
        A.el('div', { class: 'modal-actions wrap' },
          A.el('button', { class: 'btn', text: 'Abrir GitHub', onclick: () => { try { A.nat('gitOpenUrl', 'https://github.com/settings/applications/new'); } catch (e) { A.toast(e.message, true); } } }),
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          A.el('button', { class: 'btn primary', text: 'Guardar', onclick: submit })));
    });
  }

  async function loginWithDevice() {
    if (!G.auth || !G.auth.hasClientId) {
      const cid = await clientIdDialog();
      if (!cid) return false;
      try { setAuth(A.nat('gitSetClientId', cid)); } catch (e) { A.toast(e.message, true); return false; }
    }
    let codeBox = null; let uri = ''; let closeFn = null; let finished = false;
    const modal = A.openModal((box, close) => {
      closeFn = close;
      codeBox = A.el('div', { class: 'gcode', text: '…' });
      box.append(A.el('h3', { text: 'Entrar com código' }),
        A.el('p', { text: '1. Abre a página do GitHub.  2. Escreve este código e autoriza o CodeVerse.' }),
        codeBox,
        A.el('div', { class: 'modal-actions wrap' },
          A.el('button', { class: 'btn', text: 'Copiar código', onclick: async () => {
            try { await navigator.clipboard.writeText(codeBox.textContent); A.toast('Código copiado'); } catch (_) { A.toast('Seleciona o código e copia-o.'); }
          } }),
          A.el('button', { class: 'btn primary', text: 'Abrir github.com/login/device', onclick: () => { try { A.nat('gitOpenUrl', uri || 'https://github.com/login/device'); } catch (e) { A.toast(e.message, true); } } }),
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) })),
        A.el('p', { class: 'muted', style: 'margin:10px 0 0;font-size:12px', text: 'A aguardar autorização…' }));
    });
    const job = run('device', {}, { project: '', onPhase: (m) => { if (m.phase === 'code') { uri = m.uri; if (codeBox) codeBox.textContent = m.user_code; } } });
    modal.then(() => { if (!finished) { try { A.nat('gitCancel', job.id); } catch (_) { /* ignora */ } } });
    try {
      const r = await job;
      finished = true;
      setAuth(r);
      if (closeFn) closeFn(true);
      A.toast('Sessão iniciada como @' + r.login);
      return true;
    } catch (e) {
      finished = true;
      if (closeFn) closeFn(null);
      if (e.code === 'need_client_id') { setAuth(A.nat('gitSetClientId', '')); }
      if (e.message !== 'Cancelado.') A.toast(e.message, true);
      return false;
    }
  }

  // Login sem configurar nada: só precisa de um token (o GitHub abre já com a permissão certa marcada).
  async function loginFlow() {
    loadAuth();
    const ok = await loginWithToken();
    if (ok) refresh();
    return ok;
  }

  function logout() {
    try { setAuth(A.nat('gitLogout')); A.toast('Sessão terminada'); } catch (e) { A.toast(e.message, true); }
  }

  // ===================== Remoto =====================
  function remoteDialog() {
    loadAuth();
    return A.openModal((box, close) => {
      const input = A.el('input', { type: 'text', placeholder: 'https://github.com/dono/repositorio', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      if (G.st && G.st.remote) input.value = G.st.remote;
      const save = async () => {
        const url = input.value.trim();
        if (!url) return;
        try { await run('remote', { url }); close(true); A.toast('Remoto definido'); }
        catch (e) { A.toast(e.message, true); }
      };
      const create = async () => {
        if (!G.auth || !G.auth.loggedIn) { close(null); const ok = await loginFlow(); if (ok) remoteDialog().then(() => refresh()); return; }
        const def = (A.S.project || 'projeto').replace(/[^A-Za-z0-9._-]+/g, '-');
        const name = await A.uiPrompt('Nome do repositório no GitHub', def, 'nome-do-repositorio', 'Criar');
        if (!name) return;
        const vis = await A.uiSheet('Visibilidade de “' + name + '”', [
          { id: 'private', label: 'Privado (só tu vês)', icon: 'key' },
          { id: 'public', label: 'Público (qualquer pessoa vê)', icon: 'globe' },
        ]);
        if (!vis) return;
        try { await run('createRepo', { name, private: vis === 'private' }); close(true); A.toast('Repositório criado no GitHub'); }
        catch (e) { A.toast(e.message, true); }
      };
      box.append(A.el('h3', { text: 'Repositório remoto (origin)' }),
        A.el('p', { text: 'Cola o endereço de um repositório do GitHub, ou cria um novo vazio na tua conta.' }),
        input,
        A.el('div', { class: 'modal-actions wrap' },
          A.el('button', { class: 'btn', text: 'Criar novo no GitHub', onclick: create }),
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          A.el('button', { class: 'btn primary', text: 'Guardar', onclick: save })));
    }).then((v) => v === true);
  }

  // ===================== Menu "mais" =====================
  async function moreMenu() {
    loadAuth();
    const st = G.st;
    const items = [];
    if (st && st.repo) {
      items.push(
        { id: 'pull', label: 'Pull (receber)', icon: 'download' },
        { id: 'push', label: 'Push (enviar)', icon: 'import' },
        { id: 'branch', label: 'Branches…', icon: 'branch' },
        { id: 'log', label: 'Histórico', icon: 'history' },
        { id: 'amend', label: 'Emendar o último commit', icon: 'edit' },
        { id: 'remote', label: 'Repositório remoto…', icon: 'globe' });
    }
    items.push({ id: 'identity', label: 'Nome e email do Git…', icon: 'user' });
    if (G.auth && G.auth.loggedIn) items.push({ id: 'logout', label: 'Terminar sessão (@' + G.auth.login + ')', icon: 'close' });
    else items.push({ id: 'login', label: 'Entrar no GitHub…', icon: 'key' });
    const a = await A.uiSheet('Git', items);
    if (a === 'pull') doPull();
    else if (a === 'push') doPush();
    else if (a === 'branch') branchMenu();
    else if (a === 'log') historyDialog();
    else if (a === 'amend') doCommit(true);
    else if (a === 'remote') remoteDialog().then((ok) => ok && refresh());
    else if (a === 'identity') identityDialog();
    else if (a === 'logout') logout();
    else if (a === 'login') loginFlow();
  }

  // ===================== Clonar =====================
  function reposPicker() {
    return A.openModal((box, close) => {
      box.append(A.el('h3', { text: 'Os meus repositórios' }));
      const filter = A.el('input', { type: 'text', placeholder: 'Filtrar…', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const list = A.el('div', { class: 'glist' }, A.el('p', { text: 'A carregar…' }));
      box.append(filter, list, A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn', text: 'Fechar', onclick: () => close(null) })));
      let repos = [];
      const draw = () => {
        const q = filter.value.trim().toLowerCase();
        list.textContent = '';
        const shown = repos.filter((r) => !q || r.name.toLowerCase().includes(q));
        if (!shown.length) list.append(A.el('p', { text: repos.length ? 'Nada encontrado.' : 'Sem repositórios.' }));
        shown.forEach((r) => list.append(A.el('button', { class: 'sheet-item', onclick: () => close(r.url) },
          A.el('span', {}, [r.name, r.private ? A.el('span', { class: 'priv', title: 'Privado', html: A.I.svg('lock', 13) }) : null]),
          r.desc ? A.el('span', { class: 'sub', text: r.desc }) : null)));
      };
      filter.addEventListener('input', draw);
      run('repos', {}, { project: '' }).then((r) => { repos = r.repos; draw(); })
        .catch((e) => { list.textContent = ''; list.append(A.el('p', { text: e.message })); });
    });
  }

  function progressModal(title) {
    let setText = () => {}; let closeFn = () => {}; let jobId = null; let done = false;
    const m = A.openModal((box, close) => {
      closeFn = close;
      const p = A.el('p', { text: 'A preparar…' });
      setText = (t) => { p.textContent = t; };
      box.append(A.el('h3', { text: title }), p,
        A.el('div', { class: 'modal-actions' }, A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) })));
    });
    m.then(() => { if (!done && jobId) { try { A.nat('gitCancel', jobId); } catch (_) { /* ignora */ } } });
    return { setText: (t) => setText(t), setJob: (id) => { jobId = id; }, close: () => { done = true; closeFn(null); } };
  }

  async function cloneDialog() {
    loadAuth();
    const url = await A.openModal((box, close) => {
      const input = A.el('input', { type: 'text', placeholder: 'https://github.com/dono/repo  ou  dono/repo', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
      const submit = () => close(input.value.trim() || null);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
      const who = A.el('p', { class: 'muted', style: 'margin:8px 0 0;font-size:12.5px' });
      const actions = A.el('div', { class: 'modal-actions wrap' });
      const draw = () => {
        who.textContent = G.auth && G.auth.loggedIn ? 'Sessão: @' + G.auth.login : 'Sem sessão: só consegues clonar repositórios públicos.';
        actions.textContent = '';
        actions.append(
          G.auth && G.auth.loggedIn
            ? A.el('button', { class: 'btn', text: 'Os meus repositórios', onclick: async () => { const u = await reposPicker(); if (u) close(u); } })
            : A.el('button', { class: 'btn', text: 'Entrar no GitHub', onclick: async () => { if (await loginFlow()) draw(); } }),
          A.el('button', { class: 'btn', text: 'Cancelar', onclick: () => close(null) }),
          A.el('button', { class: 'btn primary', text: 'Clonar', onclick: submit }));
      };
      draw();
      box.append(A.el('h3', { text: 'Clonar do GitHub' }),
        A.el('p', { text: 'Descarrega um repositório para um projeto novo no CodeVerse.' }), input, who, actions);
    });
    if (!url) return;
    const pm = progressModal('A clonar…');
    const job = run('clone', { url }, { project: '', onProgress: (t) => pm.setText(t) });
    pm.setJob(job.id);
    try {
      const r = await job;
      pm.close();
      A.toast('Repositório clonado');
      A.openProject(r.project);
    } catch (e) {
      pm.close();
      if (e.message !== 'Cancelado.') handleErr(e, () => { /* o utilizador repete a partir do diálogo */ });
    }
  }

  // ===================== Arranque =====================
  function init(api) {
    A = api;
    A.listeners.git = onNative;
    const b = (sel, fn) => { const e = A.$(sel); if (e) e.addEventListener('click', fn); };
    b('#git-refresh', refresh);
    b('#git-more', moreMenu);
    b('#st-branch', branchMenu);
  }

  // ===================== Compilar APK na nuvem (GitHub Actions): Flutter, Kotlin/Android e JavaScript =====================
  const APK_WF = '.github/workflows/build-apk.yml';
  let buildingId = null;

  // ui = { say(tipo, texto), state(texto) }. Devolve true se o APK ficou pronto (e o instalador abriu).
  async function buildApk(ui, attempt) {
    attempt = attempt || 0;
    const proj = A.S.project;
    if (!proj) return false;
    A.flushSaves();
    loadAuth();
    if (!G.auth || !G.auth.loggedIn) {
      ui.say('out', 'Para compilar na nuvem é preciso entrar no GitHub.\n');
      if (!(await loginFlow())) { ui.say('err', 'Sem sessão no GitHub.\n'); return false; }
    }
    // O workflow universal tem de estar no projeto (só o acrescenta se ainda não existir).
    if (!A.S.tree.some((i) => i.path === APK_WF)) {
      if (!window.CV_CI_YML) { ui.say('err', 'Falta o modelo do workflow de compilação.\n'); return false; }
      A.nat('writeFiles', proj, JSON.stringify({ [APK_WF]: window.CV_CI_YML }));
      A.reloadFromDisk();
      ui.say('out', 'Adicionei o workflow ' + APK_WF + ' ao projeto.\n');
    }
    try {
      ui.state('A preparar o repositório…');
      let st = await run('status', {}, { project: proj });
      if (!st.repo) { await run('init', {}, { project: proj }); st = await run('status', {}, { project: proj }); }
      if (!st.remote) {
        ui.say('out', 'Falta ligar o projeto a um repositório do GitHub.\n');
        if (!(await remoteDialog())) { ui.say('err', 'Sem repositório no GitHub.\n'); return false; }
        st = await run('status', {}, { project: proj });
      }
      if ((st.staged || []).length || (st.changes || []).length) {
        ui.state('A guardar as alterações (commit)…');
        await run('stage', { all: true }, { project: proj });
        await run('commit', { message: 'CodeVerse: compilar APK' }, { project: proj });
      }
      ui.state('A enviar para o GitHub…');
      const p = run('ciBuild', { workflow: 'build-apk.yml' }, { project: proj, onProgress: (t) => ui.state(t) });
      buildingId = p.id;
      try { await p; } finally { buildingId = null; }
      ui.say('out', 'APK pronto. A abrir o instalador do Android…\n');
      A.nat('installBuiltApk');
      return true;
    } catch (e) {
      if (attempt < 2) {
        if (e.code === 'need_identity' && (await identityDialog())) return buildApk(ui, attempt + 1);
        if (e.code === 'need_login' && (await loginFlow())) return buildApk(ui, attempt + 1);
      }
      const msg = String(e.message || 'Erro');
      ui.say('err', msg + '\n');
      const url = (/https:\/\/github\.com\/\S+/.exec(msg) || [])[0];
      if (url && (await A.uiConfirm('A compilação falhou', msg.replace(url, '').trim() + '\nAbrir o registo no GitHub?', 'Abrir registo'))) {
        try { A.nat('gitOpenUrl', url); } catch (_) { /* ignora */ }
      }
      return false;
    } finally { await refresh(); }
  }

  function cancelBuild() { if (buildingId) { try { A.nat('gitCancel', buildingId); } catch (_) { /* ignora */ } } }

  window.CVGit = {
    buildApk,
    cancelBuild,
    init,
    onProject,
    touch,
    refresh,
    badge,
    show() { loadAuth(); render(); refresh(); },
    cloneDialog,
  };
})();
