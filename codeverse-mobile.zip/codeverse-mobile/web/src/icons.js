/* CodeVerse — conjunto de ícones próprio (SVG inline, sem emojis nem fontes de ícones).
 * Ícones de interface: grelha 24x24, traço 1.8, extremidades redondas, cor = currentColor.
 * Ícones de ficheiro: grelha 16x16, coloridos.
 * Uso: CVIcons.svg('play', 20)  |  elementos com data-icon="play" são preenchidos por CVIcons.hydrate().
 */
(function () {
  'use strict';

  // ---- Interface (traço) ----
  const UI = {
    save: '<path d="M5 4.5h11.2L19.5 7.8V18a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V6A1.5 1.5 0 0 1 6 4.5z"/><path d="M8 4.5v4.2h6.5V4.5"/><rect x="7.5" y="12.8" width="9" height="6.7" rx="1"/>',
    extensions: '<path d="M4.5 10.5h5v-5h-5z"/><path d="M4.5 18.5h5v-5h-5z"/><path d="M12.5 18.5h5v-5h-5z"/><path d="M15 4.5v6M12 7.5h6"/>',
    download: '<path d="M12 4.5v11"/><path d="M7.5 11.5 12 16l4.5-4.5"/><path d="M5 19.5h14"/>',
    phone: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>',
    logo: '<path d="M8.5 7.5 3.5 12l5 4.5"/><path d="M15.5 7.5l5 4.5-5 4.5"/><path d="M13.4 5.5l-2.8 13"/>',
    menu: '<path d="M4 6.5h16M4 12h16M4 17.5h16"/>',
    more: '<circle cx="12" cy="5.5" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="18.5" r="1.5" fill="currentColor" stroke="none"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    back: '<path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/>',
    send: '<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>',
    'chevron-right': '<path d="M9.5 5.5 16 12l-6.5 6.5"/>',
    'chevron-down': '<path d="M5.5 9.5 12 16l6.5-6.5"/>',
    play: '<path d="M7.5 4.8v14.4a.6.6 0 0 0 .9.5l11.4-7.2a.6.6 0 0 0 0-1L8.4 4.3a.6.6 0 0 0-.9.5z" fill="currentColor"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2.2" fill="currentColor"/>',
    refresh: '<path d="M19.5 11A7.5 7.5 0 1 0 17.3 16.8"/><path d="M19.8 4.8V11h-6.2"/>',
    explorer: '<path d="M14 3.5H8.5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8z"/><path d="M14 3.5V8h4.5"/><path d="M4.5 7.5v12a2 2 0 0 0 2 2H15"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.2"/><path d="M15.2 15.2 20.5 20.5"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7"/><path d="M19 12h2.6M5 12H2.4M12 19v2.6M12 5V2.4M16.95 16.95l1.84 1.84M7.05 16.95l-1.84 1.84M7.05 7.05 5.21 5.21M16.95 7.05l1.84-1.84"/>',
    'new-file': '<path d="M14 3.5H7.5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V8z"/><path d="M14 3.5V8h4.5"/><path d="M12 11.5v5M9.5 14h5"/>',
    'new-folder': '<path d="M3.5 7A1.5 1.5 0 0 1 5 5.5h4l2 2.5h8a1.5 1.5 0 0 1 1.5 1.5v8A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5z"/><path d="M12 11.2v4.6M9.7 13.5h4.6"/>',
    folder: '<path d="M3.5 7A1.5 1.5 0 0 1 5 5.5h4l2 2.5h8a1.5 1.5 0 0 1 1.5 1.5v8A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5z"/>',
    trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.5h5V7"/><path d="M6.5 7l.9 12.5h9.2L17.5 7"/><path d="M10.2 11v5M13.8 11v5"/>',
    edit: '<path d="M4.5 19.5l1-4.4L16.6 4a2.1 2.1 0 0 1 3 3L8.4 18.1z"/><path d="M14.6 6l3.4 3.4"/>',
    undo: '<path d="M9 5 4.5 9.5 9 14"/><path d="M4.5 9.5H14a5.5 5.5 0 0 1 0 11h-3"/>',
    redo: '<path d="M15 5l4.5 4.5L15 14"/><path d="M19.5 9.5H10a5.5 5.5 0 0 0 0 11h3"/>',
    export: '<path d="M12 4v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/>',
    import: '<path d="M12 15V4"/><path d="M7.5 8.5 12 4l4.5 4.5"/><path d="M5 19.5h14"/>',
    terminal: '<rect x="3" y="4.5" width="18" height="15" rx="2.2"/><path d="M7.2 9.5 10.2 12l-3 2.5"/><path d="M12.5 15h4.3"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.6 2.4 2.6 14.6 0 17M12 3.5c-2.6 2.4-2.6 14.6 0 17"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5"/><circle cx="12" cy="7.8" r=".9" fill="currentColor" stroke="none"/>',
    layout: '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M9.5 4.5v15"/>',
    code: '<path d="M8.5 7.5 3.5 12l5 4.5"/><path d="M15.5 7.5l5 4.5-5 4.5"/>',
    save: '<path d="M5 5.5A1.5 1.5 0 0 1 6.5 4H16l3.5 3.5V18a1.5 1.5 0 0 1-1.5 1.5H6.5A1.5 1.5 0 0 1 5 18z"/><path d="M8 4v4.5h6.5V4"/><rect x="8" y="13" width="8" height="6.5" rx=".8"/>',
    keyboard: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M10.5 10h.01M14 10h.01M17.5 10h.01M7 14h10"/>',
    bug: '<rect x="8" y="8" width="8" height="10" rx="4"/><path d="M12 8V6M9 6.5l1.5 1.5M15 6.5 13.5 8M4.5 12H8M16 12h3.5M5.5 18l3-1.5M18.5 18l-3-1.5M5.5 7l3 2M18.5 7l-3 2"/>',
    warning: '<path d="M12 4.2 21 19.5H3z"/><path d="M12 10v4.5"/><circle cx="12" cy="17" r=".9" fill="currentColor" stroke="none"/>',
  };

  // ---- Ficheiros (16x16, coloridos) ----
  const F = (body) => body;
  const FILE = {
    html: F('<path d="M5.6 4.6 2 8l3.6 3.4M10.4 4.6 14 8l-3.6 3.4" fill="none" stroke="#e37933" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>'),
    css: F('<path d="M6.2 2.8 5.2 13.2M10.8 2.8 9.8 13.2M3.2 6h10M2.8 10h10" fill="none" stroke="#42a5f5" stroke-width="1.6" stroke-linecap="round"/>'),
    js: F('<rect x="1.8" y="1.8" width="12.4" height="12.4" rx="2.4" fill="#f1e05a"/><path d="M6.4 6.3v4.1c0 .9-.5 1.4-1.4 1.4-.5 0-.9-.2-1.2-.5M8.9 11c.4.5.9.7 1.5.7.8 0 1.3-.4 1.3-1 0-1.4-2.7-.8-2.7-2.3 0-.6.5-1.1 1.4-1.1.5 0 .9.1 1.2.4" fill="none" stroke="#2b2b2b" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'),
    ts: F('<rect x="1.8" y="1.8" width="12.4" height="12.4" rx="2.4" fill="#3178c6"/><path d="M3.6 7h4M5.6 7v5M9 11.3c.4.4.9.6 1.4.6.8 0 1.3-.4 1.3-1 0-1.3-2.6-.8-2.6-2.1 0-.6.5-1 1.3-1 .5 0 .9.1 1.2.4" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'),
    json: F('<path d="M6 2.8c-1.4 0-1.8.8-1.8 1.8v1.4c0 .8-.5 1.4-1.4 2 .9.6 1.4 1.2 1.4 2v1.4c0 1 .4 1.8 1.8 1.8M10 2.8c1.4 0 1.8.8 1.8 1.8v1.4c0 .8.5 1.4 1.4 2-.9.6-1.4 1.2-1.4 2v1.4c0 1-.4 1.8-1.8 1.8" fill="none" stroke="#cbcb41" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'),
    py: F('<rect x="1.8" y="1.8" width="8.2" height="8.2" rx="2.6" fill="#3776ab"/><rect x="6" y="6" width="8.2" height="8.2" rx="2.6" fill="#ffd43b" stroke="#1e1e1e" stroke-width="1"/><circle cx="4.6" cy="4.4" r=".8" fill="#fff"/><circle cx="11.4" cy="11.6" r=".8" fill="#3b3b3b"/>'),
    java: F('<path d="M3 7.2h8v3a3.4 3.4 0 0 1-3.4 3.4H6.4A3.4 3.4 0 0 1 3 10.2z" fill="#e76f51"/><path d="M11 8.2h1a1.5 1.5 0 0 1 0 3h-1" fill="none" stroke="#e76f51" stroke-width="1.3" stroke-linecap="round"/><path d="M5.2 2.2c-.9.9.9 1.7 0 2.7M8 2.2c-.9.9.9 1.7 0 2.7" fill="none" stroke="#5fa8d3" stroke-width="1.2" stroke-linecap="round"/>'),
    dart: F('<path d="M2.4 7.6 7.6 2.4h5.2L9.2 6l3.6 3.6v3.2H9.6L2.4 7.6z" fill="#40c4ff"/><path d="M5.2 12.8 2.4 10V7.6l7.2 5.2z" fill="#0175c2"/>'),
    md: F('<rect x="1.6" y="3.4" width="12.8" height="9.2" rx="1.8" fill="none" stroke="#519aba" stroke-width="1.2"/><path d="M4 10.4V5.8l1.8 2.2 1.8-2.2v4.6M10.6 5.8v3.6M9.2 8.2l1.4 1.5 1.4-1.5" fill="none" stroke="#519aba" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'),
    yaml: F('<path d="M3 4h4M3 8h10M3 12h6" fill="none" stroke="#c586c0" stroke-width="1.6" stroke-linecap="round"/><circle cx="11.5" cy="4" r="1.2" fill="#c586c0"/>'),
    image: F('<rect x="1.8" y="2.8" width="12.4" height="10.4" rx="2" fill="none" stroke="#a074c4" stroke-width="1.3"/><circle cx="5.6" cy="6.2" r="1.2" fill="#a074c4"/><path d="m2.6 12 3.6-3.6 2.4 2.4 1.8-1.8L13.4 12" fill="none" stroke="#a074c4" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round"/>'),
    gradle: F('<path d="M3 11.6c-1-1 0-3.4 2.2-3.8l1.2-3.4c.4-1 1.6-1.4 2.4-.6 2.2.2 3.8 1.6 3.8 3.4 0 1.2-.8 2-2 2.2" fill="none" stroke="#7bb6c6" stroke-width="1.4" stroke-linecap="round"/><circle cx="10.6" cy="11.6" r="1.5" fill="none" stroke="#7bb6c6" stroke-width="1.3"/>'),
    text: F('<path d="M9.6 1.8H4.6A1.4 1.4 0 0 0 3.2 3.2v9.6a1.4 1.4 0 0 0 1.4 1.4h6.8a1.4 1.4 0 0 0 1.4-1.4V5.6z" fill="none" stroke="#9d9d9d" stroke-width="1.2" stroke-linejoin="round"/><path d="M9.6 1.8v3.8h3.2M5.6 8.4h4.8M5.6 10.8h3.2" fill="none" stroke="#9d9d9d" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'),
    folder: F('<path d="M1.8 4.2A1.2 1.2 0 0 1 3 3h3l1.4 1.6H13a1.2 1.2 0 0 1 1.2 1.2v6A1.2 1.2 0 0 1 13 12.2H3a1.2 1.2 0 0 1-1.2-1.2z" fill="#c09553"/>'),
    'folder-open': F('<path d="M1.8 4.2A1.2 1.2 0 0 1 3 3h3l1.4 1.6H12a1.2 1.2 0 0 1 1.2 1.2v1.2" fill="none" stroke="#dcb67a" stroke-width="1.3" stroke-linejoin="round"/><path d="M2.4 12.4 4 7.6h10.2l-1.6 4.8a1 1 0 0 1-1 .8H3.4a1 1 0 0 1-1-.8z" fill="#dcb67a"/>'),
  };

  const EXT = {
    html: 'html', htm: 'html', xml: 'html', svg: 'image',
    css: 'css', scss: 'css',
    js: 'js', mjs: 'js', cjs: 'js', jsx: 'js', ts: 'ts', tsx: 'ts',
    json: 'json', py: 'py', java: 'java', dart: 'dart',
    md: 'md', markdown: 'md', yml: 'yaml', yaml: 'yaml', toml: 'yaml',
    png: 'image', jpg: 'image', jpeg: 'image', gif: 'image', webp: 'image', ico: 'image',
    gradle: 'gradle', kts: 'gradle',
  };

  function wrapUI(name, size) {
    const body = UI[name] || '';
    return '<svg class="ic" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  function wrapFile(name, size) {
    const body = FILE[name] || FILE.text;
    return '<svg class="ic ic-file" width="' + size + '" height="' + size + '" viewBox="0 0 16 16" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  window.CVIcons = {
    /** Ícone de interface por nome. */
    svg(name, size) { return wrapUI(name, size || 20); },
    /** Ícone de ficheiro/pasta; `kind` = nome do ficheiro, ou 'folder' / 'folder-open'. */
    file(nameOrKind, size) {
      if (nameOrKind === 'folder' || nameOrKind === 'folder-open') return wrapFile(nameOrKind, size || 16);
      const m = /\.([A-Za-z0-9]+)$/.exec(nameOrKind || '');
      const key = m ? EXT[m[1].toLowerCase()] : null;
      return wrapFile(key || 'text', size || 16);
    },
    has(name) { return Object.prototype.hasOwnProperty.call(UI, name); },
    names() { return Object.keys(UI); },
    fileNames() { return Object.keys(FILE); },
    /** Preenche todos os elementos [data-icon] dentro de `root`. */
    hydrate(root) {
      (root || document).querySelectorAll('[data-icon]').forEach((e) => {
        const n = e.getAttribute('data-icon');
        const size = parseInt(e.getAttribute('data-size') || '20', 10);
        e.innerHTML = n.indexOf('file:') === 0 ? wrapFile(n.slice(5), size) : wrapUI(n, size);
        e.removeAttribute('data-icon');
      });
    },
  };
})();
