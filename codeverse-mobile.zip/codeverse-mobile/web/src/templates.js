// Modelos de projeto: só a estrutura (sem código de exemplo). Cada modelo: { id, name, desc, main, files: { caminho: conteúdo } }
window.CV_TEMPLATES = [
  {
    id: "web",
    name: "Web (HTML + CSS + JS)",
    desc: "Executa offline com pré-visualização",
    main: "index.html",
    files: {
          "index.html": "<!DOCTYPE html>\n<html lang=\"pt\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>Novo projeto</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
          "style.css": "/* Estilos */\n",
          "script.js": "// Código JavaScript\n"
    }
  },
  {
    id: "python",
    name: "Python",
    desc: "Executa offline (Pyodide)",
    main: "main.py",
    files: {
          "main.py": "def main():\n    pass\n\n\nif __name__ == \"__main__\":\n    main()\n"
    }
  },
  {
    id: "java",
    name: "Java",
    desc: "Executa offline (compilador local)",
    main: "Main.java",
    files: {
          "Main.java": "public class Main {\n    public static void main(String[] args) {\n        \n    }\n}\n"
    }
  },
  {
    id: "dart",
    name: "Dart (consola)",
    desc: "Executa online (precisa de internet)",
    main: "main.dart",
    files: {
          "main.dart": "void main() {\n  \n}\n"
    }
  },
  {
    id: "flutter",
    name: "Flutter (editar + compilar no GitHub)",
    desc: "Compila o APK na nuvem com o GitHub Actions",
    main: "lib/main.dart",
    files: {
          "pubspec.yaml": "name: codeverse_app\ndescription: Projeto Flutter criado no CodeVerse\npublish_to: 'none'\nversion: 1.0.0+1\n\nenvironment:\n  sdk: '>=3.0.0 <4.0.0'\n\ndependencies:\n  flutter:\n    sdk: flutter\n\nflutter:\n  uses-material-design: true\n",
          "lib/main.dart": "import 'package:flutter/material.dart';\n\nvoid main() => runApp(const MyApp());\n\nclass MyApp extends StatelessWidget {\n  const MyApp({super.key});\n\n  @override\n  Widget build(BuildContext context) {\n    return const MaterialApp(\n      home: Scaffold(),\n    );\n  }\n}\n",
          "README.md": "# Projeto Flutter\n\nO Flutter não corre no telemóvel: toca em Executar (ou menu → Compilar APK) para o\nCodeVerse compilar o APK no GitHub Actions e abrir o instalador.\n"
    }
  },
  {
    id: "empty",
    name: "Projeto vazio",
    desc: "Só um README",
    main: "README.md",
    files: {
          "README.md": "# Novo projeto\n"
    }
  }
];
