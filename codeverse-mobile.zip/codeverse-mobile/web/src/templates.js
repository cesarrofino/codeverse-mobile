// Modelos de projeto. Cada modelo: { id, name, desc, main, files: { caminho: conteúdo } }
window.CV_TEMPLATES = [
  {
    id: 'web',
    name: 'Web (HTML + CSS + JS)',
    desc: 'Executa offline com pré-visualização',
    main: 'index.html',
    files: {
      'index.html': [
        '<!DOCTYPE html>',
        '<html lang="pt">',
        '<head>',
        '  <meta charset="UTF-8">',
        '  <meta name="viewport" content="width=device-width, initial-scale=1.0">',
        '  <title>O meu site</title>',
        '  <link rel="stylesheet" href="style.css">',
        '</head>',
        '<body>',
        '  <h1>Olá, CodeVerse!</h1>',
        '  <button id="btn">Clica-me</button>',
        '  <p id="out"></p>',
        '  <script src="script.js"></script>',
        '</body>',
        '</html>',
        ''
      ].join('\n'),
      'style.css': [
        'body {',
        '  font-family: system-ui, sans-serif;',
        '  background: #1e1e1e;',
        '  color: #d4d4d4;',
        '  text-align: center;',
        '  padding: 2rem;',
        '}',
        'button {',
        '  padding: 0.7rem 1.2rem;',
        '  border: 0;',
        '  border-radius: 6px;',
        '  background: #007acc;',
        '  color: white;',
        '  font-size: 1rem;',
        '}',
        ''
      ].join('\n'),
      'script.js': [
        'let cliques = 0;',
        "document.getElementById('btn').addEventListener('click', () => {",
        '  cliques++;',
        "  document.getElementById('out').textContent = 'Cliques: ' + cliques;",
        "  console.log('Clique número', cliques);",
        '});',
        ''
      ].join('\n')
    }
  },
  {
    id: 'python',
    name: 'Python',
    desc: 'Executa offline (Pyodide)',
    main: 'main.py',
    files: {
      'main.py': [
        'def fibonacci(n):',
        '    a, b = 0, 1',
        '    for _ in range(n):',
        '        yield a',
        '        a, b = b, a + b',
        '',
        'print("Olá, CodeVerse!")',
        'print("Fibonacci:", list(fibonacci(10)))',
        ''
      ].join('\n')
    }
  },
  {
    id: 'java',
    name: 'Java',
    desc: 'Executa offline (compilador local)',
    main: 'Main.java',
    files: {
      'Main.java': [
        'public class Main {',
        '    public static void main(String[] args) {',
        '        System.out.println("Olá, CodeVerse!");',
        '        int soma = 0;',
        '        for (int i = 1; i <= 10; i++) {',
        '            soma += i;',
        '        }',
        '        System.out.println("Soma 1..10 = " + soma);',
        '    }',
        '}',
        ''
      ].join('\n')
    }
  },
  {
    id: 'dart',
    name: 'Dart (consola)',
    desc: 'Executa online (precisa de internet)',
    main: 'main.dart',
    files: {
      'main.dart': [
        'void main() {',
        "  print('Olá, CodeVerse!');",
        '  var numeros = [1, 2, 3, 4, 5];',
        "  print('Soma: ' + numeros.reduce((a, b) => a + b).toString());",
        '}',
        ''
      ].join('\n')
    }
  },
  {
    id: 'flutter',
    name: 'Flutter (editar + compilar no GitHub)',
    desc: 'Não executa no telemóvel; inclui workflow para gerar APK',
    main: 'lib/main.dart',
    files: {
      'pubspec.yaml': [
        'name: codeverse_app',
        'description: Projeto Flutter criado no CodeVerse',
        "publish_to: 'none'",
        'version: 1.0.0+1',
        '',
        'environment:',
        "  sdk: '>=3.0.0 <4.0.0'",
        '',
        'dependencies:',
        '  flutter:',
        '    sdk: flutter',
        '',
        'flutter:',
        '  uses-material-design: true',
        ''
      ].join('\n'),
      'lib/main.dart': [
        "import 'package:flutter/material.dart';",
        '',
        'void main() => runApp(const MyApp());',
        '',
        'class MyApp extends StatelessWidget {',
        '  const MyApp({super.key});',
        '',
        '  @override',
        '  Widget build(BuildContext context) {',
        '    return MaterialApp(',
        "      title: 'CodeVerse Flutter',",
        '      theme: ThemeData.dark(useMaterial3: true),',
        '      home: const Counter(),',
        '    );',
        '  }',
        '}',
        '',
        'class Counter extends StatefulWidget {',
        '  const Counter({super.key});',
        '',
        '  @override',
        '  State<Counter> createState() => _CounterState();',
        '}',
        '',
        'class _CounterState extends State<Counter> {',
        '  int _count = 0;',
        '',
        '  @override',
        '  Widget build(BuildContext context) {',
        '    return Scaffold(',
        "      appBar: AppBar(title: const Text('Olá, Flutter!')),",
        '      body: Center(',
        "        child: Text('Cliques: ' + _count.toString(), style: const TextStyle(fontSize: 28)),",
        '      ),',
        '      floatingActionButton: FloatingActionButton(',
        '        onPressed: () => setState(() => _count++),',
        '        child: const Icon(Icons.add),',
        '      ),',
        '    );',
        '  }',
        '}',
        ''
      ].join('\n'),
      'README.md': [
        '# Projeto Flutter',
        '',
        'O Flutter SDK completo não corre dentro do Android. Edita o código aqui e toca em',
        'Executar (ou menu → Compilar APK): o CodeVerse envia o projeto para o teu repositório',
        'do GitHub, compila o APK com o GitHub Actions e abre o instalador.',
        ''
      ].join('\n')
    }
  },
  {
    id: "game-snake",
    name: "Jogo: Snake (Python)",
    desc: "Mini-jogo com a biblioteca cvgame",
    main: "main.py",
    files: {
          "main.py": "# Snake - setas (ou botoes no ecra) para virar. Toca no ecra / espaco para recomecar.\nfrom cvgame import Game, random\n\nCELL = 20\nCOLS, ROWS = 18, 28\nTOP = 40\ngame = Game(COLS * CELL, ROWS * CELL + TOP, \"Snake\")\n\n\ndef new_food():\n    while True:\n        p = (random.randrange(COLS), random.randrange(ROWS))\n        if p not in snake:\n            return p\n\n\ndef reset():\n    global snake, direction, wanted, food, score, timer, dead\n    snake = [(9, 14), (8, 14), (7, 14)]\n    direction = wanted = (1, 0)\n    score = 0\n    timer = 0.0\n    dead = False\n    food = new_food()\n\n\nsnake = []\nreset()\nbest = 0\n\n\n@game.update\ndef update(dt):\n    global wanted, direction, food, score, timer, dead, best\n    if dead:\n        if game.pressed(\"space\") or game.tap():\n            reset()\n        return\n    if game.key(\"left\") and direction != (1, 0):\n        wanted = (-1, 0)\n    elif game.key(\"right\") and direction != (-1, 0):\n        wanted = (1, 0)\n    elif game.key(\"up\") and direction != (0, 1):\n        wanted = (0, -1)\n    elif game.key(\"down\") and direction != (0, -1):\n        wanted = (0, 1)\n    timer += dt\n    step = max(0.06, 0.16 - score * 0.004)\n    if timer < step:\n        return\n    timer = 0.0\n    direction = wanted\n    head = (snake[0][0] + direction[0], snake[0][1] + direction[1])\n    if not (0 <= head[0] < COLS and 0 <= head[1] < ROWS) or head in snake:\n        dead = True\n        best = max(best, score)\n        game.beep(120, 300)\n        return\n    snake.insert(0, head)\n    if head == food:\n        score += 1\n        food = new_food()\n        game.beep(660, 60)\n    else:\n        snake.pop()\n\n\n@game.draw\ndef draw():\n    game.clear(\"#0f141d\")\n    game.text(\"Pontos: %d   Recorde: %d\" % (score, best), 10, 10, \"white\", 18)\n    game.rect(0, TOP, COLS * CELL, ROWS * CELL, \"#161d2b\")\n    game.rect(food[0] * CELL + 2, TOP + food[1] * CELL + 2, CELL - 4, CELL - 4, \"#ff5c5c\")\n    for i, (x, y) in enumerate(snake):\n        game.rect(x * CELL + 1, TOP + y * CELL + 1, CELL - 2, CELL - 2, \"#7ee787\" if i else \"#2ea043\")\n    if dead:\n        game.text(\"Fim de jogo\", COLS * CELL / 2, 250, \"white\", 32, \"center\")\n        game.text(\"Toca para recomecar\", COLS * CELL / 2, 295, \"#9aa4b2\", 18, \"center\")\n\n\ngame.run()\n"
    }
  },
  {
    id: "game-flappy",
    name: "Jogo: Flappy (Python)",
    desc: "Toca para saltar entre os canos",
    main: "main.py",
    files: {
          "main.py": "# Flappy - toca no ecra (ou espaco / botao A) para saltar.\nfrom cvgame import Game, collide, random\n\nW, H = 360, 640\ngame = Game(W, H, \"Flappy\")\n\nGAP = 170\nSPEED = 130\nbird_x = 90\n\n\ndef reset():\n    global y, vy, pipes, score, dead, spawn\n    y, vy = H / 2, 0.0\n    pipes = []\n    score = 0\n    dead = False\n    spawn = 0.0\n\n\npipes = []\nreset()\nbest = 0\n\n\ndef flap():\n    global vy\n    vy = -330\n    game.beep(520, 40)\n\n\n@game.update\ndef update(dt):\n    global y, vy, score, dead, spawn, best\n    jump = game.pressed(\"space\") or game.pressed(\"up\") or game.tap()\n    if dead:\n        if jump:\n            reset()\n        return\n    if jump:\n        flap()\n    vy += 900 * dt\n    y += vy * dt\n    spawn -= dt\n    if spawn <= 0:\n        pipes.append({\"x\": W + 10, \"gap\": random.randint(150, H - 150 - GAP), \"passed\": False})\n        spawn = 1.7\n    for p in pipes:\n        p[\"x\"] -= SPEED * dt\n        if not p[\"passed\"] and p[\"x\"] + 50 < bird_x:\n            p[\"passed\"] = True\n            score += 1\n            game.beep(880, 50)\n        bird = (bird_x - 14, y - 14, 28, 28)\n        if collide(bird, (p[\"x\"], 0, 50, p[\"gap\"])) or collide(bird, (p[\"x\"], p[\"gap\"] + GAP, 50, H)):\n            dead = True\n    pipes[:] = [p for p in pipes if p[\"x\"] > -60]\n    if y < 0 or y > H:\n        dead = True\n    if dead:\n        best = max(best, score)\n        game.beep(120, 300)\n\n\n@game.draw\ndef draw():\n    game.clear(\"#5ec8f2\")\n    for p in pipes:\n        game.rect(p[\"x\"], 0, 50, p[\"gap\"], \"#3fa34d\")\n        game.rect(p[\"x\"], p[\"gap\"] + GAP, 50, H, \"#3fa34d\")\n    game.circle(bird_x, y, 14, \"#ffd23f\")\n    game.circle(bird_x + 6, y - 4, 3, \"black\")\n    game.text(str(score), W / 2, 30, \"white\", 48, \"center\")\n    if dead:\n        game.text(\"Fim de jogo\", W / 2, 250, \"white\", 34, \"center\")\n        game.text(\"Recorde: %d\" % best, W / 2, 300, \"white\", 20, \"center\")\n        game.text(\"Toca para recomecar\", W / 2, 335, \"white\", 18, \"center\")\n\n\ngame.run()\n"
    }
  },
  {
    id: "game-pong",
    name: "Jogo: Pong (Python)",
    desc: "Contra o computador, com o dedo ou as setas",
    main: "main.py",
    files: {
          "main.py": "# Pong contra o computador - setas, ou arrasta o dedo no ecra.\nfrom cvgame import Game, collide, clamp, random\n\nW, H = 360, 600\ngame = Game(W, H, \"Pong\")\nPW, PH = 70, 12\n\n\ndef serve(direction):\n    global bx, by, vx, vy\n    bx, by = W / 2, H / 2\n    vx, vy = random.choice((-140, 140)), 240 * direction\n\n\npx = ax = W / 2 - PW / 2\nps = as_ = 0\nserve(1)\n\n\n@game.update\ndef update(dt):\n    global px, ax, bx, by, vx, vy, ps, as_\n    if game.key(\"left\"):\n        px -= 320 * dt\n    if game.key(\"right\"):\n        px += 320 * dt\n    if game.touching:\n        px = game.pointer[0] - PW / 2\n    px = clamp(px, 0, W - PW)\n    target = bx - PW / 2\n    ax += clamp(target - ax, -210 * dt, 210 * dt)\n    ax = clamp(ax, 0, W - PW)\n    bx += vx * dt\n    by += vy * dt\n    if bx < 6 or bx > W - 6:\n        vx = -vx\n        bx = clamp(bx, 6, W - 6)\n    ball = (bx - 6, by - 6, 12, 12)\n    if vy > 0 and collide(ball, (px, H - 40, PW, PH)):\n        vy = -abs(vy) * 1.05\n        vx += (bx - (px + PW / 2)) * 3\n        game.beep(440, 40)\n    if vy < 0 and collide(ball, (ax, 28, PW, PH)):\n        vy = abs(vy) * 1.05\n        vx += (bx - (ax + PW / 2)) * 3\n        game.beep(330, 40)\n    if by > H:\n        as_ += 1\n        serve(-1)\n        game.beep(120, 200)\n    elif by < 0:\n        ps += 1\n        serve(1)\n        game.beep(880, 120)\n\n\n@game.draw\ndef draw():\n    game.clear(\"#0f141d\")\n    for i in range(0, W, 30):\n        game.rect(i, H / 2 - 1, 16, 2, \"#2a3446\")\n    game.rect(ax, 28, PW, PH, \"#ff7b72\")\n    game.rect(px, H - 40, PW, PH, \"#7ee787\")\n    game.circle(bx, by, 6, \"white\")\n    game.text(str(as_), 14, H / 2 - 40, \"#ff7b72\", 28)\n    game.text(str(ps), 14, H / 2 + 12, \"#7ee787\", 28)\n\n\ngame.run()\n"
    }
  },
  {
    id: "game-js",
    name: "Jogo: Esquiva (JavaScript)",
    desc: "Jogo em canvas que corre no navegador",
    main: "index.html",
    files: {
          "game.js": "// Esquiva: move o jogador com o dedo ou as setas e foge dos blocos.\nconst cv = document.getElementById('c');\nconst ctx = cv.getContext('2d');\nconst W = cv.width, H = cv.height;\n\nlet player, blocks, score, best = 0, dead, spawn, last = performance.now();\nconst keys = {};\n\nfunction reset() {\n  player = { x: W / 2, y: H - 60, r: 14 };\n  blocks = []; score = 0; dead = false; spawn = 0;\n}\nreset();\n\nfunction pointerX(e) {\n  const r = cv.getBoundingClientRect();\n  return (e.clientX - r.left) / r.width * W;\n}\ncv.addEventListener('pointerdown', (e) => { if (dead) reset(); player.x = pointerX(e); });\ncv.addEventListener('pointermove', (e) => { if (e.buttons || e.pointerType === 'touch') player.x = pointerX(e); });\naddEventListener('keydown', (e) => { keys[e.key] = true; if (dead && e.key === ' ') reset(); });\naddEventListener('keyup', (e) => { keys[e.key] = false; });\n\nfunction update(dt) {\n  if (dead) return;\n  if (keys.ArrowLeft) player.x -= 300 * dt;\n  if (keys.ArrowRight) player.x += 300 * dt;\n  player.x = Math.max(player.r, Math.min(W - player.r, player.x));\n  score += dt;\n  spawn -= dt;\n  if (spawn <= 0) {\n    const w = 30 + Math.random() * 60;\n    blocks.push({ x: Math.random() * (W - w), y: -30, w, h: 24, v: 150 + score * 8 });\n    spawn = Math.max(0.25, 0.8 - score * 0.012);\n  }\n  for (const b of blocks) {\n    b.y += b.v * dt;\n    const nx = Math.max(b.x, Math.min(player.x, b.x + b.w));\n    const ny = Math.max(b.y, Math.min(player.y, b.y + b.h));\n    if (Math.hypot(player.x - nx, player.y - ny) < player.r) { dead = true; best = Math.max(best, score); }\n  }\n  blocks = blocks.filter((b) => b.y < H + 40);\n}\n\nfunction draw() {\n  ctx.clearRect(0, 0, W, H);\n  ctx.fillStyle = '#ff5c5c';\n  for (const b of blocks) ctx.fillRect(b.x, b.y, b.w, b.h);\n  ctx.fillStyle = '#7ee787';\n  ctx.beginPath(); ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2); ctx.fill();\n  ctx.fillStyle = '#fff'; ctx.font = 'bold 20px system-ui'; ctx.textAlign = 'left';\n  ctx.fillText('Pontos: ' + Math.floor(score) + '   Recorde: ' + Math.floor(best), 10, 26);\n  if (dead) {\n    ctx.textAlign = 'center'; ctx.font = 'bold 32px system-ui';\n    ctx.fillText('Fim de jogo', W / 2, H / 2 - 10);\n    ctx.font = '18px system-ui'; ctx.fillText('Toca para recomeçar', W / 2, H / 2 + 24);\n  }\n}\n\nfunction loop(t) {\n  const dt = Math.min(0.05, (t - last) / 1000); last = t;\n  update(dt); draw();\n  requestAnimationFrame(loop);\n}\nrequestAnimationFrame(loop);\n",
          "index.html": "<!DOCTYPE html>\n<html lang=\"pt\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\">\n  <title>Esquiva</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n  <canvas id=\"c\" width=\"360\" height=\"560\"></canvas>\n  <p>Arrasta o dedo para mover. Foge dos blocos vermelhos!</p>\n  <script src=\"game.js\"></script>\n</body>\n</html>\n",
          "style.css": "body { margin: 0; background: #0f141d; color: #9aa4b2; font-family: system-ui, sans-serif; text-align: center; }\ncanvas { display: block; margin: 0 auto; max-width: 100%; max-height: 82vh; touch-action: none; background: #161d2b; }\np { margin: 8px; font-size: 14px; }\n"
    }
  },
  {
    id: "site-portfolio",
    name: "Site: Portfólio",
    desc: "Página responsiva com projetos e contacto",
    main: "index.html",
    files: {
          "index.html": "<!DOCTYPE html>\n<html lang=\"pt\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>O meu portfólio</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n  <header class=\"hero\">\n    <div class=\"avatar\">A</div>\n    <h1>Olá, sou o <span>Teu Nome</span></h1>\n    <p>Programador apaixonado por criar apps e sites.</p>\n    <a class=\"btn\" href=\"#projetos\">Ver projetos</a>\n  </header>\n\n  <main>\n    <section id=\"projetos\">\n      <h2>Projetos</h2>\n      <div class=\"cards\" id=\"cards\"></div>\n    </section>\n\n    <section id=\"contacto\">\n      <h2>Contacto</h2>\n      <form id=\"form\">\n        <input id=\"nome\" placeholder=\"O teu nome\" required>\n        <textarea id=\"msg\" placeholder=\"Mensagem\" rows=\"3\" required></textarea>\n        <button class=\"btn\" type=\"submit\">Enviar</button>\n        <p id=\"resp\"></p>\n      </form>\n    </section>\n  </main>\n\n  <footer>Feito com CodeVerse</footer>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
          "script.js": "// Os teus projetos: edita esta lista.\nconst projetos = [\n  { titulo: 'App de notas', texto: 'Guarda ideias rápidas no telemóvel.' },\n  { titulo: 'Jogo de cobrinha', texto: 'Feito em Python com o CodeVerse.' },\n  { titulo: 'Loja online', texto: 'Site responsivo com HTML, CSS e JS.' },\n];\n\nconst cards = document.getElementById('cards');\nfor (const p of projetos) {\n  const el = document.createElement('div');\n  el.className = 'card';\n  el.innerHTML = '<h3></h3><p></p>';\n  el.querySelector('h3').textContent = p.titulo;\n  el.querySelector('p').textContent = p.texto;\n  cards.appendChild(el);\n}\n\ndocument.getElementById('form').addEventListener('submit', (e) => {\n  e.preventDefault();\n  const nome = document.getElementById('nome').value.trim();\n  document.getElementById('resp').textContent = 'Obrigado, ' + nome + '! Mensagem recebida.';\n  e.target.reset();\n});\n",
          "style.css": ":root { --bg: #0f141d; --card: #161d2b; --fg: #e6edf3; --muted: #9aa4b2; --accent: #4cc2ff; }\n* { box-sizing: border-box; }\nbody { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--fg); line-height: 1.5; }\n.hero { text-align: center; padding: 56px 20px 40px; background: linear-gradient(160deg, #16233a, var(--bg)); }\n.avatar { width: 84px; height: 84px; margin: 0 auto 14px; border-radius: 50%; background: var(--accent); color: #05202f; display: grid; place-items: center; font-size: 36px; font-weight: 800; }\n.hero h1 { margin: 0 0 8px; font-size: 1.8rem; }\n.hero h1 span { color: var(--accent); }\n.hero p { color: var(--muted); margin: 0 0 22px; }\n.btn { display: inline-block; padding: 12px 22px; border: 0; border-radius: 10px; background: var(--accent); color: #05202f; font-weight: 700; font-size: 1rem; text-decoration: none; }\nmain { max-width: 720px; margin: 0 auto; padding: 0 18px; }\nh2 { margin: 36px 0 14px; }\n.cards { display: grid; gap: 14px; }\n.card { background: var(--card); border-radius: 14px; padding: 16px; border: 1px solid #243149; }\n.card h3 { margin: 0 0 6px; }\n.card p { margin: 0; color: var(--muted); }\nform { display: grid; gap: 10px; }\ninput, textarea { width: 100%; padding: 12px; border-radius: 10px; border: 1px solid #243149; background: var(--card); color: var(--fg); font: inherit; }\n#resp { color: var(--accent); margin: 0; min-height: 1.4em; }\nfooter { text-align: center; color: var(--muted); padding: 40px 0 28px; }\n"
    }
  },
  {
    id: 'empty',
    name: 'Projeto vazio',
    desc: 'Só um README',
    main: 'README.md',
    files: { 'README.md': '# Novo projeto\n' }
  }
];
