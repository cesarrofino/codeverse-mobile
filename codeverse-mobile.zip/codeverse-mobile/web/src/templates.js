// Modelos de projeto. Cada modelo: { id, name, desc, main, files: { caminho: conteúdo } }
window.CV_TEMPLATES = [
  {
    id: 'web',
    name: 'Web (HTML + CSS + JS)',
    desc: 'Executa offline com pré-visualização',
    main: 'index.html',
    files: {
      'index.html': [
        '<!DOCTYPE html>',
        '<html lang="pt">',
        '<head>',
        '  <meta charset="UTF-8">',
        '  <meta name="viewport" content="width=device-width, initial-scale=1.0">',
        '  <title>O meu site</title>',
        '  <link rel="stylesheet" href="style.css">',
        '</head>',
        '<body>',
        '  <h1>Olá, CodeVerse!</h1>',
        '  <button id="btn">Clica-me</button>',
        '  <p id="out"></p>',
        '  <script src="script.js"></script>',
        '</body>',
        '</html>',
        ''
      ].join('\n'),
      'style.css': [
        'body {',
        '  font-family: system-ui, sans-serif;',
        '  background: #1e1e1e;',
        '  color: #d4d4d4;',
        '  text-align: center;',
        '  padding: 2rem;',
        '}',
        'button {',
        '  padding: 0.7rem 1.2rem;',
        '  border: 0;',
        '  border-radius: 6px;',
        '  background: #007acc;',
        '  color: white;',
        '  font-size: 1rem;',
        '}',
        ''
      ].join('\n'),
      'script.js': [
        'let cliques = 0;',
        "document.getElementById('btn').addEventListener('click', () => {",
        '  cliques++;',
        "  document.getElementById('out').textContent = 'Cliques: ' + cliques;",
        "  console.log('Clique número', cliques);",
        '});',
        ''
      ].join('\n')
    }
  },
  {
    id: 'python',
    name: 'Python',
    desc: 'Executa offline (Pyodide)',
    main: 'main.py',
    files: {
      'main.py': [
        'def fibonacci(n):',
        '    a, b = 0, 1',
        '    for _ in range(n):',
        '        yield a',
        '        a, b = b, a + b',
        '',
        'print("Olá, CodeVerse!")',
        'print("Fibonacci:", list(fibonacci(10)))',
        ''
      ].join('\n')
    }
  },
  {
    id: 'java',
    name: 'Java',
    desc: 'Executa offline (compilador local)',
    main: 'Main.java',
    files: {
      'Main.java': [
        'public class Main {',
        '    public static void main(String[] args) {',
        '        System.out.println("Olá, CodeVerse!");',
        '        int soma = 0;',
        '        for (int i = 1; i <= 10; i++) {',
        '            soma += i;',
        '        }',
        '        System.out.println("Soma 1..10 = " + soma);',
        '    }',
        '}',
        ''
      ].join('\n')
    }
  },
  {
    id: 'dart',
    name: 'Dart (consola)',
    desc: 'Executa online (precisa de internet)',
    main: 'main.dart',
    files: {
      'main.dart': [
        'void main() {',
        "  print('Olá, CodeVerse!');",
        '  var numeros = [1, 2, 3, 4, 5];',
        "  print('Soma: ' + numeros.reduce((a, b) => a + b).toString());",
        '}',
        ''
      ].join('\n')
    }
  },
  {
    id: 'flutter',
    name: 'Flutter (editar + compilar no GitHub)',
    desc: 'Não executa no telemóvel; inclui workflow para gerar APK',
    main: 'lib/main.dart',
    files: {
      'pubspec.yaml': [
        'name: codeverse_app',
        'description: Projeto Flutter criado no CodeVerse',
        "publish_to: 'none'",
        'version: 1.0.0+1',
        '',
        'environment:',
        "  sdk: '>=3.0.0 <4.0.0'",
        '',
        'dependencies:',
        '  flutter:',
        '    sdk: flutter',
        '',
        'flutter:',
        '  uses-material-design: true',
        ''
      ].join('\n'),
      'lib/main.dart': [
        "import 'package:flutter/material.dart';",
        '',
        'void main() => runApp(const MyApp());',
        '',
        'class MyApp extends StatelessWidget {',
        '  const MyApp({super.key});',
        '',
        '  @override',
        '  Widget build(BuildContext context) {',
        '    return MaterialApp(',
        "      title: 'CodeVerse Flutter',",
        '      theme: ThemeData.dark(useMaterial3: true),',
        '      home: const Counter(),',
        '    );',
        '  }',
        '}',
        '',
        'class Counter extends StatefulWidget {',
        '  const Counter({super.key});',
        '',
        '  @override',
        '  State<Counter> createState() => _CounterState();',
        '}',
        '',
        'class _CounterState extends State<Counter> {',
        '  int _count = 0;',
        '',
        '  @override',
        '  Widget build(BuildContext context) {',
        '    return Scaffold(',
        "      appBar: AppBar(title: const Text('Olá, Flutter!')),",
        '      body: Center(',
        "        child: Text('Cliques: ' + _count.toString(), style: const TextStyle(fontSize: 28)),",
        '      ),',
        '      floatingActionButton: FloatingActionButton(',
        '        onPressed: () => setState(() => _count++),',
        '        child: const Icon(Icons.add),',
        '      ),',
        '    );',
        '  }',
        '}',
        ''
      ].join('\n'),
      '.github/workflows/build-flutter-apk.yml': [
        'name: Build Flutter APK',
        'on:',
        '  workflow_dispatch:',
        '  push:',
        '    branches: [main, master]',
        'jobs:',
        '  build:',
        '    runs-on: ubuntu-latest',
        '    steps:',
        '      - uses: actions/checkout@v4',
        '      - uses: actions/setup-java@v4',
        '        with:',
        '          distribution: temurin',
        "          java-version: '17'",
        '      - uses: subosito/flutter-action@v2',
        '        with:',
        '          channel: stable',
        '      - name: Gerar pasta android (se não existir)',
        '        run: |',
        '          if [ ! -d android ]; then',
        '            mkdir -p /tmp/cv_bak && cp -r lib pubspec.yaml /tmp/cv_bak/',
        '            flutter create . --platforms=android --project-name codeverse_app',
        '            rm -rf lib && cp -r /tmp/cv_bak/lib lib && cp /tmp/cv_bak/pubspec.yaml pubspec.yaml',
        '          fi',
        '      - run: flutter pub get',
        '      - run: flutter build apk --debug',
        '      - uses: actions/upload-artifact@v4',
        '        with:',
        '          name: flutter-apk',
        '          path: build/app/outputs/flutter-apk/*.apk',
        ''
      ].join('\n'),
      'README.md': [
        '# Projeto Flutter',
        '',
        'O Flutter SDK completo não corre dentro do Android. Edita o código aqui,',
        'exporta o projeto em ZIP (menu → Exportar ZIP), envia para um repositório GitHub',
        'e o workflow em .github/workflows gera o APK com GitHub Actions.',
        ''
      ].join('\n')
    }
  },
  {
    id: 'empty',
    name: 'Projeto vazio',
    desc: 'Só um README',
    main: 'README.md',
    files: { 'README.md': '# Novo projeto\n' }
  }
];
