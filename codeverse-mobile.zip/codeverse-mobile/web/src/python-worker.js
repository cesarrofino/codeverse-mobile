// Worker que executa Python com Pyodide (CPython compilado para WebAssembly), 100% offline.
// Os ficheiros de Pyodide são copiados para assets/www/pyodide/ durante o build.
/* global importScripts, loadPyodide */
let pyodide = null;
let baseModules = null;

function post(type, extra) {
  self.postMessage(Object.assign({ type }, extra || {}));
}

async function init() {
  try {
    importScripts('pyodide/pyodide.js');
    pyodide = await loadPyodide({
      indexURL: new URL('pyodide/', self.location.href).href,
      stdout: (s) => post('out', { text: String(s) }),
      stderr: (s) => post('err', { text: String(s) }),
    });
    pyodide.runPython('import sys\nBASE_MODULES = set(sys.modules.keys())');
    post('ready');
  } catch (e) {
    post('initError', { message: String((e && e.message) || e) });
  }
}

function ensureDir(path) {
  const parts = path.split('/');
  parts.pop();
  let cur = '/home/project';
  for (const p of parts) {
    cur += '/' + p;
    try { pyodide.FS.mkdir(cur); } catch (_) { /* já existe */ }
  }
}

async function run(files, main) {
  try {
    pyodide.runPython(
      [
        'import shutil, os, sys',
        'os.chdir("/home")',
        'shutil.rmtree("/home/project", ignore_errors=True)',
        'os.makedirs("/home/project", exist_ok=True)',
        'for _m in [m for m in list(sys.modules) if m not in BASE_MODULES]:',
        '    sys.modules.pop(_m, None)',
      ].join('\n')
    );
    for (const f of files) {
      ensureDir(f.path);
      pyodide.FS.writeFile('/home/project/' + f.path, f.content);
    }
    pyodide.runPython('import os, sys\nos.chdir("/home/project")\nif "/home/project" not in sys.path: sys.path.insert(0, "/home/project")');
    pyodide.globals.set('CV_MAIN', '/home/project/' + main);
    await pyodide.runPythonAsync('import runpy\nrunpy.run_path(CV_MAIN, run_name="__main__")');
    post('done', { ok: true });
  } catch (e) {
    // PythonError traz o traceback completo na mensagem
    post('err', { text: String((e && e.message) || e) });
    post('done', { ok: false });
  }
}

self.onmessage = (ev) => {
  const m = ev.data || {};
  if (m.type === 'init') init();
  else if (m.type === 'run') run(m.files || [], m.main);
};
