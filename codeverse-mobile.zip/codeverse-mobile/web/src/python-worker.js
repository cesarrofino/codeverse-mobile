// Worker que executa Python com Pyodide (CPython compilado para WebAssembly), 100% offline.
// Os ficheiros de Pyodide são copiados para assets/www/pyodide/ durante o build.
/* global importScripts, loadPyodide */
let pyodide = null;
let baseModules = null;

// ---- Jogos (cvgame): o Python desenha enviando comandos ao ecrã e recebe teclas/toques como mensagens ----
let gameActive = false, gameTimer = null, gameDonePending = false;
const gameIn = { k: {}, e: [] };
function gameEnd(ok) {
  gameActive = false; clearTimeout(gameTimer);
  post('gclose');
  if (gameDonePending) { gameDonePending = false; post('done', { ok: ok !== false }); }
}
self._cvg = {
  open: (w, h, title, controls, bg) => { gameIn.k = {}; gameIn.e = []; post('gopen', { w, h, title: String(title), controls: !!controls, bg: String(bg) }); },
  frame: (json) => post('gframe', { cmds: json }),
  take: () => { const s = JSON.stringify({ k: Object.keys(gameIn.k).filter((x) => gameIn.k[x]), e: gameIn.e }); gameIn.e = []; return s; },
  start: (fn, ms) => {
    gameActive = true;
    const loop = () => {
      if (!gameActive) return;
      const t0 = performance.now();
      try { fn(); } catch (e) { post('gclose'); post('err', { text: String((e && e.message) || e) }); gameEnd(false); return; }
      if (gameActive) gameTimer = setTimeout(loop, Math.max(0, ms - (performance.now() - t0)));
    };
    gameTimer = setTimeout(loop, 0);
  },
  stop: () => gameEnd(true),
};
function gameInput(m) {
  if (m.kind === 'down') { if (!gameIn.k[m.key]) gameIn.e.push(['d', m.key]); gameIn.k[m.key] = true; }
  else if (m.kind === 'up') { if (gameIn.k[m.key]) gameIn.e.push(['u', m.key]); gameIn.k[m.key] = false; }
  else if (m.kind === 'pd') gameIn.e.push(['pd', m.x, m.y]);
  else if (m.kind === 'pm') gameIn.e.push(['pm', m.x, m.y]);
  else if (m.kind === 'pu') gameIn.e.push(['pu']);
  if (gameIn.e.length > 200) gameIn.e.splice(0, gameIn.e.length - 200);
}

function post(type, extra) {
  self.postMessage(Object.assign({ type }, extra || {}));
}

async function init() {
  try {
    importScripts('pyodide/pyodide.js', 'cvgame.js');
    pyodide = await loadPyodide({
      indexURL: new URL('pyodide/', self.location.href).href,
      stdout: (s) => post('out', { text: String(s) }),
      stderr: (s) => post('err', { text: String(s) }),
    });
    try { pyodide.FS.mkdirTree('/lib/cv'); pyodide.FS.writeFile('/lib/cv/cvgame.py', self.CVGAME_PY); } catch (_) { /* sem jogos */ }
    pyodide.globals.set('_cv_readline', readLine);
    pyodide.runPython([
      'import sys, builtins',
      'def _cv_input(prompt=""):',
      '    line = _cv_readline(str(prompt))',
      '    if line is None:',
      '        raise EOFError("EOF when reading a line")',
      '    return line',
      'builtins.input = _cv_input',
      'class _CvStdin:',
      '    encoding = "utf-8"',
      '    def readline(self, size=-1):',
      '        line = _cv_readline("")',
      '        return "" if line is None else line + "\\n"',
      '    def read(self, size=-1):',
      '        out = []',
      '        while True:',
      '            l = self.readline()',
      '            if not l: break',
      '            out.append(l)',
      '        return "".join(out)',
      '    def readlines(self, hint=-1):',
      '        return list(iter(self.readline, ""))',
      '    def __iter__(self):',
      '        return iter(self.readline, "")',
      '    def isatty(self): return False',
      '    def fileno(self): raise OSError("sem descritor")',
      'sys.stdin = _CvStdin()',
      'sys.path.append("/lib/cv")',
      'BASE_MODULES = set(sys.modules.keys())',
    ].join('\n'));
    post('ready');
  } catch (e) {
    post('initError', { message: String((e && e.message) || e) });
  }
}

// input(): bloqueia o worker com um XHR síncrono; a app Android só responde quando o utilizador escreve a linha.
function readLine(prompt) {
  post('needInput', { prompt: String(prompt || '') });
  const x = new XMLHttpRequest();
  x.open('GET', '__cv/stdin?t=' + Date.now(), false);
  x.send(null);
  if (x.status === 200 && x.responseText.startsWith('L:')) return x.responseText.slice(2);
  return null; // EOF (parado, tempo esgotado ou sem ponte nativa)
}

function ensureDir(path) {
  const parts = path.split('/');
  parts.pop();
  let cur = '/home/project';
  for (const p of parts) {
    cur += '/' + p;
    try { pyodide.FS.mkdir(cur); } catch (_) { /* já existe */ }
  }
}

async function run(files, main) {
  try {
    pyodide.runPython(
      [
        'import shutil, os, sys',
        'os.chdir("/home")',
        'shutil.rmtree("/home/project", ignore_errors=True)',
        'os.makedirs("/home/project", exist_ok=True)',
        'for _m in [m for m in list(sys.modules) if m not in BASE_MODULES]:',
        '    sys.modules.pop(_m, None)',
      ].join('\n')
    );
    for (const f of files) {
      ensureDir(f.path);
      pyodide.FS.writeFile('/home/project/' + f.path, f.content);
    }
    pyodide.runPython('import os, sys\nos.chdir("/home/project")\nif "/home/project" not in sys.path: sys.path.insert(0, "/home/project")');
    pyodide.globals.set('CV_MAIN', '/home/project/' + main);
    await pyodide.runPythonAsync('import runpy\nrunpy.run_path(CV_MAIN, run_name="__main__")');
    if (gameActive) { gameDonePending = true; return; }   // jogo em curso: o 'done' vem quando ele terminar
    post('done', { ok: true });
  } catch (e) {
    // PythonError traz o traceback completo na mensagem
    gameActive = false; clearTimeout(gameTimer); gameDonePending = false; post('gclose');
    post('err', { text: String((e && e.message) || e) });
    post('done', { ok: false });
  }
}

self.onmessage = (ev) => {
  const m = ev.data || {};
  if (m.type === 'init') init();
  else if (m.type === 'ginput') gameInput(m);
  else if (m.type === 'run') run(m.files || [], m.main);
};
