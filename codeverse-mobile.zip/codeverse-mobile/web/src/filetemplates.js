/* Estrutura inicial de cada tipo de ficheiro novo (como "snippets de ficheiro" do VS Code).
 * window.CV_fileTemplate(path, info) -> { text, cursor }  (text vazio = sem modelo)
 *   info = { flutter: boolean }  (projeto com pubspec.yaml a usar Flutter)
 * O marcador \u0001 indica onde o cursor fica depois de criar o ficheiro.
 */
(function () {
  'use strict';
  const CUR = '\u0001';
  const lines = (...l) => l.join('\n') + '\n';

  const baseName = (p) => p.split('/').pop();
  const stem = (p) => baseName(p).replace(/\.[^.]*$/, '');
  const ident = (s, upperFirst) => {
    let n = String(s).replace(/[^A-Za-z0-9_$]/g, ' ').trim().split(/\s+/).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join('');
    if (!n) n = 'Main';
    if (/^[0-9]/.test(n)) n = '_' + n;
    return upperFirst === false ? n.charAt(0).toLowerCase() + n.slice(1) : n;
  };
  const camel = (s) => ident(String(s).replace(/[_\-]+/g, ' '));
  const snake = (s) => String(s).replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '').toLowerCase() || 'modulo';

  function javaPackage(path) {
    const parts = path.split('/').slice(0, -1);
    // ignora pastas de organização habituais
    while (parts.length && ['src', 'main', 'java', 'app'].includes(parts[0])) parts.shift();
    const ok = parts.length && parts.every((p) => /^[a-z_][a-z0-9_]*$/.test(p));
    return ok ? parts.join('.') : '';
  }

  const T = {
    html: (p) => lines(
      '<!DOCTYPE html>',
      '<html lang="pt">',
      '<head>',
      '  <meta charset="UTF-8">',
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0">',
      '  <title>' + camel(stem(p)).replace(/([a-z])([A-Z])/g, '$1 $2') + '</title>',
      '  <link rel="stylesheet" href="style.css">',
      '</head>',
      '<body>',
      '  ' + CUR,
      '  <script src="script.js"></script>',
      '</body>',
      '</html>'
    ),
    css: () => lines(
      '* {',
      '  box-sizing: border-box;',
      '  margin: 0;',
      '  padding: 0;',
      '}',
      '',
      'body {',
      '  font-family: system-ui, sans-serif;',
      '  ' + CUR,
      '}'
    ),
    js: () => lines("'use strict';", '', 'function main() {', '  ' + CUR, '}', '', 'main();'),
    ts: () => lines('function main(): void {', '  ' + CUR, '}', '', 'main();'),
    json: () => lines('{', '  ' + CUR, '}'),
    py: () => lines(
      'def main():',
      '    ' + CUR + 'pass',
      '',
      '',
      'if __name__ == "__main__":',
      '    main()'
    ),
    java: (p) => {
      const cls = ident(stem(p));
      const pkg = javaPackage(p);
      return (pkg ? 'package ' + pkg + ';\n\n' : '') + lines(
        'public class ' + cls + ' {',
        '    public static void main(String[] args) {',
        '        ' + CUR,
        '    }',
        '}'
      );
    },
    dart: (p, info) => {
      const file = baseName(p);
      if (info && info.flutter) {
        if (file === 'main.dart') {
          return lines(
            "import 'package:flutter/material.dart';",
            '',
            'void main() => runApp(const MyApp());',
            '',
            'class MyApp extends StatelessWidget {',
            '  const MyApp({super.key});',
            '',
            '  @override',
            '  Widget build(BuildContext context) {',
            '    return MaterialApp(',
            "      title: 'Minha app',",
            '      theme: ThemeData(useMaterial3: true),',
            '      home: const HomePage(),',
            '    );',
            '  }',
            '}',
            '',
            'class HomePage extends StatelessWidget {',
            '  const HomePage({super.key});',
            '',
            '  @override',
            '  Widget build(BuildContext context) {',
            '    return Scaffold(',
            "      appBar: AppBar(title: const Text('Início')),",
            '      body: const Center(',
            "        child: Text('Olá, Flutter!'" + CUR + '),',
            '      ),',
            '    );',
            '  }',
            '}'
          );
        }
        const cls = camel(stem(p));
        return lines(
          "import 'package:flutter/material.dart';",
          '',
          'class ' + cls + ' extends StatelessWidget {',
          '  const ' + cls + '({super.key});',
          '',
          '  @override',
          '  Widget build(BuildContext context) {',
          '    return Scaffold(',
          '      body: Center(',
          "        child: Text('" + cls + "'" + CUR + '),',
          '      ),',
          '    );',
          '  }',
          '}'
        );
      }
      return lines('void main() {', '  ' + CUR, '}');
    },
    md: (p) => '# ' + camel(stem(p)).replace(/([a-z])([A-Z])/g, '$1 $2') + '\n\n' + CUR + '\n',
    xml: () => lines('<?xml version="1.0" encoding="utf-8"?>', '<root>', '  ' + CUR, '</root>'),
    yaml: () => lines('# ' + CUR),
    kt: () => lines('fun main() {', '    ' + CUR, '}'),
    c: () => lines('#include <stdio.h>', '', 'int main(void) {', '    ' + CUR, '    return 0;', '}'),
    cpp: () => lines('#include <iostream>', '', 'int main() {', '    ' + CUR, '    return 0;', '}'),
    sh: () => lines('#!/bin/sh', '', CUR),
    php: () => lines('<?php', '', CUR),
    sql: () => lines('-- ' + CUR),
    vue: () => lines('<template>', '  <div>' + CUR + '</div>', '</template>', '', '<script>', 'export default {', '};', '</script>'),
  };
  const ALIAS = { htm: 'html', mjs: 'js', cjs: 'js', jsx: 'js', tsx: 'ts', yml: 'yaml', h: 'c', cc: 'cpp', cxx: 'cpp', hpp: 'cpp', svg: null };

  window.CV_fileTemplate = function (path, info) {
    const m = /\.([A-Za-z0-9]+)$/.exec(path);
    if (!m) return { text: '', cursor: 0 };
    let ext = m[1].toLowerCase();
    if (Object.prototype.hasOwnProperty.call(ALIAS, ext)) ext = ALIAS[ext];
    const f = ext && T[ext];
    if (!f) return { text: '', cursor: 0 };
    let text = f(path, info || {});
    const i = text.indexOf(CUR);
    text = text.replace(/\u0001/g, '');
    return { text, cursor: i < 0 ? text.length : i };
  };
  window.CV_snakeName = snake;
})();
