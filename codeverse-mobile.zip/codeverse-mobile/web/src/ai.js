/* CodeVerse — Assistente de IA no editor.
 * As chaves NÃO são introduzidas na app: vêm dos segredos do GitHub (GEMINI_KEY e OPENROUTER_KEY, com chaves separadas por vírgula),
 * injetados na compilação em ai-config.js. Ordem de uso: Gemini (todas as chaves) -> OpenRouter; quando uma chave
 * esgota (limite/quota) ou falha, passa à seguinte automaticamente. */
'use strict';
(function () {
  let A = null;
  const LS = 'cv.ai';

  const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai';
  const OPENROUTER_BASE = 'https://openrouter.ai/api/v1';
  const CFG = window.CV_AI_CONFIG || {};

  // Cadeia de chaves por ordem de prioridade (todas usam o formato compatível com a OpenAI).
  const CHAIN = [];
  const gem = CFG.gemini || {};
  (gem.keys || []).forEach((k, i) => { if (k) CHAIN.push({ id: 'g' + (i + 1), label: 'Gemini ' + (i + 1), base: GEMINI_BASE, key: k, model: gem.model || 'gemini-3.8-flash', reasoning: gem.reasoning || '' }); });
  const orc = CFG.openrouter || {};
  const orKeys = orc.keys || (orc.key ? [orc.key] : []);
  orKeys.forEach((k, i) => { if (k) CHAIN.push({ id: 'or' + (i + 1), label: orKeys.length > 1 ? 'OpenRouter ' + (i + 1) : 'OpenRouter', base: OPENROUTER_BASE, key: k, model: orc.model || 'openrouter/auto' }); });

  // Chaves que falharam ficam em pausa (guardado só o tempo, nunca a chave).
  const CD = 'cv.ai.cd';
  const cooldown = (() => { try { return JSON.parse(localStorage.getItem(CD) || '{}') || {}; } catch (_) { return {}; } })();
  const saveCd = () => { try { localStorage.setItem(CD, JSON.stringify(cooldown)); } catch (_) { /* ignora */ } };
  const MIN = 60000;
  const pause = (id, status) => {
    cooldown[id] = Date.now() + (status === 429 ? 30 * MIN : (status === 401 || status === 403) ? 12 * 60 * MIN : 2 * MIN);
    saveCd();
  };
  const ready = (n) => !(cooldown[n.id] > Date.now());

  const QUICK = [
    ['Explicar', 'Explica este código de forma simples e direta.'],
    ['Corrigir', 'Procura erros neste código e corrige-os. Devolve o código corrigido e diz o que mudaste.'],
    ['Melhorar', 'Melhora este código (legibilidade e boas práticas) sem mudar o comportamento. Devolve o código completo.'],
    ['Comentar', 'Adiciona comentários úteis ao código sem mudar o comportamento. Devolve o código completo.'],
  ];

  const C = {
    msgs: [],        // { role: 'user' | 'bot' | 'err', text, meta }
    hist: [],        // histórico enviado ao modelo: { role: 'user' | 'assistant', content }
    notes: [],       // memória duradoura do projeto (factos e instruções)
    digest: [],      // resumo de pedidos antigos que já saíram do histórico
    busy: null,      // AbortController enquanto há um pedido a decorrer
    project: null,
    memView: false,
    ui: null,
  };
  const configured = () => CHAIN.length > 0;

  // ---------- Memória do projeto (guardada neste telemóvel, uma por projeto) ----------
  const MK = 'cv.ai.p.';
  const HIST_KEEP = 20, HIST_SEND = 10, OLD_CLIP = 1200, NOTES_MAX = 25, NOTE_LEN = 400, DIGEST_MAX = 20;
  const MEM_RE = /\[\[\s*mem[óo]ria\s*:([\s\S]*?)\]\]/gi;
  // Remove as marcas de memória do texto mostrado (também uma marca ainda por fechar, durante o fluxo).
  const clean = (t) => String(t).replace(MEM_RE, '').replace(/\[\[\s*mem[^\]]*$/i, '').replace(/\s+$/, '');
  const slimMeta = (m) => (!m || (m.sel && m.sel.text.length > 6000) ? null : m);

  function loadProject(name) {
    C.msgs = []; C.hist = []; C.notes = []; C.digest = [];
    try {
      const j = JSON.parse(localStorage.getItem(MK + name) || 'null');
      if (j) { C.msgs = j.msgs || []; C.hist = j.hist || []; C.notes = j.notes || []; C.digest = j.digest || []; }
    } catch (_) { /* memória corrompida: começa limpa */ }
  }
  function saveProject() {
    if (!C.project) return;
    const pack = (n) => JSON.stringify({
      msgs: C.msgs.filter((m) => !m.streaming).slice(-n).map((m) => ({ role: m.role, text: m.text, meta: slimMeta(m.meta) })),
      hist: C.hist, notes: C.notes, digest: C.digest,
    });
    try { localStorage.setItem(MK + C.project, pack(30)); } catch (_) {
      try { localStorage.setItem(MK + C.project, pack(8)); } catch (_2) { /* sem espaço */ }
    }
  }
  function pushTurn(prompt, answer) {
    C.hist.push({ role: 'user', content: prompt }, { role: 'assistant', content: answer });
    while (C.hist.length > HIST_KEEP) {             // o que sai do histórico fica resumido numa linha
      const old = C.hist.splice(0, 2)[0];
      C.digest.push('• ' + String(old.content).replace(/\s+/g, ' ').slice(0, 110));
    }
    if (C.digest.length > DIGEST_MAX) C.digest.splice(0, C.digest.length - DIGEST_MAX);
  }
  function addNote(text) {
    const n = String(text).replace(/\s+/g, ' ').trim().slice(0, NOTE_LEN);
    if (!n || C.notes.includes(n)) return false;
    C.notes.push(n);
    if (C.notes.length > NOTES_MAX) C.notes.splice(0, C.notes.length - NOTES_MAX);
    return true;
  }
  function harvest(text) {
    let m, k = 0;
    MEM_RE.lastIndex = 0;
    while ((m = MEM_RE.exec(text))) if (addNote(m[1])) k++;
    return k;
  }
  // Só as últimas mensagens vão ao modelo (respostas antigas encurtadas): menos texto = resposta mais rápida.
  const histForSend = () => C.hist.slice(-HIST_SEND).map((m) => ({
    role: m.role, content: m.role === 'assistant' && m.content.length > OLD_CLIP ? m.content.slice(0, OLD_CLIP) + '\n… (resposta antiga encurtada)' : m.content,
  }));

  // ---------- Contexto do editor ----------
  const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(p || ''); return m ? m[1].toLowerCase() : ''; };

  function captureContext() {
    const S = A.S, ed = A.ed();
    const path = S.active;
    if (!path || !ed.has(path)) return null;
    const text = ed.getText(path) || '';
    let sel = null;
    try {
      const s = ed.getSelection && ed.getSelection();
      if (s && s.to > s.from) sel = { from: s.from, to: s.to, text: text.slice(s.from, s.to) };
    } catch (_) { /* sem seleção */ }
    return { path, text, sel };
  }

  function fence(text, lang) {
    let n = 3;
    const runs = String(text).match(/`+/g);
    if (runs) for (const r of runs) n = Math.max(n, r.length + 1);
    const f = '`'.repeat(n);
    return f + (lang || '') + '\n' + text + '\n' + f;
  }
  const clip = (t) => (t.length > 30000 ? t.slice(0, 30000) + '\n… (ficheiro cortado)' : t);
  const AROUND = 2500;

  function projectMap() {
    const all = (A.S.tree || []).filter((i) => !i.dir && !/(^|\/)(node_modules|\.git|build|dist|\.gradle)\//.test(i.path)).map((i) => i.path);
    let out = '', n = 0;
    for (const p of all) { if (n >= 150 || out.length > 3500) break; out += p + '\n'; n++; }
    return out.trimEnd() + (all.length > n ? '\n… (+' + (all.length - n) + ' ficheiros)' : '');
  }

  // Parte estável (instruções + memória + mapa do projeto): vai sempre primeiro, o que ajuda o serviço a reaproveitar o pedido.
  function systemPrompt() {
    const L = [
      'És o assistente de programação do CodeVerse, um editor de código para Android. O utilizador está no telemóvel: respostas rápidas e curtas.',
      '',
      'Regras:',
      '1. Responde na língua do utilizador (por omissão, português de Portugal).',
      '2. Vai direto ao ponto: primeiro a resposta ou o código, depois no máximo 2 ou 3 frases de explicação. Sem introduções, sem repetir a pergunta, sem elogios.',
      '3. Escreve código sempre em blocos com três acentos graves e o nome da linguagem.',
      '4. Se o pedido for corrigir, melhorar ou alterar código, devolve só a parte pedida (a seleção ou, sem seleção, o ficheiro todo) COMPLETA num único bloco, pronta a substituir. Nunca uses "..." nem "resto igual".',
      '5. Mantém a linguagem, o estilo e as bibliotecas que o projeto já usa. Não inventes funções, ficheiros nem APIs; se faltar contexto, diz o que falta em vez de adivinhar.',
      '6. Se o pedido for ambíguo, faz UMA pergunta curta em vez de assumir.',
      '7. Só alteras o que foi pedido. Podes sugerir mudanças noutros ficheiros do projeto, indicando o caminho.',
      '8. As instruções e a memória abaixo foram dadas pelo utilizador ou guardadas por ti: segue-as.',
      '',
      'Memória: guardas factos duradouros do projeto. Quando aprenderes algo que valha a pena lembrar noutras conversas (tecnologias, convenções, decisões, objetivo do projeto, preferências do utilizador), acrescenta NO FIM da resposta, numa linha própria, [[memória: facto curto]]. No máximo 1 ou 2 por resposta, só se for novo e útil. A app guarda a linha e remove-a do texto; não lhe dês outro uso.',
    ];
    if (A.S.project) L.push('', 'Projeto: ' + A.S.project);
    if (C.notes.length) L.push('', 'Memória do projeto:', C.notes.map((n) => '- ' + n).join('\n'));
    if (C.digest.length) L.push('', 'Pedidos anteriores já fora da conversa (resumo):', C.digest.join('\n'));
    const map = projectMap();
    if (map) L.push('', 'Ficheiros do projeto:', map);
    return L.join('\n');
  }

  // Parte variável: pergunta + ficheiro/seleção. Com seleção vai só um pouco do texto à volta (mais rápido).
  function userContent(prompt, ctx) {
    if (!ctx) return prompt;
    const lang = extOf(ctx.path);
    const L = [prompt, '', '---', 'Ficheiro aberto: ' + ctx.path];
    if (ctx.sel) {
      const before = ctx.text.slice(Math.max(0, ctx.sel.from - AROUND), ctx.sel.from);
      const after = ctx.text.slice(ctx.sel.to, ctx.sel.to + AROUND);
      L.push('Seleção do utilizador:', fence(ctx.sel.text, lang));
      if (before) L.push('Texto imediatamente antes (contexto):', fence(before, lang));
      if (after) L.push('Texto imediatamente depois (contexto):', fence(after, lang));
    } else {
      L.push('Conteúdo do ficheiro:', fence(clip(ctx.text), lang));
    }
    return L.join('\n');
  }

  // ---------- Pedido ao fornecedor (com resposta em fluxo e troca automática de chave) ----------
  class ApiError extends Error {
    constructor(msg, status, retry) { super(msg); this.status = status; this.retry = retry; }
  }

  async function errorOf(res) {
    let msg = '';
    try {
      const j = await res.json();
      const e = Array.isArray(j) ? j[0] : j;
      msg = (e && e.error && (e.error.message || e.error)) || (e && e.message) || '';
      if (typeof msg !== 'string') msg = JSON.stringify(msg);
    } catch (_) { /* sem corpo */ }
    const s = res.status;
    const base = s === 429 ? 'Limite de pedidos ou quota esgotada (429).'
      : (s === 401 || s === 403) ? 'Chave inválida ou sem permissão (' + s + ').'
      : s === 404 ? 'Modelo ou endereço não encontrado (404).'
      : 'Erro ' + s + '.';
    return new ApiError(base + (msg ? ' ' + msg.slice(0, 200) : ''), s, true);
  }

  const HEAD_MS = 12000, IDLE_MS = 30000;   // sem resposta a tempo: passa logo à chave seguinte

  async function streamOne(node, system, msgs, signal, onText) {
    if (signal && signal.aborted) throw new DOMException('Aborted', 'AbortError');
    const lc = new AbortController();
    const onAbort = () => lc.abort();
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
    let timedOut = false;
    const arm = (ms) => setTimeout(() => { timedOut = true; lc.abort(); }, ms);
    const stall = () => new ApiError(node.label + ' não respondeu a tempo.', 0, true);
    try {
      const body = { model: node.model, messages: [{ role: 'system', content: system }].concat(msgs), stream: true };
      if (node.reasoning && !node.noReason) body.reasoning_effort = node.reasoning;
      let res;
      const t0 = arm(HEAD_MS);
      try {
        res = await fetch(node.base + '/chat/completions', {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: 'Bearer ' + node.key },
          body: JSON.stringify(body),
          signal: lc.signal,
        });
      } catch (e) {
        if (timedOut) throw stall();
        if (e && e.name === 'AbortError') throw e;
        throw new ApiError('Sem ligação ao serviço (' + node.label + ').', 0, true);
      } finally { clearTimeout(t0); }
      if (!res.ok) throw await errorOf(res);

      const take = (ev) => {
        const o = Array.isArray(ev) ? ev[0] : ev;
        if (o && o.error) throw new ApiError((o.error.message || 'Erro do serviço.'), o.error.code || 0, true);
        const d = o && o.choices && o.choices[0] && o.choices[0].delta;
        if (d && d.content) onText(d.content);
      };

      if (!res.body || !res.body.getReader) {           // sem leitura em fluxo: lê tudo de uma vez
        const j = await res.json();
        onText((((j.choices || [])[0] || {}).message || {}).content || '');
        return;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      try {
        for (;;) {
          const t = arm(IDLE_MS);
          let r;
          try { r = await reader.read(); } finally { clearTimeout(t); }
          if (r.done) break;
          buf += dec.decode(r.value, { stream: true });
          let nl;
          while ((nl = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, nl).trim();
            buf = buf.slice(nl + 1);
            if (!line.startsWith('data:')) continue;
            const payload = line.slice(5).trim();
            if (!payload || payload === '[DONE]') continue;
            let ev;
            try { ev = JSON.parse(payload); } catch (_) { continue; }
            take(ev);
          }
        }
      } catch (e) {
        if (timedOut) throw stall();
        throw e;
      }
    } finally {
      if (signal) signal.removeEventListener('abort', onAbort);
    }
  }

  async function streamChat(system, msgs, signal, onText) {
    // Primeiro as chaves disponíveis; se todas estiverem em pausa, tenta todas na mesma.
    let list = CHAIN.filter(ready);
    if (!list.length) list = CHAIN.slice();
    let last = null;
    for (let i = 0; i < list.length; i++) {
      const node = list[i];
      let started = false;
      try {
        await streamOne(node, system, msgs, signal, (t) => { if (t) started = true; onText(t); });
        delete cooldown[node.id]; saveCd();
        return;
      } catch (e) {
        if (e && e.name === 'AbortError') throw e;
        if (started) throw e;                          // já começou a responder: não troca a meio
        if (e && e.status === 400 && node.reasoning && !node.noReason) { node.noReason = true; i--; continue; }   // o modelo não aceita "raciocínio": repete sem ele
        last = e;
        pause(node.id, e && e.status);
        const next = list[i + 1];
        if (next && A && A.toast) A.toast(node.label + ' indisponível. A usar ' + next.label + '.');
      }
    }
    throw new Error('Todas as chaves falharam. ' + (last && last.message ? last.message : ''));
  }

  // ---------- Markdown simples (seguro: constrói nós, nunca usa innerHTML) ----------
  function inline(s) {
    const out = [];
    const re = /(`[^`]+`|\*\*[^*]+\*\*)/g;
    let last = 0, m;
    while ((m = re.exec(s))) {
      if (m.index > last) out.push(s.slice(last, m.index));
      const t = m[0];
      out.push(t[0] === '`' ? A.el('code', { class: 'ai-ic', text: t.slice(1, -1) }) : A.el('strong', { text: t.slice(2, -2) }));
      last = m.index + t.length;
    }
    if (last < s.length) out.push(s.slice(last));
    return out;
  }

  function copyText(text) {
    const done = () => A.toast('Copiado');
    const fallback = () => {
      const ta = A.el('textarea', { style: 'position:fixed;left:-999px;top:0' });
      ta.value = text; document.body.append(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (_) { A.toast('Não foi possível copiar.', true); }
      ta.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fallback);
    else fallback();
  }

  function codeBlock(code, lang, meta, streaming) {
    const head = A.el('div', { class: 'ai-code-h' }, A.el('span', { class: 'ai-lang', text: lang || 'código' }), A.el('span', { class: 'spacer' }));
    if (!streaming) {
      head.append(
        A.el('button', { class: 'ai-act', text: 'Copiar', onclick: () => copyText(code) }),
        A.el('button', { class: 'ai-act', text: 'Inserir', onclick: () => applyCode(code, meta, 'insert') }),
        A.el('button', { class: 'ai-act primary', text: 'Substituir', onclick: () => applyCode(code, meta, 'replace') })
      );
    }
    return A.el('div', { class: 'ai-code' }, head, A.el('pre', {}, A.el('code', { text: code })));
  }

  function renderMd(host, text, meta, streaming) {
    host.textContent = '';
    const lines = String(text).split('\n');
    let i = 0, para = [], list = null;
    const flushPara = () => { if (para.length) { host.append(A.el('p', {}, inline(para.join(' ')))); para = []; } };
    const flushList = () => { if (list) { host.append(list); list = null; } };
    while (i < lines.length) {
      const ln = lines[i];
      const fm = /^\s*(`{3,}|~{3,})\s*([\w+#.-]*)\s*$/.exec(ln);
      if (fm) {
        flushPara(); flushList();
        const mark = fm[1];
        const buf = [];
        i++;
        while (i < lines.length) {
          const t = lines[i].trim();
          if (t.length >= mark.length && t[0] === mark[0] && /^(`+|~+)$/.test(t)) break;
          buf.push(lines[i]); i++;
        }
        const closed = i < lines.length;
        i++;
        host.append(codeBlock(buf.join('\n'), fm[2], meta, streaming || !closed));
        continue;
      }
      const hm = /^#{1,6}\s+(.*)$/.exec(ln);
      const bm = /^\s*[-*•]\s+(.*)$/.exec(ln);
      const nm = /^\s*\d+[.)]\s+(.*)$/.exec(ln);
      if (hm) { flushPara(); flushList(); host.append(A.el('p', { class: 'ai-h' }, inline(hm[1]))); }
      else if (bm || nm) {
        flushPara();
        const tag = bm ? 'ul' : 'ol';
        if (!list || list.tagName.toLowerCase() !== tag) { flushList(); list = A.el(tag, { class: 'ai-list' }); }
        list.append(A.el('li', {}, inline((bm || nm)[1])));
      } else if (!ln.trim()) { flushPara(); flushList(); }
      else { flushList(); para.push(ln.trim()); }
      i++;
    }
    flushPara(); flushList();
  }

  // ---------- Aplicar código no editor ----------
  async function applyCode(code, meta, mode) {
    const S = A.S, ed = A.ed();
    if (!meta || !meta.path) {
      if (!S.active || !ed.has(S.active)) { A.toast('Abre um ficheiro primeiro.', true); return; }
      ed.insert(code); A.closeExplorer(); return;
    }
    if (S.active !== meta.path || !ed.has(meta.path)) { A.toast('Abre o ficheiro “' + A.basename(meta.path) + '” para aplicar.', true); return; }
    if (mode === 'insert') { ed.insert(code); A.closeExplorer(); A.toast('Inserido no cursor'); return; }
    if (meta.sel) {
      const cur = ed.getText(meta.path) || '';
      if (cur.slice(meta.sel.from, meta.sel.to) === meta.sel.text) {
        ed.replaceRange(meta.sel.from, meta.sel.to, code);
        A.closeExplorer(); A.toast('Seleção substituída');
      } else {
        ed.insert(code); A.closeExplorer(); A.toast('O ficheiro mudou: inseri o código no cursor.');
      }
      return;
    }
    const ok = await A.uiConfirm('Substituir ficheiro', 'Substituir todo o conteúdo de “' + A.basename(meta.path) + '” por este código? Podes desfazer no menu do editor (Desfazer).', 'Substituir');
    if (!ok) return;
    ed.replaceAll(code);
    A.closeExplorer(); A.toast('Ficheiro substituído');
  }

  // ---------- Interface ----------
  function bubble(m) {
    if (m.role === 'user') return A.el('div', { class: 'ai-msg user', text: m.text });
    const d = A.el('div', { class: 'ai-msg ' + (m.role === 'err' ? 'err' : 'bot') });
    if (m.role === 'err') d.textContent = m.text; else renderMd(d, clean(m.text), m.meta, !!m.streaming);
    return d;
  }

  function ctxLabel() {
    const ctx = captureContext();
    if (!ctx) return 'Sem ficheiro aberto: pergunta à vontade.';
    const lines = ctx.sel ? ctx.sel.text.split('\n').length : 0;
    return A.basename(ctx.path) + (ctx.sel ? ' · seleção de ' + lines + (lines === 1 ? ' linha' : ' linhas') : ' · ficheiro todo');
  }

  function renderChat(host) {
    const msgs = A.el('div', { class: 'ai-msgs' });
    const ctxEl = A.el('div', { class: 'ai-ctx' });
    const ta = A.el('textarea', { class: 'ai-ta', rows: '1', placeholder: 'Pergunta ao assistente…', autocapitalize: 'sentences', spellcheck: 'false' });
    const send = A.el('button', { class: 'ai-send', 'aria-label': 'Enviar' });
    const chips = A.el('div', { class: 'ai-chips' }, QUICK.map(([label, prompt]) =>
      A.el('button', { class: 'ai-chip', text: label, onclick: () => ask(prompt, true) })));
    C.ui = { msgs, ctxEl, ta, send };

    const fit = () => { ta.style.height = 'auto'; ta.style.height = Math.min(120, ta.scrollHeight) + 'px'; };
    ta.addEventListener('input', fit);
    send.addEventListener('click', () => {
      if (C.busy) { C.busy.abort(); return; }
      const t = ta.value.trim();
      if (!t) return;
      ta.value = ''; fit();
      ask(t, false);
    });

    if (!C.msgs.length) {
      msgs.append(A.el('div', { class: 'ai-empty' },
        A.el('div', { class: 'ai-empty-ic', html: A.I.svg('sparkles', 28) }),
        A.el('p', { text: 'Seleciona um trecho de código (ou deixa o ficheiro todo) e usa as ações rápidas, ou escreve a tua pergunta.' })));
    } else {
      for (const m of C.msgs) msgs.append(bubble(m));
    }
    host.append(msgs, chips, ctxEl, A.el('div', { class: 'ai-composer' }, ta, send));
    ctxEl.textContent = ctxLabel();
    updateSend();
    msgs.scrollTop = msgs.scrollHeight;
  }

  function updateSend() {
    if (!C.ui) return;
    const b = C.ui.send;
    b.classList.toggle('stop', !!C.busy);
    b.innerHTML = A.I.svg(C.busy ? 'stop' : 'send', 20);
    b.setAttribute('aria-label', C.busy ? 'Parar' : 'Enviar');
  }

  function renderMemory(host) {
    const list = A.el('div', { class: 'ai-notes' });
    const draw = () => {
      list.textContent = '';
      if (!C.notes.length) list.append(A.el('p', { class: 'ai-hint', text: 'Ainda não há notas. O assistente guarda aqui o que aprende do projeto, e tu podes acrescentar instruções.' }));
      C.notes.forEach((n, i) => list.append(A.el('div', { class: 'ai-note' },
        A.el('span', { text: n }),
        A.el('button', { class: 'ai-act', text: 'Remover', onclick: () => { C.notes.splice(i, 1); saveProject(); draw(); } }))));
    };
    draw();
    const inp = A.el('input', { class: 'ai-input', type: 'text', placeholder: 'Ex.: usa sempre TypeScript e aspas simples', autocapitalize: 'sentences', spellcheck: 'false', autocomplete: 'off' });
    const add = () => { if (addNote(inp.value)) { inp.value = ''; saveProject(); draw(); } };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
    host.append(A.el('div', { class: 'ai-setup' },
      A.el('h3', { class: 'ai-setup-title', text: 'Memória do projeto' }),
      A.el('p', { class: 'ai-hint', text: 'O assistente lê estas notas em todos os pedidos deste projeto, mesmo depois de fechares a app. Podes escrever aqui instruções para ele seguir.' }),
      list,
      inp,
      A.el('div', { class: 'ai-btns' },
        A.el('button', { class: 'btn primary', text: 'Guardar nota', onclick: add }),
        A.el('button', { class: 'btn', text: 'Voltar', onclick: () => { C.memView = false; render(); } }),
        A.el('button', { class: 'btn danger', text: 'Apagar tudo', onclick: async () => {
          if (!(await A.uiConfirm('Apagar memória', 'Apagar todas as notas e o resumo deste projeto?', 'Apagar'))) return;
          C.notes = []; C.digest = []; saveProject(); draw(); A.toast('Memória apagada');
        } }))));
  }

  function render() {
    const host = A.$('#ai-body');
    if (!host) return;
    host.textContent = '';
    C.ui = null;
    if (C.memView) { renderMemory(host); return; }
    if (!configured()) {
      host.append(A.el('div', { class: 'ai-setup' },
        A.el('div', { class: 'ai-setup-ic', html: A.I.svg('sparkles', 30) }),
        A.el('h3', { class: 'ai-setup-title', text: 'Assistente indisponível' }),
        A.el('p', { class: 'ai-hint', text: 'O assistente não está disponível de momento. Tenta novamente mais tarde.' })));
      return;
    }
    renderChat(host);
  }

  async function ask(prompt, needsCode) {
    if (C.busy) { A.toast('Aguarda a resposta atual ou toca em parar.', true); return; }
    if (!configured()) { render(); return; }
    const ctx = captureContext();
    if (needsCode && !ctx) { A.toast('Abre um ficheiro (ou seleciona código) primeiro.', true); return; }
    const ui = C.ui;
    if (!ui) return;
    if (!C.msgs.length) ui.msgs.textContent = '';

    const meta = ctx ? { path: ctx.path, sel: ctx.sel } : null;
    const um = { role: 'user', text: prompt };
    const bm = { role: 'bot', text: '', meta, streaming: true };
    C.msgs.push(um, bm);
    ui.msgs.append(bubble(um));
    const bel = bubble(bm);
    bel.classList.add('wait');
    ui.msgs.append(bel);
    ui.msgs.scrollTop = ui.msgs.scrollHeight;

    const ac = new AbortController();
    C.busy = ac;
    updateSend();
    let tm = 0;
    let errMsg = null;
    const paint = () => {                              // a cada ~90 ms (redesenhar a cada letra pesa no telemóvel)
      tm = 0;
      bel.classList.remove('wait');
      renderMd(bel, clean(bm.text), meta, true);
      ui.msgs.scrollTop = ui.msgs.scrollHeight;
    };
    const drop = () => { const k = C.msgs.indexOf(bm); if (k >= 0) C.msgs.splice(k, 1); };
    try {
      await streamChat(systemPrompt(), histForSend().concat([{ role: 'user', content: userContent(prompt, ctx) }]), ac.signal, (t) => {
        bm.text += t;
        if (!tm) tm = setTimeout(paint, 90);
      });
      if (harvest(bm.text)) A.toast('Memória do projeto atualizada');
      bm.text = clean(bm.text);
      if (!bm.text.trim()) throw new Error('O assistente não devolveu resposta.');
      pushTurn(prompt, bm.text);
    } catch (e) {
      if (e && e.name === 'AbortError') {
        harvest(bm.text);
        bm.text = clean(bm.text);
        if (bm.text.trim()) {
          bm.text += '\n\n(interrompido)';
          pushTurn(prompt, bm.text);
        } else { drop(); bel.remove(); }
      } else {
        errMsg = { role: 'err', text: (e && e.message) || 'Erro desconhecido.' };
        const k = C.msgs.indexOf(bm);
        if (k >= 0) C.msgs.splice(k, 1, errMsg);
      }
    } finally {
      if (tm) clearTimeout(tm);
      C.busy = null;
      bm.streaming = false;
      saveProject();
      if (C.ui === ui) {
        if (errMsg) bel.replaceWith(bubble(errMsg));
        else if (bel.isConnected) { bel.classList.remove('wait'); renderMd(bel, clean(bm.text), meta, false); }
        ui.msgs.scrollTop = ui.msgs.scrollHeight;
        updateSend();
      }
    }
  }

  // ---------- API pública ----------
  window.CVAI = {
    init(api) {
      A = api;
      const clear = A.$('#ai-clear');
      if (clear) clear.addEventListener('click', () => {
        if (C.busy) C.busy.abort();
        C.msgs = []; C.hist = []; C.digest = [];      // a conversa recomeça; as notas do projeto ficam
        saveProject();
        C.memView = false;
        render();
      });
      const mem = A.$('#ai-mem');
      if (mem) mem.addEventListener('click', () => { C.memView = !C.memView; render(); });
    },
    show() {
      if (C.project !== A.S.project) {
        if (C.busy) C.busy.abort();
        C.project = A.S.project;
        loadProject(C.project);
        C.memView = false;
        render();
        return;
      }
      if (!C.ui || !configured() || C.memView) render();
      else C.ui.ctxEl.textContent = ctxLabel();
    },
  };
})();
