"""cvgame - mini-jogos no CodeVerse (offline, leve).

    from cvgame import Game

    game = Game(360, 640, "O meu jogo")
    x = 150

    @game.update
    def update(dt):
        global x
        if game.key("left"):  x -= 200 * dt
        if game.key("right"): x += 200 * dt

    @game.draw
    def draw():
        game.clear("#0f141d")
        game.rect(x, 560, 60, 14, "cyan")

    game.run()

Teclas: left right up down space enter e as letras (a..z). No telemóvel aparecem botoes no ecra.
Toque: game.tap() devolve (x, y) no frame em que tocaste; game.pointer e game.touching dizem onde esta o dedo.
"""
import json
import math
import random
import time

import js
from pyodide.ffi import create_proxy

__all__ = ["Game", "collide", "hit_circle", "clamp", "dist", "random", "math"]


def _col(c):
    if isinstance(c, (tuple, list)):
        return "rgb(%d,%d,%d)" % tuple(int(v) for v in c[:3])
    return str(c)


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def dist(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def collide(a, b):
    """True se os retangulos (x, y, largura, altura) se tocam."""
    return a[0] < b[0] + b[2] and a[0] + a[2] > b[0] and a[1] < b[1] + b[3] and a[1] + a[3] > b[1]


def hit_circle(x1, y1, r1, x2, y2, r2):
    """True se dois circulos se tocam."""
    return dist(x1, y1, x2, y2) < r1 + r2


class Game:
    def __init__(self, width=360, height=640, title="Jogo", bg="#0f141d", controls=True, fps=60):
        self.width = int(width)
        self.height = int(height)
        self.title = str(title)
        self.bg = _col(bg)
        self.controls = bool(controls)
        self.fps = max(10, min(120, int(fps)))
        self.time = 0.0
        self.frame = 0
        self.pointer = (0, 0)
        self.touching = False
        self._held = set()
        self._pressed = set()
        self._released = set()
        self._taps = []
        self._cmds = []
        self._upd = None
        self._drw = None
        self._run = False
        self._last = 0.0
        self._proxy = None

    # ---- registar funcoes ----
    def update(self, fn):
        self._upd = fn
        return fn

    def draw(self, fn):
        self._drw = fn
        return fn

    # ---- entrada ----
    def key(self, name):
        """True enquanto a tecla esta premida."""
        return str(name).lower() in self._held

    def pressed(self, name):
        """True so no frame em que a tecla foi premida."""
        return str(name).lower() in self._pressed

    def released(self, name):
        return str(name).lower() in self._released

    def tap(self):
        """(x, y) do toque deste frame, ou None."""
        return self._taps[0] if self._taps else None

    # ---- desenho (coordenadas do jogo: 0,0 no canto superior esquerdo) ----
    def clear(self, color=None):
        self._cmds.append(["c", _col(color) if color is not None else self.bg])

    def rect(self, x, y, w, h, color="white", fill=True):
        self._cmds.append(["r", round(x, 1), round(y, 1), round(w, 1), round(h, 1), _col(color), 1 if fill else 0])

    def circle(self, x, y, r, color="white", fill=True):
        self._cmds.append(["o", round(x, 1), round(y, 1), round(r, 1), _col(color), 1 if fill else 0])

    def line(self, x1, y1, x2, y2, color="white", width=2):
        self._cmds.append(["l", round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1), _col(color), width])

    def text(self, s, x, y, color="white", size=20, align="left"):
        self._cmds.append(["t", str(s), round(x, 1), round(y, 1), _col(color), size, align])

    def beep(self, freq=440, ms=100):
        self._cmds.append(["b", freq, ms])

    # ---- ciclo ----
    def run(self):
        """Abre o jogo e arranca o ciclo (volta logo; o jogo corre ate chamares quit() ou parares)."""
        if self._run:
            return
        self._run = True
        self._last = time.time()
        js._cvg.open(self.width, self.height, self.title, self.controls, self.bg)
        self._proxy = create_proxy(self._tick)
        js._cvg.start(self._proxy, int(1000 / self.fps))

    def quit(self):
        if self._run:
            self._run = False
            js._cvg.stop()

    def _tick(self):
        if not self._run:
            return
        inp = json.loads(js._cvg.take())
        self._held = set(inp["k"])
        self._pressed = set()
        self._released = set()
        self._taps = []
        for ev in inp["e"]:
            kind = ev[0]
            if kind == "d":
                self._pressed.add(ev[1])
            elif kind == "u":
                self._released.add(ev[1])
            elif kind == "pd":
                self._taps.append((ev[1], ev[2]))
                self.touching = True
                self.pointer = (ev[1], ev[2])
            elif kind == "pm":
                self.pointer = (ev[1], ev[2])
            elif kind == "pu":
                self.touching = False
        now = time.time()
        dt = min(0.05, max(0.0, now - self._last))
        self._last = now
        self.time += dt
        self.frame += 1
        if self._upd:
            self._upd(dt)
        if not self._run:
            return
        self._cmds = []
        if self._drw:
            self._drw()
        js._cvg.frame(json.dumps(self._cmds, separators=(",", ":")))
