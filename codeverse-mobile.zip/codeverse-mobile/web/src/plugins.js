/* CodeVerse — gestor de plugins (extensões).
 *
 * Um plugin é um ficheiro JSON DECLARATIVO (nunca executa código), por isso é seguro instalar plugins de qualquer loja:
 *   { "id": "meu-tema", "name": "Meu tema", "version": "1.0.0", "publisher": "eu", "description": "…",
 *     "type": "theme",    "theme":    { "dark": true, "colors": { "bg": "#…", "keyword": "#…", … }, "ui": { "bg": "#…", … } } }
 *   { "id": "meus-snippets", …, "type": "snippets", "snippets": { "python": [ { "prefix": "ifmain", "name": "…", "body": "…" } ] } }
 * Uma "loja" é um registry.json: { "name": "…", "plugins": [ { "id", "name", "version", "type", "description", "url" } ] }
 * (os "url" podem ser relativos ao endereço do registry).
 * A loja incluída na app funciona offline; lojas/URLs https podem ser acrescentadas pelo utilizador.
 */
(function () {
  'use strict';
  const KEY = 'cv.plugins';
  const HEX = /^#[0-9a-fA-F]{3,8}$/;
  const ID = /^[a-z0-9][a-z0-9._-]{1,60}$/;
  const COLOR_KEYS = ['bg', 'fg', 'sel', 'line', 'gutter', 'caret', 'keyword', 'control', 'string', 'comment', 'number', 'func', 'type', 'variable', 'constant', 'regexp', 'escape', 'invalid', 'tag', 'bracket', 'link'];
  const UI_VARS = { bg: '--bg', sidebar: '--sidebar', titlebar: '--titlebar', activity: '--activity', tabInactive: '--tab-inactive', border: '--border', fg: '--fg', fgStrong: '--fg-strong', muted: '--muted', hover: '--hover', selected: '--selected', inputBg: '--input-bg', accent: '--accent' };
  const LANGS = ['html', 'css', 'javascript', 'typescript', 'json', 'python', 'java', 'dart', 'markdown', 'text', 'all'];
  const MAX_BYTES = 300 * 1024;
  const BUNDLED_REGISTRY = 'plugins/registry.json';

  let state = { installed: {}, activeTheme: 'dark-plus', registries: [] };
  let httpGet = null; // função (url) => Promise<{status, body}> fornecida pela app (rede nativa)
  let listeners = [];

  function load() {
    try {
      const s = JSON.parse(localStorage.getItem(KEY) || '{}');
      if (s && typeof s === 'object') {
        state.installed = s.installed && typeof s.installed === 'object' ? s.installed : {};
        state.activeTheme = typeof s.activeTheme === 'string' ? s.activeTheme : 'dark-plus';
        state.registries = Array.isArray(s.registries) ? s.registries.filter((u) => /^https:\/\//i.test(u)) : [];
      }
    } catch (_) { /* ignora */ }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (_) { /* ignora */ } }
  function emitChange() { for (const f of listeners) { try { f(); } catch (_) { /* ignora */ } } }

  // ---------- Validação ----------
  function str(v, max, def) { return typeof v === 'string' ? v.slice(0, max) : (def || ''); }

  function validate(m) {
    if (!m || typeof m !== 'object') throw new Error('Plugin inválido (não é um objeto JSON).');
    const id = str(m.id, 80);
    if (!ID.test(id)) throw new Error('Plugin inválido: "id" deve usar só letras minúsculas, números, ponto, hífen e _.');
    if (id === 'dark-plus') throw new Error('O id "dark-plus" está reservado.');
    const out = { id, name: str(m.name, 80, id), version: str(m.version, 20, '1.0.0'), publisher: str(m.publisher, 60, 'desconhecido'), description: str(m.description, 300), type: m.type };
    if (m.type === 'theme') {
      const th = m.theme;
      if (!th || typeof th !== 'object' || !th.colors || typeof th.colors !== 'object') throw new Error('Tema inválido: falta "theme.colors".');
      const colors = {};
      for (const k of COLOR_KEYS) if (th.colors[k] != null) {
        if (!HEX.test(String(th.colors[k]))) throw new Error('Cor inválida em "' + k + '" (usa #rrggbb).');
        colors[k] = String(th.colors[k]);
      }
      if (!colors.bg || !colors.fg) throw new Error('Tema inválido: "bg" e "fg" são obrigatórios.');
      const ui = {};
      if (th.ui && typeof th.ui === 'object') for (const k of Object.keys(UI_VARS)) if (th.ui[k] != null) {
        if (!HEX.test(String(th.ui[k]))) throw new Error('Cor inválida em ui.' + k);
        ui[k] = String(th.ui[k]);
      }
      out.theme = { dark: th.dark !== false, colors, ui };
    } else if (m.type === 'snippets') {
      const sn = m.snippets;
      if (!sn || typeof sn !== 'object') throw new Error('Plugin de snippets inválido: falta "snippets".');
      const clean = {};
      let total = 0;
      for (const lang of Object.keys(sn)) {
        if (!LANGS.includes(lang)) continue;
        if (!Array.isArray(sn[lang])) continue;
        clean[lang] = [];
        for (const s of sn[lang]) {
          if (!s || typeof s.prefix !== 'string' || typeof s.body !== 'string') continue;
          if (!/^[\w!.\-]{1,30}$/.test(s.prefix) || s.body.length > 4000) continue;
          if (++total > 500) break;
          clean[lang].push({ prefix: s.prefix, name: str(s.name, 80, s.prefix), body: s.body });
        }
      }
      if (!total) throw new Error('O plugin não tem snippets válidos.');
      out.snippets = clean;
    } else {
      throw new Error('Tipo de plugin não suportado: "' + m.type + '" (suportados: theme, snippets).');
    }
    return out;
  }

  // ---------- Aplicar ----------
  let appliedUi = [];
  function applyUi(ui) {
    const root = document.documentElement;
    for (const v of appliedUi) root.style.removeProperty(v);
    appliedUi = [];
    for (const k of Object.keys(ui || {})) {
      const v = UI_VARS[k];
      if (!v) continue;
      root.style.setProperty(v, ui[k]);
      appliedUi.push(v);
    }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta && ui && ui.bg) meta.setAttribute('content', ui.bg);
  }

  function apply() {
    const Ed = window.CVEditor;
    // tema
    let th = null;
    const p = state.installed[state.activeTheme];
    if (state.activeTheme !== 'dark-plus' && p && p.type === 'theme') th = p;
    if (state.activeTheme !== 'dark-plus' && !th) state.activeTheme = 'dark-plus';
    if (Ed && Ed.setTheme) Ed.setTheme(th ? { id: th.id, name: th.name, dark: th.theme.dark, colors: th.theme.colors } : null);
    applyUi(th ? Object.assign({ bg: th.theme.colors.bg }, th.theme.ui) : {});
    // snippets
    const map = {};
    for (const id of Object.keys(state.installed)) {
      const pl = state.installed[id];
      if (pl.type !== 'snippets' || pl.enabled === false) continue;
      for (const lang of Object.keys(pl.snippets)) (map[lang] = map[lang] || []).push(...pl.snippets[lang]);
    }
    if (Ed && Ed.setSnippets) Ed.setSnippets(map);
  }

  // ---------- Rede ----------
  async function getText(url) {
    if (/^https:\/\//i.test(url)) {
      if (!httpGet) throw new Error('A rede só está disponível dentro da app Android.');
      const r = await httpGet(url);
      if (r.status < 200 || r.status >= 300) throw new Error('O servidor respondeu ' + r.status + '.');
      if (r.body.length > MAX_BYTES) throw new Error('Ficheiro demasiado grande.');
      return r.body;
    }
    if (/^[a-z][a-z0-9+.-]*:/i.test(url) || url.startsWith('//') || url.includes('..')) throw new Error('Endereço não permitido (só https:// ou plugins incluídos na app).');
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error('Plugin incluído não encontrado (' + res.status + ').');
    const text = await res.text();
    if (text.length > MAX_BYTES) throw new Error('Ficheiro demasiado grande.');
    return text;
  }

  function resolve(base, rel) {
    if (/^https:\/\//i.test(rel)) return rel;
    if (/^https:\/\//i.test(base)) { try { return new URL(rel, base).href; } catch (_) { throw new Error('Endereço inválido: ' + rel); } }
    return base.replace(/[^/]*$/, '') + rel;
  }

  async function fetchRegistry(url) {
    const text = await getText(url);
    let j;
    try { j = JSON.parse(text); } catch (_) { throw new Error('A loja não devolveu JSON válido.'); }
    if (!j || !Array.isArray(j.plugins)) throw new Error('Loja inválida: falta a lista "plugins".');
    const plugins = [];
    for (const e of j.plugins.slice(0, 300)) {
      if (!e || !ID.test(String(e.id)) || typeof e.url !== 'string') continue;
      plugins.push({
        id: e.id, name: str(e.name, 80, e.id), version: str(e.version, 20, '1.0.0'), publisher: str(e.publisher, 60, ''),
        type: e.type === 'theme' || e.type === 'snippets' ? e.type : '', description: str(e.description, 300),
        url: resolve(url, e.url), registry: url,
      });
    }
    return { name: str(j.name, 80, url), url, plugins };
  }

  async function installFromUrl(url) {
    const text = await getText(url);
    let j;
    try { j = JSON.parse(text); } catch (_) { throw new Error('O ficheiro não é JSON válido.'); }
    const m = validate(j);
    m.enabled = true;
    m.source = url;
    m.installedAt = Date.now();
    state.installed[m.id] = m;
    save(); apply(); emitChange();
    return m;
  }

  function uninstall(id) {
    delete state.installed[id];
    if (state.activeTheme === id) state.activeTheme = 'dark-plus';
    save(); apply(); emitChange();
  }

  function setActiveTheme(id) {
    if (id !== 'dark-plus' && !(state.installed[id] && state.installed[id].type === 'theme')) throw new Error('Tema não instalado.');
    state.activeTheme = id;
    save(); apply(); emitChange();
  }

  function setEnabled(id, on) {
    if (state.installed[id]) { state.installed[id].enabled = !!on; save(); apply(); emitChange(); }
  }

  function addRegistry(url) {
    if (!/^https:\/\//i.test(url)) throw new Error('O endereço da loja tem de começar por https://');
    if (!state.registries.includes(url)) state.registries.push(url);
    save(); emitChange();
  }
  function removeRegistry(url) { state.registries = state.registries.filter((u) => u !== url); save(); emitChange(); }

  window.CVPlugins = {
    BUNDLED_REGISTRY,
    init(opts) { httpGet = (opts && opts.httpGet) || null; load(); apply(); },
    onChange(f) { listeners.push(f); },
    installed() { return Object.keys(state.installed).map((k) => state.installed[k]); },
    isInstalled(id) { return !!state.installed[id]; },
    get(id) { return state.installed[id] || null; },
    activeTheme() { return state.activeTheme; },
    registries() { return state.registries.slice(); },
    fetchRegistry, installFromUrl, uninstall, setActiveTheme, setEnabled, addRegistry, removeRegistry, validate, apply,
  };
})();
