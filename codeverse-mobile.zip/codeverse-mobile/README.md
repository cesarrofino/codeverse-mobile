# CodeVerse

Ambiente de programação para Android com a aparência do **VS Code (Dark+)**: barra lateral com Explorador e Pesquisa em todos os ficheiros, separadores com ícones, caminho do ficheiro, barra de estado, definições organizadas e um **ecrã próprio de execução**. Corre HTML/CSS/JS, Python (com `input()`) e **Java, tudo offline**; abre e guarda pastas do telemóvel; tem extensões (temas e snippets). Não é o VS Code nem usa o seu logótipo.

## Como gerar o APK só com o telemóvel (GitHub Actions)

1. Cria um repositório no GitHub (pode ser privado).
2. Em **Add file → Upload files**, envia o ficheiro `codeverse-mobile.zip` **sem o extrair**.
3. Em **Add file → Create new file**, escreve o nome `.github/workflows/build-apk.yml` e cola o conteúdo do ficheiro `build-apk.yml` (vem à parte). Faz *Commit*.
4. Separador **Actions → Build APK**. Se não arrancou sozinho, toca em **Run workflow**.
5. Quando ficar verde (✓), abre a execução e descarrega o artefacto **CodeVerse-Mobile-APK**. É um ZIP com o `.apk`; extrai e instala (permite “instalar de fontes desconhecidas”).

Se tiveres um computador: extrai o ZIP, faz push de tudo para o repositório (o workflow já está em `.github/workflows/`).

> Se o build falhar, abre o passo vermelho, copia as últimas ~30 linhas do erro e envia-as para correção.
> Atenção: usa o `build-apk.yml` desta versão (já não tem o passo "Preparar biblioteca Java"; se mantiveres o antigo, também funciona).

## Novidades da versão 0.3

- **Java offline corrigido**: o `rt.jar` (biblioteca Java) passou a ser gerado pelo próprio Gradle (tarefa `generateJavaRt`) e entra sempre no APK. Já não depende do passo "Preparar biblioteca Java" do workflow. Se algo falhar, a mensagem mostra agora a causa real.
- **`input()` do Python funciona**: o programa pára e espera pela linha escrita na barra de entrada do ecrã de execução (também `sys.stdin.readline()` e `for linha in sys.stdin`).
- **Botão Guardar** (ícone de disquete) na barra superior; fica com um ponto azul quando há alterações por guardar, e os separadores mostram `●`. A gravação automática continua ativa.
- **Ficheiros novos já com estrutura**: HTML, CSS, JS/TS, JSON, Python, Java (classe com o nome do ficheiro e `package` pela pasta), Dart, Flutter (em projeto com `pubspec.yaml` ou ao escolher "Flutter (widget)"), Markdown, XML, Kotlin, C/C++, Shell, PHP, SQL, Vue. O cursor fica dentro da estrutura.
- **Pastas e ficheiros do telemóvel**: *Início → Abrir pasta do telemóvel…* / *Abrir ficheiro(s) do telemóvel…*. Tudo o que guardas (e criar, renomear, eliminar) é espelhado na pasta real. Menu do projeto → *Atualizar do armazenamento* volta a ler a pasta.
- **Cores do VS Code**: palette Dark+ completa, mais realce de classes/exceções/tipos nativos (`ValueError`, `float`, `int`…) a verde-azulado, constantes e `self`.
- **Extensões (plugins)**: ícone de extensões na barra lateral. Loja incluída (13 plugins: temas Dark+ Azul-escuro, Monokai, Dracula, One Dark, GitHub Dark, Solarized Dark, Tokyo Night, Light+; snippets de HTML/CSS, JavaScript, Python, Java e Flutter/Dart), instalação/desinstalação dentro da app, **instalar por URL** e **adicionar lojas** `https://…/registry.json`.

### Formato de um plugin (JSON, sem código executável)

```json
{ "id": "meu-tema", "name": "Meu tema", "version": "1.0.0", "publisher": "eu", "type": "theme",
  "description": "…",
  "theme": { "dark": true,
    "colors": { "bg": "#1e1e1e", "fg": "#d4d4d4", "keyword": "#569cd6", "control": "#c586c0", "string": "#ce9178",
                "comment": "#6a9955", "number": "#b5cea8", "func": "#dcdcaa", "type": "#4ec9b0", "variable": "#9cdcfe",
                "constant": "#4fc1ff", "sel": "#264f78", "line": "#2a2d2e", "gutter": "#858585" },
    "ui": { "bg": "#1e1e1e", "sidebar": "#252526", "titlebar": "#3c3c3c" } } }
```

```json
{ "id": "meus-snippets", "name": "Meus snippets", "version": "1.0.0", "type": "snippets",
  "snippets": { "python": [ { "prefix": "ifmain", "name": "if __name__", "body": "if __name__ == \"__main__\":\n    ${1:main()}" } ] } }
```

Uma loja é um `registry.json`: `{ "name": "A minha loja", "plugins": [ { "id": "meu-tema", "name": "Meu tema", "type": "theme", "version": "1.0.0", "description": "…", "url": "meu-tema.json" } ] }` (o `url` pode ser relativo). Podes alojá-la no GitHub (endereço *raw*) e adicioná-la em *Extensões → Adicionar loja…*. Por segurança só são aceites plugins declarativos (temas e snippets); plugins com código não são executados.

## Estado real das funcionalidades

| Funcionalidade | Estado |
|---|---|
| Projetos, ficheiros e pastas, gravação automática, botão Guardar | Implementado, **por testar em dispositivo** |
| Pastas/ficheiros do armazenamento do telemóvel (abrir + guardar de volta) | Implementado (Storage Access Framework), **por testar em dispositivo** |
| Editor CodeMirror 6, cores Dark+, realce por linguagem, pesquisa/substituição, teclas extra | Implementado, por testar |
| Modelos de ficheiro novo | Implementado e testado em Node |
| Extensões (temas + snippets), loja incluída, instalar por URL/loja | Validação testada em Node; interface **por testar em dispositivo** |
| HTML/CSS/JS com pré-visualização e consola (offline) | Implementado, por testar |
| Python (Pyodide, offline) com `input()` | Implementado, **por testar** (o `input()` usa um pedido síncrono interceptado pela app). Sem bibliotecas extra (numpy, etc.) |
| Java (ECJ + D8, offline) | Implementado, **por testar** (rt.jar agora gerado pelo Gradle) |
| Dart (consola) | Depende de serviço externo (API compatível com Piston) |
| Flutter | Só edição + workflow para gerar APK no GitHub. **Não executa no telemóvel** |

“Por testar” = o código foi escrito e verificado quanto a sintaxe, mas **ainda não foi compilado nem executado num Android** (o ambiente onde foi escrito não tem Android SDK nem rede). A primeira compilação pode revelar erros a corrigir: envia as últimas ~30 linhas do erro.

## Armazenamento do telemóvel: como funciona e limites

- A pasta escolhida é **copiada** para um projeto interno (necessário para compilar Java e correr Python) e cada gravação é **espelhada** na pasta real, por ordem. A permissão fica guardada (não pede de novo).
- O Android 11+ **não deixa escolher a raiz do armazenamento nem as pastas Download/Android**: cria uma pasta de projetos (ex.: `Documentos/Projetos`) e escolhe-a ou uma subpasta.
- Ignora `.git`, `node_modules`, `venv`, `build`, `__pycache__`; máx. 5000 ficheiros / 120 MB / 25 MB por ficheiro.
- Se outra app alterar a pasta, usa *Atualizar do armazenamento* (substitui os ficheiros locais pelos da pasta).
- Eliminar um projeto ligado **não apaga** a pasta real; só desliga.

## Online / offline

- **Offline:** HTML/CSS/JS, JavaScript, Python, **Java**, edição, projetos, ZIP, plugins incluídos.
- **Online:** Dart; lojas e plugins por URL (https).

## Java offline (como funciona)

1. `ECJ` (compilador do Eclipse) compila os `.java` para `.class`, usando a biblioteca padrão em `assets/java/rt.jar`.
2. `D8` converte para `classes.dex`; carregado com `DexClassLoader`; `main(String[])` é chamado.
3. Corre num **processo separado** (`:runner`): Parar termina esse processo; `Scanner`/`System.in` lê da barra de entrada.

O `rt.jar` é gerado no build pela tarefa Gradle `generateJavaRt` a partir do `android.jar` (só `java.*`, `javax.*`, `org.json`). Limitações: sem `android.*`; `System.exit()` termina a execução; Java 11 experimental.

## Arquitetura

- `app/` — app nativa Kotlin: `MainActivity` (WebView com servidor interno de assets em `https://appassets.androidplatform.net`), `Bridge` (ponte JS↔nativo), `ProjectStore` (ficheiros no armazenamento privado da app, com validação de caminhos, ZIP seguro contra *zip-slip* e limites de tamanho).
- `web/` — interface HTML/JS. O build (`web/build.mjs`) empacota o editor CodeMirror com esbuild e copia o Pyodide para `app/src/main/assets/www/`.
- `.github/workflows/build-apk.yml` — instala Node, JDK 17, Android SDK, Gradle 8.9; gera a web; compila `assembleDebug`.
- Versões usadas: AGP 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 34, minSdk 26 (exigido pelo D8 em Android), ECJ 3.25.0, R8/D8 8.5.35, CodeMirror 6, Pyodide 0.26.x. Requer um *Android System WebView* atualizado.

## Segurança

- Só carrega conteúdo da própria app; navegação externa abre no navegador; sem acesso a `file://`.
- O código de HTML corre num `iframe` com `sandbox` (sem acesso ao armazenamento da app). Python e JS correm em Workers isolados.
- Projetos ficam no armazenamento privado da app (`allowBackup=false`).
- Sem chaves/credenciais no código. O APK é *debug* (assinado com a chave de debug): serve para instalar e testar, **não** para publicar na Play Store.

## Limitações conhecidas

- Python: sem bibliotecas extra (numpy, pandas…); `input()` espera até 15 min por linha.
- Páginas web com `<script type="module">` que usam `import` de ficheiros do projeto não funcionam na pré-visualização.
- Ficheiros >2 MB não abrem no editor; binários não são editáveis.
- Dart não tem compilador local no Android; Flutter só edita.
- O APK ficou maior (≈ +20 MB) por incluir o compilador Java e o `rt.jar`.

## Próximas etapas sugeridas

1. Compilar, instalar, e testar cada função (lista abaixo) — corrigir erros reportados.
2. Pacotes Python offline extra (numpy).
3. Assinatura *release* com chave guardada nos *Secrets* do GitHub.
4. *Git* básico, formatação de código, mais linguagens.

### Lista de testes a fazer após instalar
1. Criar projeto Web → ▶ mostra a página; clicar no botão regista no consola.
2. Criar projeto Python → ▶ imprime “Olá, CodeVerse!” (modo avião ativado: deve funcionar).
3. Criar/renomear/eliminar ficheiro e pasta; fechar a app e reabrir: tudo mantido.
4. Exportar ZIP e voltar a importar.
5. Java em modo avião: ▶ abre o ecrã de execução, compila e imprime “Olá, CodeVerse!”. Testa também um `Scanner` a ler da linha de entrada e um `while(true){}` com o botão Parar.
6. Web: ▶ abre a pré-visualização em ecrã inteiro; o botão da consola mostra o `console.log` e os erros.
7. Definições: alterar tamanho da letra, tabulação e números de linha reflete-se logo no editor.
8. Python: ▶ num programa com `nome = input("Nome? ")` → aparece a barra de entrada; escreve e continua.
9. Início → Abrir pasta do telemóvel → escolhe uma pasta de projetos; edita, toca em Guardar, abre a pasta no gestor de ficheiros e confirma a alteração.
10. Explorador → novo ficheiro `teste.py` / `Pagina.html` / `Foo.java`: já vem com a estrutura.
11. Extensões → Loja → instala "Dark+ Azul-escuro" e "Python essenciais"; escreve `ifmain` num .py e escolhe o snippet.
