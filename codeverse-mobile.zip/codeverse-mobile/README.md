# CodeVerse Mobile

Ambiente de programação para Android com a aparência do **VS Code (Dark+)**: barra lateral com Explorador e Pesquisa em todos os ficheiros, separadores com ícones, caminho do ficheiro, barra de estado, definições organizadas e um **ecrã próprio de execução**. Corre HTML/CSS/JS, Python e **Java, tudo offline**. Não é o VS Code nem usa o seu logótipo.

## Como gerar o APK só com o telemóvel (GitHub Actions)

1. Cria um repositório no GitHub (pode ser privado).
2. Em **Add file → Upload files**, envia o ficheiro `codeverse-mobile.zip` **sem o extrair**.
3. Em **Add file → Create new file**, escreve o nome `.github/workflows/build-apk.yml` e cola o conteúdo do ficheiro `build-apk.yml` (vem à parte). Faz *Commit*.
4. Separador **Actions → Build APK**. Se não arrancou sozinho, toca em **Run workflow**.
5. Quando ficar verde (✓), abre a execução e descarrega o artefacto **CodeVerse-Mobile-APK**. É um ZIP com o `.apk`; extrai e instala (permite “instalar de fontes desconhecidas”).

Se tiveres um computador: extrai o ZIP, faz push de tudo para o repositório (o workflow já está em `.github/workflows/`).

> Se o build falhar, abre o passo vermelho, copia as últimas ~30 linhas do erro e envia-as para correção.

## Estado real das funcionalidades

| Funcionalidade | Estado |
|---|---|
| Projetos (criar, renomear, eliminar, recentes), ficheiros e pastas, gravação automática | Implementado, **por testar em dispositivo** |
| Editor CodeMirror 6, tema Dark+, realce por linguagem, números de linha, pesquisa/substituição, teclas extra | Implementado, **por testar em dispositivo** |
| HTML/CSS/JS com pré-visualização e consola (offline) | Implementado, por testar |
| JavaScript isolado (Worker, sem DOM) | Implementado, por testar |
| Python (Pyodide/CPython em WebAssembly, offline) | Implementado, por testar. Sem `input()`, sem bibliotecas extra (numpy, etc.) |
| Importar/exportar ZIP | Implementado, por testar |
| Java (compilador ECJ + D8 dentro da app, **offline**) | Implementado, **por testar em dispositivo** (é a parte mais arriscada: ver “Java offline”) |
| Dart (consola) | Depende de serviço externo (API compatível com Piston, configurável) |
| Flutter | Só edição + workflow incluído no modelo para gerar APK no GitHub. **Não executa no telemóvel** |

“Por testar” = o código foi escrito e verificado quanto a sintaxe, mas **ainda não foi compilado nem executado num Android**. A primeira compilação pode revelar erros a corrigir.

## Online / offline

- **Offline:** HTML/CSS/JS, JavaScript, Python, **Java**, edição, projetos, ZIP.
- **Online:** só o Dart (o código é enviado ao serviço configurado em Definições → Execução).

## Java offline (como funciona)

1. `ECJ` (compilador do Eclipse) compila os `.java` do projeto para `.class`, usando a biblioteca padrão em `assets/java/rt.jar`.
2. `D8` converte os `.class` para `classes.dex`.
3. O DEX é carregado com `DexClassLoader` e `main(String[])` é chamado.
4. Tudo corre num **processo separado** (`:runner`): o botão Parar termina esse processo (ciclos infinitos não bloqueiam a app) e a entrada (`Scanner`, `System.in`) é escrita na linha de baixo do ecrã de execução.

O `rt.jar` é gerado no build por `tools_make_javalib.py` a partir do `android.jar` do SDK (só `java.*`, `javax.*`, `org.json`). Limitações: não há `android.*` nos programas; `System.exit()` termina o processo de execução; Java 11 (Definições → Execução) é experimental; o primeiro arranque do compilador demora alguns segundos.

## Arquitetura

- `app/` — app nativa Kotlin: `MainActivity` (WebView com servidor interno de assets em `https://appassets.androidplatform.net`), `Bridge` (ponte JS↔nativo), `ProjectStore` (ficheiros no armazenamento privado da app, com validação de caminhos, ZIP seguro contra *zip-slip* e limites de tamanho).
- `web/` — interface HTML/JS. O build (`web/build.mjs`) empacota o editor CodeMirror com esbuild e copia o Pyodide para `app/src/main/assets/www/`.
- `.github/workflows/build-apk.yml` — instala Node, JDK 17, Android SDK, Gradle 8.9; gera a web; compila `assembleDebug`.
- Versões usadas: AGP 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 34, minSdk 26 (exigido pelo D8 em Android), ECJ 3.25.0, R8/D8 8.5.35, CodeMirror 6, Pyodide 0.26.x. Requer um *Android System WebView* atualizado.

## Segurança

- Só carrega conteúdo da própria app; navegação externa abre no navegador; sem acesso a `file://`.
- O código de HTML corre num `iframe` com `sandbox` (sem acesso ao armazenamento da app). Python e JS correm em Workers isolados.
- Projetos ficam no armazenamento privado da app (`allowBackup=false`).
- Sem chaves/credenciais no código. O APK é *debug* (assinado com a chave de debug): serve para instalar e testar, **não** para publicar na Play Store.

## Limitações conhecidas

- `input()` do Python não funciona (sem leitura de teclado em Worker).
- Páginas web com `<script type="module">` que usam `import` de ficheiros do projeto não funcionam na pré-visualização.
- Ficheiros >2 MB não abrem no editor; binários não são editáveis.
- Dart não tem compilador local no Android; Flutter só edita.
- O APK ficou maior (≈ +20 MB) por incluir o compilador Java e o `rt.jar`.

## Próximas etapas sugeridas

1. Compilar, instalar, e testar cada função (lista abaixo) — corrigir erros reportados.
2. Pacotes Python offline extra (numpy) e `input()` com SharedArrayBuffer/diálogo.
3. Assinatura *release* com chave guardada nos *Secrets* do GitHub.
4. Pesquisa em todos os ficheiros, *Git* básico, temas adicionais.

### Lista de testes a fazer após instalar
1. Criar projeto Web → ▶ mostra a página; clicar no botão regista no consola.
2. Criar projeto Python → ▶ imprime “Olá, CodeVerse!” (modo avião ativado: deve funcionar).
3. Criar/renomear/eliminar ficheiro e pasta; fechar a app e reabrir: tudo mantido.
4. Exportar ZIP e voltar a importar.
5. Java em modo avião: ▶ abre o ecrã de execução, compila e imprime “Olá, CodeVerse!”. Testa também um `Scanner` a ler da linha de entrada e um `while(true){}` com o botão Parar.
6. Web: ▶ abre a pré-visualização em ecrã inteiro; o botão da consola mostra o `console.log` e os erros.
7. Definições: alterar tamanho da letra, tabulação e números de linha reflete-se logo no editor.
